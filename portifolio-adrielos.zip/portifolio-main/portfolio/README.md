# AdrielOS — Portfólio interativo estilo Windows 11

Portfólio de **Adriel Morback** feito como um sistema operacional completo no navegador, em HTML, CSS e JavaScript puros (sem build, sem frameworks).

## O que tem
- **Boot, tela de bloqueio e login** (com "entrar automaticamente"), desligar / reiniciar / suspender e tela azul (easter egg).
- **Área de trabalho**: ícones selecionáveis, arrastáveis e renomeáveis, seleção por retângulo, Novo → Pasta/Documento, **Lixeira funcional**.
- **Barra de tarefas Windows 11**: Iniciar, Pesquisa, Visão de Tarefas, Widgets, apps fixados/em execução, bandeja, relógio, "mostrar área de trabalho", menu Win+X (botão direito no Iniciar).
- **Menu Iniciar** (fixados, recomendados, todos os apps), **Pesquisa** global (apps, projetos, arquivos, configurações), **Widgets** (relógio, Pomodoro, notas…), **Configurações rápidas**, **Central de notificações + calendário**.
- **Janelas**: arrastar, redimensionar, minimizar/maximizar, **snap nas bordas e Snap Layouts**, Alt+Tab-like, atalhos.
- **Apps**: Explorador de Arquivos (projetos/documentos/imagens), Navegador com abas, Sobre, Habilidades, GitHub, Contato, Configurações (18+ papéis de parede, animados, imagem própria, cores, tema, barra de tarefas…), Bloco de Notas, Calculadora, Terminal (`help`), Fotos, Paint, Campo Minado, Snake, Gerenciador de Tarefas, Rádio AdrielOS, Leitor de PDF, Executar (`Ctrl+Alt+R`).

## Estrutura
```
portfolio/
├── index.html · style.css
├── js/  icons.js · data.js (edite projetos/skills aqui) · core.js · shell.js · desktop.js
│        apps-core.js · apps-settings.js · apps-tools.js · main.js
└── assets/ wallpapers/ · icons/ · projects/ · docs/
```
## Rodar
`python -m http.server 8080 --directory portfolio` e abra http://localhost:8080 (ou abra o `index.html`). Publica direto no GitHub Pages / Vercel / Netlify.

## Contato
adriel.morback@gmail.com · WhatsApp +55 19 97422-6148 · github.com/43111-cyber
