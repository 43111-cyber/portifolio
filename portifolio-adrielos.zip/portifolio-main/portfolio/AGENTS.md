# Guia rápido — AdrielOS
- Sem build: edite os arquivos e recarregue.
- Dados do portfólio (projetos, skills, textos): `js/data.js`.
- Novo app: `OS.registerApp({id,title,icon,w,h,build(win,opts)})` em `js/apps-*.js`; adicione o ícone em `js/icons.js`; para aparecer no Iniciar, inclua o id em `START_PINS` (`js/shell.js`).
- Wallpapers: arquivos em `assets/wallpapers/` + lista `WALLPAPERS` em `js/core.js`.
- Configurações persistem em `localStorage` (prefixo `adrielos.`).
