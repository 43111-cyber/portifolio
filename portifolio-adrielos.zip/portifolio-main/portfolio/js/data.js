/* ==========================================================================
   AdrielOS — DADOS DO PORTFÓLIO (projetos, habilidades, textos)
   Tudo que aparece nos aplicativos vem daqui, para ficar fácil de editar.
   ========================================================================== */
(function () {
  'use strict';

  const DATA = (window.DATA = {});

  DATA.me = {
    name: 'Adriel Morback',
    role: 'Estudante de Ensino Médio Técnico',
    tagline: 'Entre códigos, ideias e futebol, estou sempre criando algo novo.',
    bio: 'Olá! Meu nome é Adriel Morback. Sou estudante de Ensino Médio Técnico, gosto de criar sites, desenvolver projetos e aprender novas tecnologias. Também gosto muito de futebol. Este espaço reúne um pouco do que estou aprendendo e construindo.',
    email: 'adriel.morback@gmail.com',
    whatsapp: '5519974226148',
    whatsappLabel: '+55 19 97422-6148',
    github: 'https://github.com/43111-cyber',
    githubUser: '43111-cyber'
  };

  DATA.projects = [
    {
      id: 'beico-street', name: 'BEIÇO STREET — Taça das Favelas Campinas', short: 'Beiço Street',
      image: 'assets/projects/beico_street_logo.png', badge: '🏆 Jogo Arcade 1v1', status: 'Ativo', owner: '43111-cyber / jogo-ste',
      site: 'https://jogo-ste.vercel.app/', repo: 'https://github.com/43111-cyber/jogo-ste',
      desc: 'Projeto de jogo desenvolvido por mim: uma experiência arcade de futebol de rua 1v1 diretamente no navegador. Conta com escolha de times da quebrada, modo torneio com chaveamento (oitavas, quartas, semifinal e final), placar digital dinâmico, cronômetro de partida e suporte a 1 Jogador vs CPU ou 2 Jogadores locais.',
      tags: ['JavaScript (72.4%)', 'CSS3 (19.4%)', 'HTML5 (8.2%)', 'Canvas 2D API'], kind: 'Jogo'
    },
    {
      id: 'krakens', name: 'Krakens & Cannons: Cerco Total', short: 'Krakens & Cannons',
      image: 'assets/projects/krakens_cannons.svg', badge: '🏴‍☠️ Jogo de Estratégia', status: 'Online', owner: 'fora-da-caixaa',
      site: 'https://fora-da-caixaa-vj5m.vercel.app/',
      desc: 'Jogo de estratégia naval com tema pirata, direto no navegador: gerencie a frota, o casco do navio e a chegada de reforços, e sobreviva ao cerco. O site também traz artigos sobre a história e a cultura da pirataria.',
      tags: ['Jogo Web', 'Estratégia Naval', 'Tema Pirata', 'Vercel'], kind: 'Jogo'
    },
    {
      id: 'skins', name: 'Beiço Skins', short: 'Beiço Skins',
      image: 'assets/projects/beico_skins_logo.jpg', badge: '🎨 Skins', status: 'Online', owner: 'bei-o-a-skins',
      site: 'https://bei-o-a-skins.vercel.app/',
      desc: 'Marketplace de skins do universo Beiço, com cadastro e login de usuários.',
      tags: ['Cadastro & Login', 'Marketplace', 'Vercel'], kind: 'Site'
    },
    {
      id: 'morfaias', name: "MorfaIA's — Consultoria em Inteligência Artificial", short: "MorfaIA's",
      image: 'assets/projects/morfaias_capa.jpg', badge: '📑 Proposta Comercial', status: 'Setembro de 2026', owner: "MorfaIA's — Morback + Fazio",
      pdf: 'assets/docs/MorfaIAs-proposta.pdf',
      desc: "Proposta comercial de consultoria de IA para uma adega de bairro em Campinas/SP: diagnóstico da operação, previsão de demanda com reposição automática de estoque e roteirização inteligente das entregas, com riscos, investimento e cronograma de cerca de 15 semanas.",
      tags: ['Inteligência Artificial', 'Previsão de Demanda', 'Otimização de Rotas', 'Consultoria'], kind: 'Documento'
    },
    {
      id: 'future', name: 'Próximos Projetos', short: 'Próximos Projetos',
      image: 'assets/projects/future_lab.jpg', badge: '⚡ Em Desenvolvimento', status: 'Em Progresso', owner: 'Pipeline de Criação', future: true,
      desc: 'Área reservada para futuros sites, novos jogos interativos, protótipos de sistemas e aplicações completas que estão sendo planejadas e codificadas. Atualizado periodicamente conforme novos repositórios são publicados.',
      tags: ['Web Apps', 'Jogos 2D', 'Sistemas Web', 'Projetos Técnicos'], kind: 'Em construção'
    }
  ];

  DATA.interests = [
    { t: 'Desenvolvimento de Sites', d: 'Criação de páginas dinâmicas, interfaces responsivas, estruturação semântica e estilização moderna para a web.', c: '#22c55e', i: 'monitor' },
    { t: 'Programação', d: 'Lógica de algoritmos, manipulação de dados, scripts interativos e resolução prática de desafios computacionais.', c: '#38bdf8', i: 'terminal' },
    { t: 'Projetos Digitais', d: 'Construção de aplicações úteis, materiais educacionais acessíveis e ferramentas que geram impacto real.', c: '#f59e0b', i: 'projects' },
    { t: 'Futebol', d: 'Paixão esportiva, trabalho em equipe, visão tática e inspiração para jogos de futebol arcade interativos.', c: '#ef4444', i: 'soccer' }
  ];

  DATA.skills = [
    {
      id: 'front', title: 'Criação de Sites & Front-End', color: '#22c55e', items: [
        ['HTML5 Semântico', 'Confirmado em projetos', 'Estruturação correta, acessibilidade, meta tags e integração de elementos multimídia e Canvas.'],
        ['CSS3 Moderno', 'Confirmado em projetos', 'Flexbox, CSS Grid, variáveis personalizadas, efeitos de vidro (glassmorphism), animações e responsividade.'],
        ['JavaScript Puro (ES6+)', 'Confirmado em projetos', 'Manipulação de DOM, gerenciamento de eventos, lógica funcional e estruturação modular sem dependência de frameworks.']
      ]
    },
    {
      id: 'prog', title: 'Programação & Lógica de Sistemas', color: '#38bdf8', items: [
        ['HTML5 Canvas 2D & Games', 'Utilizado no Jogo STE', 'Renderização gráfica em tempo real, detecção de colisão, física de bola e animação por quadros de arcade.'],
        ['Estruturação & Lógica de Torneio', 'Utilizado no Jogo STE', 'Sistemas de pontuação, cronômetro de partida, IA básica para modo CPU e fluxo de fases eliminatórias.'],
        ['Git & GitHub', 'Repositório Ativo', 'Versionamento de código, controle de histórico e publicação de projetos open-source.']
      ]
    },
    {
      id: 'curso', title: 'Disciplinas do Curso Técnico', color: '#a78bfa', items: [
        ['Programação', 'Estudo no curso', 'Lógica de programação, algoritmos e construção de programas.'],
        ['Desenvolvimento de Software', 'Estudo no curso', 'Planejamento, desenvolvimento e teste de sistemas e aplicações.'],
        ['Desenvolvimento de Aplicativos', 'Estudo no curso', 'Criação de aplicativos para dispositivos móveis.'],
        ['Banco de Dados', 'Estudo no curso', 'Modelagem, organização e consulta de dados.'],
        ['Redes de Dados', 'Estudo no curso', 'Estrutura e funcionamento de redes de computadores.'],
        ['Suporte em Informática', 'Estudo no curso', 'Manutenção, diagnóstico e atendimento a problemas de computadores.'],
        ['Computadores & Sistemas Operacionais', 'Estudo no curso', 'Gestão e configuração de computadores e sistemas operacionais.']
      ]
    },
    {
      id: 'tools', title: 'Projetos Digitais & Ferramentas', color: '#f59e0b', items: [
        ['Tecnologia & Futebol', 'Tema de Destaque', 'Integração de conceitos táticos do esporte em experiências digitais dinâmicas e envolventes.'],
        ['AdrielOS (este site)', 'Você está dentro dele', 'Um sistema operacional completo simulado no navegador: janelas, aplicativos, jogos e personalização — feito só com HTML, CSS e JavaScript puro.']
      ]
    }
  ];

  DATA.quotes = [
    'Futebol e código têm a mesma regra: treine o básico até ficar automático.',
    'Um bom passe é como uma boa função: simples, claro e na hora certa.',
    'Todo bug é só um zagueiro que ainda não foi driblado.',
    'Equipe boa vence jogo; commit pequeno vence projeto.',
    'Quem estuda um pouco todo dia ganha o campeonato da consistência.',
    'Primeiro faz funcionar, depois faz ficar bonito, depois faz ficar rápido.',
    'Erre rápido, aprenda mais rápido ainda.',
    'Visão de jogo também se aprende lendo código dos outros.'
  ];

  DATA.tips = [
    ['CSS', 'Use <code>clamp()</code> para tipografia fluida sem media queries.'],
    ['JavaScript', 'Prefira <code>const</code> por padrão; use <code>let</code> só quando precisar reatribuir.'],
    ['Git', 'Commits pequenos e frequentes facilitam encontrar onde um bug nasceu.'],
    ['HTML', 'Botões são <code>&lt;button&gt;</code>, links são <code>&lt;a&gt;</code>. Semântica ajuda acessibilidade e SEO.'],
    ['Canvas', 'Use <code>requestAnimationFrame</code> em vez de <code>setInterval</code> para animações suaves.'],
    ['Dev', 'Leia a mensagem de erro inteira — a resposta quase sempre está nela.'],
    ['Performance', 'Meça antes de otimizar: o gargalo raramente está onde você imagina.']
  ];
})();
