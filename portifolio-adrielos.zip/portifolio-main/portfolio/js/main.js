/* AdrielOS — inicialização */
(function () {
  'use strict';
  OS.applyAllSettings();
  OS.wallpaper.apply();
  OS.on('profile', () => { /* avatar atualizado nas telas de login */ });
  document.addEventListener('contextmenu', (e) => { if (!e.target.closest('input, textarea')) e.preventDefault(); });
  OS.session.start();
  window.addEventListener('error', (e) => console.warn('AdrielOS:', e.message));
})();
