/* ==========================================================================
   AdrielOS — SHELL
   Barra de tarefas, Menu Iniciar, Pesquisa, Widgets, Configurações rápidas,
   Central de notificações, Visão de Tarefas e menu Win+X.
   ========================================================================== */
(function () {
  'use strict';
  const { $, $$, esc, html, pad } = OS;
  const UI = window.UI, icon = window.icon, DATA = window.DATA;

  const WEEK = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
  const MONTHS = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  OS.WEEK = WEEK; OS.MONTHS = MONTHS;
  OS.fmtTime = (d, sec) => {
    let h = d.getHours(), suf = '';
    if (!OS.settings.clock24) { suf = h >= 12 ? ' PM' : ' AM'; h = h % 12 || 12; }
    return `${OS.settings.clock24 ? pad(h) : h}:${pad(d.getMinutes())}${sec || OS.settings.showSeconds ? ':' + pad(d.getSeconds()) : ''}${suf}`;
  };
  OS.fmtDate = (d) => `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
  OS.longDate = (d) => `${WEEK[d.getDay()]}, ${d.getDate()} de ${MONTHS[d.getMonth()]}`;

  OS.openUrl = (url, title) => OS.openApp('browser', { url, title });
  OS.launch = (it) => {
    if (!it) return;
    if (it.fn) return it.fn();
    if (it.url) return OS.openUrl(it.url);
    if (it.app) { OS.addRecent({ app: it.app, arg: it.arg ? JSON.stringify(it.arg) : '', label: it.label, icon: it.icon }); return OS.openApp(it.app, it.arg || {}); }
  };

  // Estado da bateria (real quando o navegador permite)
  OS.battery = { level: 1, charging: false, real: false };
  if (navigator.getBattery) navigator.getBattery().then((b) => {
    const up = () => { OS.battery = { level: b.level, charging: b.charging, real: true }; renderTray(); };
    b.addEventListener('levelchange', up); b.addEventListener('chargingchange', up); up();
  }).catch(() => { });

  /* ============================ BARRA DE TAREFAS ============================ */
  const taskbar = $('#taskbar');
  taskbar.innerHTML = `
    <div class="tb-left"><button class="tb-btn tb-widgets" id="tb-widgets" data-toggles-panel title="Widgets"><span class="tb-ic">${icon('widgets')}</span><span class="tb-wtxt"><b id="tb-wt-time">--:--</b><small>Widgets</small></span></button></div>
    <div class="tb-center">
      <button class="tb-btn tb-start" id="tb-start" data-toggles-panel title="Iniciar" aria-label="Iniciar"><span class="tb-ic start-logo">${icon('start')}</span></button>
      <button class="tb-search" id="tb-search" data-toggles-panel title="Pesquisar">${UI.search}<span>Pesquisar</span></button>
      <button class="tb-btn tb-taskview" id="tb-taskview" title="Visão de Tarefas">${UI.taskview}</button>
      <div class="tb-apps" id="tb-apps"></div>
    </div>
    <div class="tb-right">
      <button class="tb-btn tb-sys" id="tb-sys" data-toggles-panel title="Configurações rápidas"><span id="tray-wifi"></span><span id="tray-vol"></span><span id="tray-bat"></span></button>
      <button class="tb-btn tb-clock" id="tb-clock" data-toggles-panel title="Calendário e notificações"><span class="tb-clock-txt"><b id="clock-t">--:--</b><small id="clock-d">--/--/----</small></span><span class="tb-bell">${UI.bell}<i id="bell-dot"></i></span></button>
      <button class="tb-desktop" id="tb-desktop" title="Mostrar área de trabalho" aria-label="Mostrar área de trabalho"></button>
    </div>`;

  function renderApps() {
    const box = $('#tb-apps'); if (!box) return;
    const S = OS.settings;
    const ids = S.pinned.filter((id) => OS.apps[id]);
    OS.wins.forEach((w) => { if (!ids.includes(w.appId)) ids.push(w.appId); });
    box.innerHTML = '';
    ids.forEach((id) => {
      const app = OS.apps[id], ws = OS.windowsOf(id);
      const b = html(`<button class="tb-btn tb-app" data-app="${id}" title="${esc(app.title)}"><span class="tb-ic">${icon(app.icon)}</span><i class="ind"></i></button>`);
      if (ws.length) b.classList.add('running');
      if (ws.some((w) => w === OS.wm.active && !w.min)) b.classList.add('active');
      if (ws.length > 1) b.classList.add('multi');
      b.onclick = () => appClick(id);
      b.oncontextmenu = (e) => { e.preventDefault(); appMenu(id, b); };
      box.appendChild(b);
    });
  }
  function appClick(id) {
    OS.closePanels();
    const ws = OS.windowsOf(id);
    if (!ws.length) return OS.openApp(id);
    if (ws.length === 1) {
      const w = ws[0];
      if (w.min) w.restore();
      else if (OS.wm.active === w) w.minimize();
      else w.focus();
      return;
    }
    const b = $(`.tb-app[data-app="${id}"]`), r = b.getBoundingClientRect();
    OS.ctx(r.left, r.top - 4, ws.map((w) => ({ label: w.title, icon: id, action: () => (w.min ? w.restore() : w.focus()) })).concat([{ sep: true }, { label: 'Nova janela', icon: 'plus', action: () => OS.openApp(id, { forceNew: true }) }]), { fromBottom: true });
  }
  function appMenu(id, btn) {
    const app = OS.apps[id], ws = OS.windowsOf(id), r = btn.getBoundingClientRect(), pinned = OS.settings.pinned.includes(id);
    const items = [{ label: app.title, icon: id, action: () => OS.openApp(id) }, { sep: true }];
    items.push({
      label: pinned ? 'Desafixar da barra de tarefas' : 'Fixar na barra de tarefas', icon: 'star',
      action: () => OS.set('pinned', pinned ? OS.settings.pinned.filter((x) => x !== id) : OS.settings.pinned.concat(id))
    });
    if (ws.length) items.push({ label: ws.length > 1 ? 'Fechar todas as janelas' : 'Fechar janela', icon: 'close', action: () => ws.forEach((w) => w.close()) });
    OS.ctx(r.left, r.top - 4, items, { fromBottom: true });
  }
  OS.on('wm', renderApps);
  OS.on('setting', (d) => { if (d.key === 'pinned') renderApps(); });

  $('#tb-start').onclick = () => OS.togglePanel('start');
  $('#tb-start').oncontextmenu = (e) => { e.preventDefault(); winX(e); };
  $('#tb-search').onclick = () => OS.togglePanel('search');
  $('#tb-widgets').onclick = () => OS.togglePanel('widgets');
  $('#tb-sys').onclick = () => OS.togglePanel('quick');
  $('#tb-clock').onclick = () => OS.togglePanel('notif');
  $('#tb-taskview').onclick = () => (taskviewOpen ? OS.closeTaskView() : OS.openTaskView());
  $('#tb-desktop').onclick = () => { OS.closePanels(); OS.showDesktop(); };
  taskbar.addEventListener('contextmenu', (e) => {
    if (e.target.closest('.tb-app, .tb-start')) return;
    e.preventDefault();
    OS.ctx(e.clientX, e.clientY, [
      { label: 'Gerenciador de Tarefas', icon: 'taskmgr', action: () => OS.openApp('taskmgr') },
      { label: 'Configurações da barra de tarefas', icon: 'settings', action: () => OS.openApp('settings', { page: 'taskbar' }) },
      { sep: true },
      { label: 'Mostrar área de trabalho', icon: 'monitor', action: () => OS.showDesktop() }
    ], { fromBottom: true });
  });

  /* --- bandeja & relógio --- */
  function renderTray() {
    const S = OS.settings;
    const wifi = $('#tray-wifi'); if (!wifi) return;
    wifi.innerHTML = S.airplane ? UI.plane : (S.wifi && navigator.onLine !== false ? UI.wifi : UI.wifiOff);
    $('#tray-vol').innerHTML = S.muted || S.volume === 0 ? UI.volumeMute : UI.volume;
    const lvl = Math.round(OS.battery.level * 100);
    $('#tray-bat').innerHTML = UI.battery;
    $('#tray-bat').title = `Bateria: ${lvl}%${OS.battery.charging ? ' (carregando)' : ''}`;
    const rect = $('#tray-bat rect:last-of-type'); if (rect) rect.setAttribute('width', String(Math.max(1, 10 * OS.battery.level)));
  }
  function renderClock() {
    const d = new Date();
    $('#clock-t').textContent = OS.fmtTime(d);
    $('#clock-d').textContent = OS.fmtDate(d);
    const w = $('#tb-wt-time'); if (w) w.textContent = OS.fmtTime(d, false);
    const lt = $('#lock-time'); if (lt) lt.textContent = OS.fmtTime(d, false).replace(/ (AM|PM)/, '');
    const ld = $('#lock-date'); if (ld) ld.textContent = OS.longDate(d);
    const bt = $('#bell-dot'); if (bt) bt.style.display = OS.notifications.length && !OS.panelOpen('notif') ? 'block' : 'none';
  }
  setInterval(renderClock, 1000);
  OS.on('setting', (d) => { if (['wifi', 'airplane', 'muted', 'volume'].includes(d.key)) renderTray(); renderClock(); });
  OS.on('notifications', renderClock);
  window.addEventListener('online', renderTray); window.addEventListener('offline', renderTray);
  OS.initTaskbar = () => { renderApps(); renderTray(); renderClock(); };

  /* ============================== MENU INICIAR ============================== */
  const START_PINS = ['about', 'explorer', 'browser', 'skills', 'github', 'contact', 'terminal', 'notepad', 'calc', 'photos', 'paint', 'mines', 'snake', 'music', 'taskmgr', 'settings', 'trash', 'pdf'];
  const start = html(`<div id="start" class="start" aria-label="Menu Iniciar">
    <div class="start-main">
      <button class="start-search" id="start-search">${UI.search}<span>Pesquisar aplicativos, configurações e documentos</span></button>
      <div class="start-view" data-view="pinned">
        <div class="sec-head"><h3>Fixados</h3><button class="chip-btn" id="start-all">Todos os aplicativos ${UI.chevronRight}</button></div>
        <div class="pin-grid" id="pin-grid"></div>
        <div class="sec-head"><h3>Recomendados</h3><button class="chip-btn" id="start-more">Mais ${UI.chevronRight}</button></div>
        <div class="rec-grid" id="rec-grid"></div>
      </div>
      <div class="start-view" data-view="all" hidden>
        <div class="sec-head"><button class="chip-btn" id="start-back">${UI.chevronLeft} Voltar</button><h3>Todos os aplicativos</h3></div>
        <div class="all-list" id="all-list"></div>
      </div>
    </div>
    <div class="start-foot">
      <button class="user-btn" id="start-user"><span id="start-avatar"></span><span class="user-name">${esc(OS.profile.name)}</span></button>
      <button class="pw-btn" id="start-power" title="Energia" aria-label="Energia">${UI.power}</button>
    </div></div>`);
  $('#panels').appendChild(start);
  OS.registerPanel('start', start, { onOpen: () => { renderStart(); showStartView('pinned'); } });

  function appTile(id) {
    const a = OS.apps[id];
    const b = html(`<button class="pin-item" title="${esc(a.title)}"><span class="pin-ic">${icon(a.icon)}</span><span class="pin-t">${esc(a.short || a.title)}</span></button>`);
    b.onclick = () => OS.launch({ app: id, label: a.title, icon: a.icon });
    b.oncontextmenu = (e) => {
      e.preventDefault(); e.stopPropagation();
      const pinned = OS.settings.pinned.includes(id);
      OS.ctx(e.clientX, e.clientY, [
        { label: 'Abrir', icon: 'open', action: () => OS.openApp(id) },
        { label: pinned ? 'Desafixar da barra de tarefas' : 'Fixar na barra de tarefas', icon: 'star', action: () => OS.set('pinned', pinned ? OS.settings.pinned.filter((x) => x !== id) : OS.settings.pinned.concat(id)) }
      ]);
    };
    return b;
  }
  function renderStart() {
    $('#start-avatar').innerHTML = OS.avatarHTML('sm');
    $('.user-name', start).textContent = OS.profile.name;
    const pg = $('#pin-grid'); pg.innerHTML = '';
    START_PINS.filter((id) => OS.apps[id]).forEach((id) => pg.appendChild(appTile(id)));
    const rg = $('#rec-grid'); rg.innerHTML = '';
    const rec = OS.recent.slice(0, 6).map((r) => ({ icon: r.icon || 'folder', title: r.label || r.app, sub: 'Aberto recentemente', run: () => OS.launch({ app: r.app, arg: r.arg ? JSON.parse(r.arg) : null }) }));
    const defaults = DATA.projects.filter((p) => !p.future).map((p) => ({ img: p.image, title: p.short, sub: 'Projeto · ' + p.kind, run: () => (p.site ? OS.openUrl(p.site, p.short) : OS.openApp('pdf', { src: p.pdf, title: p.short })) }));
    defaults.concat([{ icon: 'txt', title: 'leia-me.txt', sub: 'Documento', run: () => OS.openApp('notepad', { file: 'leia-me.txt' }) }]).forEach((d) => { if (rec.length < 6 && !rec.some((r) => r.title === d.title)) rec.push(d); });
    rec.slice(0, 6).forEach((r) => {
      const b = html(`<button class="rec-item"><span class="rec-ic">${r.img ? `<img src="${r.img}" alt="">` : icon(r.icon)}</span><span class="rec-t"><b>${esc(r.title)}</b><small>${esc(r.sub)}</small></span></button>`);
      b.onclick = () => { OS.closePanels(); r.run(); };
      rg.appendChild(b);
    });
    // todos os apps
    const all = Object.values(OS.apps).filter((a) => !a.hidden).sort((a, b) => a.title.localeCompare(b.title, 'pt-BR'));
    const list = $('#all-list'); list.innerHTML = ''; let cur = '';
    all.forEach((a) => {
      const L = a.title[0].toUpperCase();
      if (L !== cur) { cur = L; list.appendChild(html(`<div class="all-letter">${L}</div>`)); }
      const b = html(`<button class="all-item"><span class="all-ic">${icon(a.icon)}</span><span>${esc(a.title)}</span></button>`);
      b.onclick = () => OS.launch({ app: a.id, label: a.title, icon: a.icon });
      list.appendChild(b);
    });
  }
  function showStartView(v) { $$('.start-view', start).forEach((x) => (x.hidden = x.dataset.view !== v)); }
  $('#start-all').onclick = () => showStartView('all');
  $('#start-back').onclick = () => showStartView('pinned');
  $('#start-more').onclick = () => { OS.closePanels(); OS.openApp('explorer', { path: 'Projetos' }); };
  $('#start-search').onclick = () => OS.openPanel('search');
  $('#start-user').onclick = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    OS.ctx(r.left, r.top - 4, [
      { label: 'Alterar configurações da conta', icon: 'user', action: () => OS.openApp('settings', { page: 'accounts' }) },
      { label: 'Bloquear', icon: 'lock', action: () => OS.session.lock() },
      { label: 'Sair', icon: 'user', action: () => OS.session.signOut() }
    ], { fromBottom: true });
  };
  $('#start-power').onclick = (e) => { const r = e.currentTarget.getBoundingClientRect(); OS.ctx(r.right - 190, r.top - 4, powerItems(), { fromBottom: true }); };
  function powerItems() {
    return [
      { label: 'Suspender', icon: 'sleep', action: () => OS.session.sleep() },
      { label: 'Desligar', icon: 'power', action: () => OS.session.shutdown() },
      { label: 'Reiniciar', icon: 'restart', action: () => OS.session.restart() }
    ];
  }
  OS.powerItems = powerItems;
  OS.on('profile', () => { if (OS.panelOpen('start')) renderStart(); });

  /* ================================ PESQUISA ================================ */
  const searchEl = html(`<div id="search" class="searchp" aria-label="Pesquisar">
    <div class="sp-top"><div class="sp-box">${UI.search}<input id="sp-input" type="text" placeholder="Digite aqui para pesquisar" autocomplete="off" spellcheck="false"></div>
      <div class="sp-tabs"><button class="on" data-f="all">Tudo</button><button data-f="app">Aplicativos</button><button data-f="file">Documentos</button><button data-f="project">Projetos</button><button data-f="setting">Configurações</button></div></div>
    <div class="sp-body"><div class="sp-list" id="sp-list"></div><div class="sp-prev" id="sp-prev"></div></div></div>`);
  $('#panels').appendChild(searchEl);
  let spFilter = 'all', spResults = [], spSel = 0;
  OS.registerPanel('search', searchEl, { onOpen: (q) => { const i = $('#sp-input'); if (typeof q === 'string') i.value = q; i.focus(); i.select(); runSearch(); } });

  function norm(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase(); }
  function searchIndex() {
    const out = [];
    Object.values(OS.apps).filter((a) => !a.hidden).forEach((a) => out.push({ type: 'app', title: a.title, sub: 'Aplicativo', icon: a.icon, kw: a.keywords + ' ' + a.title, run: () => OS.launch({ app: a.id, label: a.title, icon: a.icon }), open: 'Abrir' }));
    DATA.projects.forEach((p) => out.push({ type: 'project', title: p.short, sub: 'Projeto · ' + p.kind, img: p.image, kw: p.name + ' ' + p.tags.join(' ') + ' ' + p.desc, desc: p.desc,
      run: () => (p.site ? OS.openUrl(p.site, p.short) : p.pdf ? OS.openApp('pdf', { src: p.pdf, title: p.short }) : OS.openApp('explorer', { path: 'Projetos' })), open: p.site ? 'Abrir site' : p.pdf ? 'Abrir PDF' : 'Abrir pasta',
      extra: p.repo ? [{ label: 'GitHub', fn: () => window.open(p.repo, '_blank', 'noopener') }] : [] }));
    if (OS.vfs) OS.vfs.walk().forEach((f) => { if (f.type === 'file') out.push({ type: 'file', title: f.name, sub: 'Documento · ' + (f.path || ''), icon: f.icon || 'txt', kw: f.name, run: () => OS.vfs.open(f), open: 'Abrir' }); });
    (OS.settingsPages || []).forEach((s) => out.push({ type: 'setting', title: s.title, sub: 'Configurações · ' + (s.group || 'Sistema'), icon: 'settings', kw: s.title + ' ' + (s.kw || ''), run: () => OS.openApp('settings', { page: s.id }), open: 'Abrir' }));
    return out;
  }
  function runSearch() {
    const q = norm($('#sp-input').value.trim());
    const idx = searchIndex();
    let res;
    if (!q) {
      res = [];
      OS.recent.slice(0, 4).forEach((r) => res.push({ type: 'app', group: 'Recentes', title: r.label || r.app, sub: 'Aberto recentemente', icon: r.icon || 'folder', run: () => OS.launch({ app: r.app, arg: r.arg ? JSON.parse(r.arg) : null }), open: 'Abrir' }));
      ['about', 'explorer', 'github', 'contact', 'terminal', 'settings'].forEach((id) => { const a = OS.apps[id]; if (a) res.push({ type: 'app', group: 'Principais aplicativos', title: a.title, sub: 'Aplicativo', icon: a.icon, run: () => OS.launch({ app: id, label: a.title, icon: a.icon }), open: 'Abrir' }); });
    } else {
      res = idx.map((it) => {
        const t = norm(it.title), k = norm(it.kw);
        let score = 0;
        if (t === q) score = 100; else if (t.startsWith(q)) score = 80; else if (t.split(/\s+/).some((w) => w.startsWith(q))) score = 65; else if (t.includes(q)) score = 50; else if (k.includes(q)) score = 25;
        return score ? Object.assign({ score }, it) : null;
      }).filter(Boolean).sort((a, b) => b.score - a.score).slice(0, 24);
      res.push({ type: 'web', group: 'Pesquisar na web', title: `Pesquisar “${$('#sp-input').value.trim()}” na web`, sub: 'Abre o DuckDuckGo em uma nova aba', icon: 'browser', run: () => window.open('https://duckduckgo.com/?q=' + encodeURIComponent($('#sp-input').value.trim()), '_blank', 'noopener'), open: 'Abrir' });
    }
    if (spFilter !== 'all') res = res.filter((r) => r.type === spFilter);
    spResults = res; spSel = 0; drawSearch();
  }
  const TYPE_LABEL = { app: 'Aplicativos', file: 'Documentos', project: 'Projetos', setting: 'Configurações', web: 'Pesquisar na web' };
  function drawSearch() {
    const list = $('#sp-list'); list.innerHTML = '';
    if (!spResults.length) { list.innerHTML = '<div class="sp-empty">Nenhum resultado encontrado.<br><small>Tente “projetos”, “github”, “wallpaper” ou “calculadora”.</small></div>'; $('#sp-prev').innerHTML = ''; return; }
    let last = '';
    spResults.forEach((r, i) => {
      const g = r.group || TYPE_LABEL[r.type];
      if (g !== last) { last = g; list.appendChild(html(`<div class="sp-group">${g}</div>`)); }
      const b = html(`<button class="sp-item ${i === spSel ? 'sel' : ''}" data-i="${i}"><span class="sp-ic">${r.img ? `<img src="${r.img}" alt="">` : icon(r.icon)}</span><span class="sp-t"><b>${esc(r.title)}</b><small>${esc(r.sub)}</small></span></button>`);
      b.onclick = () => { spSel = i; drawSearch(); };
      b.ondblclick = () => runItem(r);
      list.appendChild(b);
    });
    drawPrev();
  }
  function drawPrev() {
    const r = spResults[spSel], p = $('#sp-prev'); if (!r) return;
    p.innerHTML = `<div class="spv-ic">${r.img ? `<img src="${r.img}" alt="">` : icon(r.icon)}</div><h3>${esc(r.title)}</h3><p class="spv-sub">${esc(r.sub)}</p>${r.desc ? `<p class="spv-desc">${esc(r.desc.slice(0, 180))}${r.desc.length > 180 ? '…' : ''}</p>` : ''}
      <div class="spv-actions"><button class="btn primary" id="spv-open">${esc(r.open || 'Abrir')}</button>${(r.extra || []).map((e, i) => `<button class="btn" data-x="${i}">${esc(e.label)}</button>`).join('')}</div>`;
    $('#spv-open').onclick = () => runItem(r);
    $$('[data-x]', p).forEach((b) => (b.onclick = () => r.extra[b.dataset.x].fn()));
  }
  function runItem(r) { OS.closePanels(); r.run(); }
  $('#sp-input').addEventListener('input', runSearch);
  $('#sp-input').addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); spSel = Math.min(spResults.length - 1, spSel + 1); drawSearch(); const s = $('.sp-item.sel'); s && s.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); spSel = Math.max(0, spSel - 1); drawSearch(); const s = $('.sp-item.sel'); s && s.scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'Enter' && spResults[spSel]) runItem(spResults[spSel]);
  });
  $$('.sp-tabs button', searchEl).forEach((b) => (b.onclick = () => { $$('.sp-tabs button', searchEl).forEach((x) => x.classList.toggle('on', x === b)); spFilter = b.dataset.f; runSearch(); $('#sp-input').focus(); }));

  /* ================================ WIDGETS ================================= */
  const widgets = html(`<div id="widgets" class="widgetsp" aria-label="Widgets">
    <div class="wd-head"><div><h2 id="wd-greet">Olá</h2><p id="wd-date"></p></div><button class="wd-x" id="wd-close" aria-label="Fechar">${UI.close}</button></div>
    <div class="wd-grid">
      <div class="wd-card wd-clock"><svg viewBox="0 0 100 100" id="wd-analog"><circle cx="50" cy="50" r="46" class="cf"/><g class="ticks"></g><line id="h-h" x1="50" y1="50" x2="50" y2="26" class="hh"/><line id="h-m" x1="50" y1="50" x2="50" y2="16" class="hm"/><line id="h-s" x1="50" y1="56" x2="50" y2="12" class="hs"/><circle cx="50" cy="50" r="2.6" class="hc"/></svg><div><b id="wd-time">--:--</b><small id="wd-tz">Horário local</small></div></div>
      <div class="wd-card wd-pomo"><h4>${UI.clock} Foco (Pomodoro)</h4><div class="pomo-t" id="pomo-t">25:00</div><div class="pomo-b"><button class="btn primary" id="pomo-go">Iniciar</button><button class="btn" id="pomo-reset">Zerar</button></div><small id="pomo-state">Sessão de estudo de 25 min</small></div>
      <div class="wd-card wd-proj"><h4>${UI.star} Projeto em destaque</h4><div id="wd-featured"></div></div>
      <div class="wd-card wd-quote"><h4>${icon('soccer')} Jogada do dia</h4><p id="wd-quote"></p></div>
      <div class="wd-card wd-note"><h4>${UI.pencil} Nota rápida</h4><textarea id="wd-note" placeholder="Escreva algo… fica salvo neste navegador." rows="4"></textarea></div>
      <div class="wd-card wd-tip"><h4>${UI.info} Dica de código</h4><div id="wd-tip"></div></div>
      <div class="wd-card wd-stats"><h4>${icon('taskmgr')} Sua sessão</h4><div class="stats" id="wd-stats"></div></div>
      <div class="wd-card wd-links"><h4>${UI.external} Atalhos</h4><div class="chips"><button data-go="projects">Projetos</button><button data-go="github">GitHub</button><button data-go="contact">Contato</button><button data-go="wall">Wallpapers</button></div></div>
    </div></div>`);
  $('#panels').appendChild(widgets);
  let wdTimer = null, pomo = { left: 25 * 60, run: false, int: null };
  const ticks = $('.ticks', widgets); for (let i = 0; i < 12; i++) { const a = i * 30; ticks.innerHTML += `<line x1="50" y1="9" x2="50" y2="${i % 3 ? 12 : 15}" transform="rotate(${a} 50 50)"/>`; }
  function wdRefresh() {
    const d = new Date(), h = d.getHours();
    $('#wd-greet').textContent = (h < 5 ? 'Boa madrugada' : h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite') + ', visitante!';
    $('#wd-date').textContent = OS.longDate(d).replace(/^./, (c) => c.toUpperCase()) + ' de ' + d.getFullYear();
    $('#wd-time').textContent = OS.fmtTime(d, true);
    $('#h-h').setAttribute('transform', `rotate(${(h % 12) * 30 + d.getMinutes() * 0.5} 50 50)`);
    $('#h-m').setAttribute('transform', `rotate(${d.getMinutes() * 6} 50 50)`);
    $('#h-s').setAttribute('transform', `rotate(${d.getSeconds() * 6} 50 50)`);
    const up = Math.floor((Date.now() - OS.bootedAt) / 1000);
    $('#wd-stats').innerHTML = `<div><b>${OS.wins.length}</b><small>janelas abertas</small></div><div><b>${OS.opened}</b><small>apps abertos</small></div><div><b>${Math.floor(up / 60)}:${pad(up % 60)}</b><small>tempo de sessão</small></div>`;
  }
  function pomoDraw() { $('#pomo-t').textContent = `${pad(Math.floor(pomo.left / 60))}:${pad(pomo.left % 60)}`; $('#pomo-go').textContent = pomo.run ? 'Pausar' : (pomo.left < 25 * 60 ? 'Continuar' : 'Iniciar'); }
  $('#pomo-go').onclick = () => {
    if (pomo.run) { clearInterval(pomo.int); pomo.run = false; }
    else { pomo.run = true; pomo.int = setInterval(() => { pomo.left--; if (pomo.left <= 0) { clearInterval(pomo.int); pomo.run = false; pomo.left = 25 * 60; OS.notify({ title: 'Sessão de foco concluída!', body: 'Hora de uma pausa de 5 minutos. 💪', icon: 'about', force: true, app: 'Foco' }); } pomoDraw(); }, 1000); }
    pomoDraw();
  };
  $('#pomo-reset').onclick = () => { clearInterval(pomo.int); pomo.run = false; pomo.left = 25 * 60; pomoDraw(); };
  const note = $('#wd-note'); note.value = OS.store.get('quicknote', ''); note.oninput = () => OS.store.set('quicknote', note.value);
  $('#wd-close').onclick = () => OS.closePanel('widgets');
  $$('[data-go]', widgets).forEach((b) => (b.onclick = () => { OS.closePanels(); ({ projects: () => OS.openApp('explorer', { path: 'Projetos' }), github: () => OS.openApp('github'), contact: () => OS.openApp('contact'), wall: () => OS.openApp('settings', { page: 'background' }) })[b.dataset.go](); }));
  OS.registerPanel('widgets', widgets, {
    onOpen: () => {
      wdRefresh(); clearInterval(wdTimer); wdTimer = setInterval(wdRefresh, 1000); pomoDraw();
      const day = Math.floor(Date.now() / 864e5);
      $('#wd-quote').textContent = DATA.quotes[day % DATA.quotes.length];
      const t = DATA.tips[day % DATA.tips.length]; $('#wd-tip').innerHTML = `<span class="tag">${t[0]}</span><p>${t[1]}</p>`;
      const fp = DATA.projects.filter((p) => !p.future)[day % 4];
      $('#wd-featured').innerHTML = `<button class="feat"><img src="${fp.image}" alt=""><span><b>${esc(fp.short)}</b><small>${esc(fp.badge)}</small></span></button>`;
      $('.feat', widgets).onclick = () => { OS.closePanels(); fp.site ? OS.openUrl(fp.site, fp.short) : OS.openApp('pdf', { src: fp.pdf, title: fp.short }); };
    }, onClose: () => clearInterval(wdTimer)
  });

  /* ======================= CONFIGURAÇÕES RÁPIDAS ============================ */
  const quick = html(`<div id="quick" class="quickp" aria-label="Configurações rápidas">
    <div class="q-tiles" id="q-tiles"></div>
    <div class="q-slider"><span>${UI.sun}</span><input type="range" id="q-bright" min="20" max="100" aria-label="Brilho"></div>
    <div class="q-slider"><button id="q-mute" aria-label="Silenciar"></button><input type="range" id="q-vol" min="0" max="100" aria-label="Volume"></div>
    <div class="q-foot"><span id="q-bat"></span><button class="q-gear" id="q-gear" title="Configurações">${UI.settings || icon('settings')}</button><button class="q-gear" id="q-power" title="Energia">${UI.power}</button></div></div>`);
  $('#panels').appendChild(quick);
  const Q_TILES = [
    { k: 'wifi', t: 'Wi-Fi', sub: () => (OS.settings.wifi && !OS.settings.airplane ? 'AdrielNet' : 'Desligado'), i: 'wifi', dis: () => OS.settings.airplane },
    { k: 'bluetooth', t: 'Bluetooth', sub: () => (OS.settings.bluetooth && !OS.settings.airplane ? 'Ligado' : 'Desligado'), i: 'bluetooth', dis: () => OS.settings.airplane },
    { k: 'airplane', t: 'Modo avião', sub: () => (OS.settings.airplane ? 'Ligado' : 'Desligado'), i: 'plane' },
    { k: 'saver', t: 'Economia de bateria', sub: () => (OS.settings.saver ? 'Ligada' : 'Desligada'), i: 'battery' },
    { k: 'focus', t: 'Não perturbe', sub: () => (OS.settings.focus ? 'Ativado' : 'Desativado'), i: 'bellOff' },
    { k: 'theme', t: 'Tema escuro', sub: () => (OS.isDark() ? 'Escuro' : 'Claro'), i: 'moon', special: true }
  ];
  function drawQuick() {
    const box = $('#q-tiles'); box.innerHTML = '';
    Q_TILES.forEach((t) => {
      const on = t.k === 'theme' ? OS.isDark() : !!OS.settings[t.k];
      const b = html(`<button class="q-tile ${on ? 'on' : ''}"><span class="q-ic">${UI[t.i]}</span><span class="q-t"><b>${t.t}</b><small>${t.sub()}</small></span></button>`);
      b.onclick = () => {
        if (t.k === 'theme') OS.set('theme', OS.isDark() ? 'light' : 'dark');
        else OS.set(t.k, !OS.settings[t.k]);
        OS.sound('click'); drawQuick();
      };
      box.appendChild(b);
    });
    $('#q-bright').value = OS.settings.brightness; $('#q-vol').value = OS.settings.muted ? 0 : OS.settings.volume;
    $('#q-mute').innerHTML = OS.settings.muted || OS.settings.volume === 0 ? UI.volumeMute : UI.volume;
    $('#q-bat').innerHTML = `${UI.battery} <b>${Math.round(OS.battery.level * 100)}%</b>${OS.battery.charging ? ' · carregando' : ''}`;
  }
  $('#q-bright').oninput = (e) => OS.set('brightness', +e.target.value);
  $('#q-vol').oninput = (e) => { OS.set('volume', +e.target.value); OS.set('muted', +e.target.value === 0); renderTray(); };
  $('#q-vol').onchange = () => OS.sound('click');
  $('#q-mute').onclick = () => { OS.set('muted', !OS.settings.muted); drawQuick(); };
  $('#q-gear').onclick = () => { OS.closePanels(); OS.openApp('settings'); };
  $('#q-power').onclick = (e) => { const r = e.currentTarget.getBoundingClientRect(); OS.ctx(r.right - 190, r.top - 4, powerItems(), { fromBottom: true }); };
  OS.registerPanel('quick', quick, { onOpen: drawQuick });

  /* ===================== CENTRAL DE NOTIFICAÇÕES + CALENDÁRIO ================== */
  const notif = html(`<div id="notif" class="notifp" aria-label="Central de notificações">
    <div class="np-head"><h3>Notificações</h3><button class="chip-btn" id="np-clear">Limpar tudo</button></div>
    <div class="np-list" id="np-list"></div>
    <div class="np-cal"><div class="cal-head"><b id="cal-title"></b><div><button id="cal-prev" aria-label="Mês anterior">${UI.chevronUp}</button><button id="cal-next" aria-label="Próximo mês">${UI.chevronDown}</button></div></div>
    <div class="cal-grid" id="cal-grid"></div>
    <div class="np-focus"><span>${UI.bellOff} Não perturbe</span><button class="switch" id="np-focus" role="switch" aria-label="Não perturbe"><i></i></button></div></div></div>`);
  $('#panels').appendChild(notif);
  let calM = new Date();
  function drawNotif() {
    const list = $('#np-list'); list.innerHTML = '';
    if (!OS.notifications.length) list.innerHTML = `<div class="np-empty">${UI.bell}<span>Nenhuma notificação nova</span></div>`;
    OS.notifications.forEach((n) => {
      const el = html(`<div class="np-item"><div class="np-app">${icon(n.icon)}<span>${esc(n.app)}</span><small>${OS.fmtTime(n.time)}</small><button aria-label="Dispensar">${UI.close}</button></div><b>${esc(n.title)}</b>${n.body ? `<p>${esc(n.body)}</p>` : ''}</div>`);
      $('button', el).onclick = () => { OS.notifications = OS.notifications.filter((x) => x !== n); drawNotif(); OS.emit('notifications'); };
      list.appendChild(el);
    });
    $('#np-focus').classList.toggle('on', !!OS.settings.focus);
    drawCal();
  }
  function drawCal() {
    const y = calM.getFullYear(), m = calM.getMonth(), now = new Date();
    $('#cal-title').textContent = `${MONTHS[m][0].toUpperCase() + MONTHS[m].slice(1)} de ${y}`;
    const g = $('#cal-grid'); g.innerHTML = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((d) => `<span class="dow">${d}</span>`).join('');
    const first = new Date(y, m, 1).getDay(), dim = new Date(y, m + 1, 0).getDate(), prevDim = new Date(y, m, 0).getDate();
    for (let i = 0; i < 42; i++) {
      let d, cls = '';
      if (i < first) { d = prevDim - first + i + 1; cls = 'dim'; } else if (i >= first + dim) { d = i - first - dim + 1; cls = 'dim'; } else { d = i - first + 1; if (d === now.getDate() && m === now.getMonth() && y === now.getFullYear()) cls = 'today'; }
      g.innerHTML += `<span class="day ${cls}">${d}</span>`;
    }
  }
  $('#cal-prev').onclick = () => { calM = new Date(calM.getFullYear(), calM.getMonth() - 1, 1); drawCal(); };
  $('#cal-next').onclick = () => { calM = new Date(calM.getFullYear(), calM.getMonth() + 1, 1); drawCal(); };
  $('#np-clear').onclick = () => { OS.notifications = []; drawNotif(); OS.emit('notifications'); };
  $('#np-focus').onclick = () => { OS.set('focus', !OS.settings.focus); drawNotif(); };
  OS.registerPanel('notif', notif, { onOpen: () => { calM = new Date(); drawNotif(); renderClock(); } });
  OS.on('notifications', () => { if (OS.panelOpen('notif')) drawNotif(); });

  /* ============================ VISÃO DE TAREFAS ============================ */
  const tv = html('<div id="taskview" class="taskview" hidden><div class="tv-inner"><div class="tv-grid" id="tv-grid"></div></div></div>');
  document.body.appendChild(tv);
  let taskviewOpen = false;
  OS.openTaskView = () => {
    OS.closePanels(); taskviewOpen = true; tv.hidden = false; drawTV();
    requestAnimationFrame(() => tv.classList.add('open'));
  };
  OS.closeTaskView = () => { if (!taskviewOpen) return; taskviewOpen = false; tv.classList.remove('open'); setTimeout(() => { if (!taskviewOpen) tv.hidden = true; }, 180); };
  function drawTV() {
    const g = $('#tv-grid'); g.innerHTML = '';
    if (!OS.wins.length) { g.innerHTML = `<div class="tv-empty">${UI.taskview}<b>Nenhuma janela aberta</b><span>Abra um aplicativo no menu Iniciar.</span></div>`; return; }
    OS.wins.slice().reverse().forEach((w) => {
      const c = html(`<div class="tv-card" tabindex="0"><div class="tv-bar">${icon(w.iconName || w.app.icon)}<span>${esc(w.title)}</span><button aria-label="Fechar janela">${UI.close}</button></div><div class="tv-thumb">${icon(w.iconName || w.app.icon)}</div></div>`);
      c.onclick = (e) => { if (e.target.closest('button')) { w.close(); setTimeout(drawTV, 200); return; } OS.closeTaskView(); w.min && w.restore(); w.focus(); };
      g.appendChild(c);
    });
  }
  tv.addEventListener('pointerdown', (e) => { if (e.target === tv || e.target.id === 'tv-grid' || e.target.classList.contains('tv-inner')) OS.closeTaskView(); });
  OS.on('wm', () => { if (taskviewOpen) drawTV(); });

  /* ================================ MENU WIN+X ============================== */
  function winX(e) {
    const r = $('#tb-start').getBoundingClientRect();
    OS.closePanels();
    OS.ctx(r.left, r.top - 4, [
      { label: 'Aplicativos e Recursos', icon: 'taskmgr', action: () => OS.openApp('taskmgr') },
      { label: 'Gerenciador de Tarefas', icon: 'taskmgr', action: () => OS.openApp('taskmgr') },
      { label: 'Configurações', icon: 'settings', action: () => OS.openApp('settings') },
      { label: 'Explorador de Arquivos', icon: 'explorer', action: () => OS.openApp('explorer') },
      { label: 'Pesquisar', icon: 'search', action: () => OS.openPanel('search') },
      { label: 'Executar', icon: 'run', action: () => OS.openApp('run') },
      { sep: true },
      { label: 'Terminal', icon: 'terminal', action: () => OS.openApp('terminal') },
      { sep: true },
      { label: 'Desligar ou sair', icon: 'power', submenu: [{ label: 'Bloquear', icon: 'lock', action: () => OS.session.lock() }, { label: 'Suspender', icon: 'sleep', action: () => OS.session.sleep() }, { label: 'Desligar', icon: 'power', action: () => OS.session.shutdown() }, { label: 'Reiniciar', icon: 'restart', action: () => OS.session.restart() }] },
      { label: 'Área de Trabalho', icon: 'monitor', action: () => OS.showDesktop() }
    ], { fromBottom: true });
    void e;
  }
})();
