/* ==========================================================================
   AdrielOS — FERRAMENTAS, JOGOS E MÍDIA
   Bloco de Notas, Calculadora, Terminal, Fotos, Paint, Campo Minado,
   Snake, Gerenciador de Tarefas e Rádio AdrielOS.
   ========================================================================== */
(function () {
  'use strict';
  const { $, $$, esc, html, clamp, pad } = OS;
  const UI = window.UI, icon = window.icon, DATA = window.DATA;

  /* ================================ BLOCO DE NOTAS ================================ */
  OS.registerApp({
    id: 'notepad', title: 'Bloco de Notas', icon: 'notepad', w: 640, h: 460, keywords: 'bloco de notas notepad texto anotações txt',
    build(win, opts) {
      const docs = () => OS.store.get('docs', {});
      let name = opts.file || 'Sem título', dirty = false, wrap = true, size = 14;
      let text = opts.content != null ? opts.content : (docs()[name] != null ? docs()[name] : '');
      const root = html(`<div class="np"><div class="np-menu"><button data-m="new">Novo</button><button data-m="open">Abrir</button><button data-m="save">Salvar</button><button data-m="saveas">Salvar como</button><button data-m="dl">Baixar .txt</button><i></i><button data-m="date">Hora/Data</button><button data-m="wrap">Quebra de linha</button><button data-m="zi">A+</button><button data-m="zo">A−</button></div><textarea class="np-ta" spellcheck="false"></textarea><div class="np-status"><span id="np-pos">Ln 1, Col 1</span><span id="np-len">0 caracteres</span><span>UTF-8</span></div></div>`);
      win.body.appendChild(root);
      const ta = $('.np-ta', root); ta.value = text;
      const title = () => win.setTitle(`${dirty ? '*' : ''}${name} — Bloco de Notas`);
      const stat = () => { const v = ta.value.slice(0, ta.selectionStart).split('\n'); $('#np-pos', root).textContent = `Ln ${v.length}, Col ${v[v.length - 1].length + 1}`; $('#np-len', root).textContent = `${ta.value.length} caracteres`; };
      ta.oninput = () => { dirty = true; title(); stat(); }; ta.onkeyup = ta.onclick = stat;
      ta.onkeydown = (e) => { if (e.ctrlKey && e.key.toLowerCase() === 's') { e.preventDefault(); save(); } if (e.key === 'Tab') { e.preventDefault(); document.execCommand('insertText', false, '  '); } };
      const readonly = opts.content != null && !opts.desk && !(docs()[name] != null);
      async function save(as) {
        let n = name;
        if (as || n === 'Sem título' || readonly) { n = await OS.prompt('Salvar como', 'Nome do arquivo:', name === 'Sem título' ? 'anotacao.txt' : name); if (!n) return; n = n.trim(); if (!/\.\w+$/.test(n)) n += '.txt'; }
        const d = docs(); d[n] = ta.value; OS.store.set('docs', d); name = n; dirty = false; title(); OS.emit('docs'); OS.toast(`“${n}” salvo em Documentos.`, 'notepad');
      }
      root.addEventListener('click', async (e) => {
        const b = e.target.closest('[data-m]'); if (!b) return; const m = b.dataset.m;
        if (m === 'new') { if (dirty && !(await OS.confirm('Bloco de Notas', 'Descartar as alterações não salvas?'))) return; name = 'Sem título'; ta.value = ''; dirty = false; title(); stat(); }
        else if (m === 'open') { const names = Object.keys(docs()); if (!names.length) { OS.toast('Nenhum documento salvo ainda.', 'notepad'); return; } const r = b.getBoundingClientRect(); OS.ctx(r.left, r.bottom, names.map((n) => ({ label: n, icon: 'txt', action: () => { name = n; ta.value = docs()[n]; dirty = false; title(); stat(); } }))); }
        else if (m === 'save') save(); else if (m === 'saveas') save(true);
        else if (m === 'dl') OS.download(name.endsWith('.txt') ? name : name + '.txt', ta.value);
        else if (m === 'date') { document.execCommand('insertText', false, new Date().toLocaleString('pt-BR')); }
        else if (m === 'wrap') { wrap = !wrap; ta.style.whiteSpace = wrap ? 'pre-wrap' : 'pre'; ta.wrap = wrap ? 'soft' : 'off'; }
        else if (m === 'zi' || m === 'zo') { size = clamp(size + (m === 'zi' ? 2 : -2), 9, 32); ta.style.fontSize = size + 'px'; }
      });
      win.onClose(() => { if (dirty) { OS.confirm('Bloco de Notas', `Deseja salvar as alterações em ${esc(name)}?`, 'Salvar', 'Não salvar').then(async (s) => { if (s) await save(); dirty = false; win.close(); }); return false; } });
      title(); stat(); setTimeout(() => ta.focus(), 60);
    }
  });

  /* ================================ CALCULADORA ================================ */
  OS.calcEval = (s) => {
    const t = s.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/,/g, '.').replace(/\^/g, '**').replace(/\s+/g, '');
    if (!/^[0-9+\-*/().%e*]+$/.test(t.replace(/sqrt|pi/g, ''))) throw new Error('inválido');
    const tk = t.match(/\*\*|\d+\.?\d*(?:e[+-]?\d+)?|\.\d+|[()+\-*/%]/g) || []; let i = 0;
    const peek = () => tk[i], next = () => tk[i++];
    function prim() { const x = next(); if (x === '(') { const v = add(); next(); return v; } if (x === '-') return -prim(); if (x === '+') return prim(); const n = parseFloat(x); if (isNaN(n)) throw new Error('inválido'); return n; }
    function pw() { let v = prim(); while (peek() === '**') { next(); v = Math.pow(v, pw()); } return v; }
    function mul() { let v = pw(); while (['*', '/', '%'].includes(peek())) { const o = next(), r = pw(); v = o === '*' ? v * r : o === '/' ? v / r : v % r; } return v; }
    function add() { let v = mul(); while (['+', '-'].includes(peek())) { const o = next(), r = mul(); v = o === '+' ? v + r : v - r; } return v; }
    const v = add(); if (i < tk.length) throw new Error('inválido'); return v;
  };
  OS.registerApp({
    id: 'calc', title: 'Calculadora', icon: 'calc', w: 340, h: 520, minW: 300, minH: 460, keywords: 'calculadora calc contas matemática',
    build(win) {
      let expr = '', res = '0', fresh = false;
      const keys = ['%', 'CE', 'C', '⌫', '1/x', 'x²', '√x', '÷', '7', '8', '9', '×', '4', '5', '6', '−', '1', '2', '3', '+', '±', '0', ',', '='];
      const root = html(`<div class="calc"><div class="c-disp"><small id="c-ex"></small><b id="c-res">0</b></div><div class="c-keys">${keys.map((k) => `<button class="k ${/\d|,/.test(k) ? 'num' : k === '=' ? 'eq' : ''}" data-k="${k}">${k}</button>`).join('')}</div></div>`);
      win.body.appendChild(root);
      const show = () => { $('#c-ex', root).textContent = expr; $('#c-res', root).textContent = res; };
      const fmt = (n) => (isFinite(n) ? String(+n.toPrecision(12)).replace('.', ',') : 'Erro');
      const press = (k) => {
        if (/^\d$/.test(k) || k === ',') { if (fresh) { res = '0'; fresh = false; } if (k === ',' && res.includes(',')) return; res = res === '0' && k !== ',' ? k : res + k; }
        else if (['+', '−', '×', '÷'].includes(k)) { expr = (fresh && expr.endsWith('=') ? '' : expr) + res + ' ' + k + ' '; res = '0'; fresh = false; if (expr.includes('=')) expr = res + ' ' + k + ' '; }
        else if (k === '=') { try { const full = expr + res; const v = OS.calcEval(full); expr = full + ' ='; res = fmt(v); fresh = true; } catch (e) { res = 'Erro'; fresh = true; } }
        else if (k === 'C') { expr = ''; res = '0'; } else if (k === 'CE') res = '0';
        else if (k === '⌫') res = res.length > 1 && res !== 'Erro' ? res.slice(0, -1) : '0';
        else if (k === '±') res = res.startsWith('-') ? res.slice(1) : res === '0' ? res : '-' + res;
        else { const n = parseFloat(res.replace(',', '.')); let v = n; if (k === '1/x') v = 1 / n; if (k === 'x²') v = n * n; if (k === '√x') v = Math.sqrt(n); if (k === '%') v = n / 100; res = fmt(v); fresh = true; }
        show();
      };
      root.addEventListener('click', (e) => { const b = e.target.closest('[data-k]'); if (b) press(b.dataset.k); });
      win.body.tabIndex = 0;
      win.body.addEventListener('keydown', (e) => {
        const m = { '*': '×', '/': '÷', '-': '−', ',': ',', '.': ',', Enter: '=', '=': '=', Backspace: '⌫', Escape: 'C', Delete: 'CE' }; const k = m[e.key] || e.key;
        if (/^[\d+%]$/.test(k) || ['×', '÷', '−', ',', '=', '⌫', 'C', 'CE'].includes(k)) { e.preventDefault(); press(k); }
      });
      setTimeout(() => win.body.focus(), 60);
    }
  });

  /* ================================== TERMINAL ================================== */
  OS.registerApp({
    id: 'terminal', title: 'Terminal', icon: 'terminal', w: 760, h: 480, keywords: 'terminal cmd powershell console comandos shell',
    build(win) {
      const root = html('<div class="term"><div class="t-out" id="t-out"></div><div class="t-line"><span class="t-ps" id="t-ps"></span><input id="t-in" spellcheck="false" autocomplete="off" aria-label="Comando"></div></div>');
      win.body.appendChild(root);
      const out = $('#t-out', root), inp = $('#t-in', root); let cwd = '', hist = OS.store.get('thist', []), hi = hist.length;
      const ps = () => { $('#t-ps', root).textContent = `PS ${cwd ? 'C:\\' + cwd.replace(/\//g, '\\') : 'C:\\Adriel'}> `; };
      const print = (s, cls) => { const d = html(`<div class="${cls || ''}"></div>`); d.innerHTML = s; out.appendChild(d); out.scrollTop = out.scrollHeight; };
      const pr = (s, cls) => print(esc(s).replace(/\n/g, '<br>').replace(/ {2}/g, '&nbsp; '), cls);
      print(`<b class="ok">AdrielOS PowerShell</b> — versão 26H2<br>Digite <b>help</b> para ver os comandos. Dica: tente <b>neofetch</b>.<br>&nbsp;`);
      const node = () => OS.vfs.resolve(cwd);
      const fortunes = DATA.quotes;
      const C = {
        help() { pr('Comandos disponíveis:\n  help            lista de comandos\n  about           quem é Adriel\n  projects        lista os projetos\n  skills          habilidades\n  contact         formas de contato\n  github          abre o GitHub\n  neofetch        informações do sistema\n  ls / dir        lista arquivos da pasta atual\n  cd <pasta>      entra em uma pasta (cd .. volta)\n  cat <arquivo>   mostra um arquivo de texto\n  open <app|url>  abre um aplicativo, site ou arquivo\n  apps            lista de aplicativos\n  theme dark|light   troca o tema\n  accent <#hex>   muda a cor de destaque\n  wallpaper list|next|<nome>\n  calc <conta>    ex.: calc 2*(3+4)\n  date, time, whoami, hostname, ver, uptime\n  echo <texto>, clear, history\n  tasklist, taskkill <app>\n  frase           uma frase aleatória\n  matrix, snake, mines, bsod\n  lock, sleep, restart, shutdown, exit'); },
        about() { pr(`${DATA.me.name} — ${DATA.me.role}\n"${DATA.me.tagline}"\n\n${DATA.me.bio}`); },
        projects() { DATA.projects.forEach((p, i) => pr(`[${i + 1}] ${p.short.padEnd(20)} ${p.badge.replace(/^\S+\s/, '')}${p.site ? '\n    ' + p.site : ''}`)); pr('\nUse: open <nome do projeto>'); },
        skills() { DATA.skills.forEach((g) => { pr(`# ${g.title}`, 'ok'); g.items.forEach((i) => pr(`   - ${i[0]}`)); }); },
        contact() { pr(`E-mail:   ${DATA.me.email}\nWhatsApp: ${DATA.me.whatsappLabel}\nGitHub:   ${DATA.me.github}`); },
        github() { window.open(DATA.me.github, '_blank', 'noopener'); pr('Abrindo GitHub em nova aba…'); },
        neofetch() {
          print(`<pre class="nf"><span class="ok">       ▄▄▄▄▄▄▄   ▄▄▄▄▄▄▄\n       █████▀▀   ▀▀█████\n       █████       █████\n       ▀▀▀▀▀       ▀▀▀▀▀\n       ▄▄▄▄▄       ▄▄▄▄▄\n       █████▄▄   ▄▄█████\n       ▀▀▀▀▀▀▀   ▀▀▀▀▀▀▀</span>\n<b>visitante</b>@<b>ADRIEL-PC</b>\n----------------------\n<b>OS</b>: AdrielOS 11 Portfólio (26H2)\n<b>Host</b>: ${esc(DATA.me.name)}\n<b>Shell</b>: PowerShell web\n<b>Tela</b>: ${innerWidth}x${innerHeight}\n<b>Tema</b>: ${OS.isDark() ? 'Escuro' : 'Claro'} (${OS.settings.accent})\n<b>Tecnologias</b>: HTML · CSS · JS\n<b>Janelas</b>: ${OS.wins.length}\n<b>Uptime</b>: ${Math.floor((Date.now() - OS.bootedAt) / 1000)}s</pre>`);
        },
        ls() { const n = node(); if (!n || !n.children) return pr('Pasta inválida.', 'err'); if (!n.children.length) return pr('(vazia)'); n.children.forEach((c) => pr(`${c.type === 'folder' ? '<DIR>' : '     '}  ${c.name}`)); },
        cd(a) {
          const t = (a[0] || '').replace(/^\.\\|^\.\//, '').replace(/\\/g, '/').replace(/\/$/, '');
          if (!t) return; if (t === '..') { cwd = cwd.split('/').slice(0, -1).join('/'); return; } if (t === '/' || t === '~') { cwd = ''; return; }
          const target = cwd ? cwd + '/' + t : t; const n = OS.vfs.resolve(target); if (n && n.type === 'folder') cwd = target; else pr(`cd: não encontrei a pasta '${t}'.`, 'err');
        },
        cat(a) { const nm = a.join(' '); const n = node(), f = n && n.children && n.children.find((c) => c.name.toLowerCase() === nm.toLowerCase()); if (!f) return pr(`cat: '${nm}' não encontrado.`, 'err'); if (f.kind === 'txt') pr(f.content != null ? f.content : OS.store.get('docs', {})[f.name] || ''); else pr('Esse arquivo não é de texto. Use: open ' + f.name, 'err'); },
        open(a) {
          const t = a.join(' '); if (!t) return pr('Uso: open <app|url|arquivo>', 'err');
          if (/^(https?:\/\/|www\.)/i.test(t)) return OS.openUrl(/^www\./i.test(t) ? 'https://' + t : t);
          const app = OS.resolveApp(t); if (app) { OS.openApp(app); return pr(`Abrindo ${OS.apps[app].title}…`); }
          const p = DATA.projects.find((x) => x.short.toLowerCase().includes(t.toLowerCase()) || x.id === t.toLowerCase()); if (p) { p.site ? OS.openUrl(p.site, p.short) : p.pdf ? OS.openApp('pdf', { src: p.pdf, title: p.short }) : OS.openApp('explorer', { path: 'Projetos' }); return pr(`Abrindo ${p.short}…`); }
          const n = node(), f = n && n.children && n.children.find((c) => c.name.toLowerCase() === t.toLowerCase()); if (f) { f.type === 'folder' ? OS.openApp('explorer', { path: (cwd ? cwd + '/' : '') + f.name }) : OS.vfs.open(f); return; }
          pr(`open: não sei abrir '${t}'. Tente: apps`, 'err');
        },
        apps() { pr(Object.values(OS.apps).filter((a) => !a.hidden).map((a) => a.id.padEnd(10) + a.title).join('\n')); },
        theme(a) { if (!['dark', 'light'].includes(a[0])) return pr('Uso: theme dark|light', 'err'); OS.set('theme', a[0]); pr('Tema alterado.'); },
        accent(a) { if (!/^#[0-9a-f]{6}$/i.test(a[0] || '')) return pr('Uso: accent #rrggbb', 'err'); OS.set('accent', a[0]); pr('Cor de destaque alterada.'); },
        wallpaper(a) { const l = OS.wallpaper.list(); if (!a[0] || a[0] === 'list') return pr(l.map((w) => w.id.padEnd(24) + w.name).join('\n')); if (a[0] === 'next') { OS.wallpaper.next(1); return; } const w = l.find((x) => x.id === a[0]); w ? OS.wallpaper.set(w.id) : pr('Wallpaper não encontrado. Use: wallpaper list', 'err'); },
        calc(a) { try { pr(String(+OS.calcEval(a.join(' ')).toPrecision(12))); } catch (e) { pr('Expressão inválida.', 'err'); } },
        date() { pr(new Date().toLocaleDateString('pt-BR', { dateStyle: 'full' })); }, time() { pr(OS.fmtTime(new Date(), true)); },
        whoami() { pr('adrielpc\\visitante'); }, hostname() { pr('ADRIEL-PC'); }, ver() { pr('AdrielOS 11 Edição Portfólio [Versão 26H2]'); },
        uptime() { const s = Math.floor((Date.now() - OS.bootedAt) / 1000); pr(`Sessão ativa há ${Math.floor(s / 60)} min ${s % 60} s`); },
        echo(a) { pr(a.join(' ')); }, clear() { out.innerHTML = ''; }, cls() { out.innerHTML = ''; },
        history() { hist.forEach((h, i) => pr(`${String(i + 1).padStart(3)}  ${h}`)); },
        tasklist() { pr(OS.wins.map((w) => w.app.id.padEnd(10) + w.title).join('\n') || 'Nenhum aplicativo aberto.'); },
        taskkill(a) { const ws = OS.windowsOf(OS.resolveApp(a[0] || '') || a[0]); if (!ws.length) return pr('Processo não encontrado.', 'err'); ws.forEach((w) => w.close()); pr('Finalizado.'); },
        frase() { pr('“' + fortunes[Math.floor(Math.random() * fortunes.length)] + '”'); }, fortune() { C.frase(); },
        matrix() { OS.wallpaper.set('live_matrix'); pr('Siga o coelho branco… 🐇'); },
        snake() { OS.openApp('snake'); }, mines() { OS.openApp('mines'); }, bsod() { OS.session.bsod(); },
        lock() { OS.session.lock(); }, sleep() { OS.session.sleep(); }, restart() { OS.session.restart(); }, shutdown() { OS.session.shutdown(); }, exit() { win.close(); },
        sudo() { pr('Boa tentativa! Mas aqui você já é administrador. 😎'); },
        rm(a) { pr(a.join(' ').includes('-rf') ? 'Calma! Os projetos do Adriel agradecem. 🛡️ (nada foi apagado)' : 'rm: operação não permitida.', 'err'); },
        ping() { pr('Disparando ping para adrielos.local…\nResposta: tempo<1ms\nResposta: tempo<1ms\nResposta: tempo<1ms'); },
        cowsay(a) { const t = a.join(' ') || 'Muu!'; pr(` ${'_'.repeat(t.length + 2)}\n< ${t} >\n ${'-'.repeat(t.length + 2)}\n        \\   ^__^\n         \\  (oo)\\_______\n            (__)\\       )\\/\\\n                ||----w |\n                ||     ||`); }
      };
      function run(line) {
        pr(`${$('#t-ps', root).textContent}${line}`, 'cmd');
        const parts = line.trim().split(/\s+/); const cmd = (parts.shift() || '').toLowerCase(); if (!cmd) return;
        const alias = { dir: 'ls', type: 'cat', start: 'open', projetos: 'projects', habilidades: 'skills', contato: 'contact', sobre: 'about', ajuda: 'help' };
        const f = C[alias[cmd] || cmd];
        if (f) { try { f(parts); } catch (e) { pr('Erro: ' + e.message, 'err'); } } else pr(`'${cmd}' não é reconhecido como um comando. Digite help.`, 'err');
      }
      inp.onkeydown = (e) => {
        if (e.key === 'Enter') { const v = inp.value; if (v.trim()) { hist.push(v); hist = hist.slice(-50); OS.store.set('thist', hist); } hi = hist.length; inp.value = ''; run(v); ps(); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); if (hi > 0) inp.value = hist[--hi]; } else if (e.key === 'ArrowDown') { e.preventDefault(); inp.value = hi < hist.length - 1 ? hist[++hi] : ((hi = hist.length), ''); }
        else if (e.key === 'Tab') { e.preventDefault(); const w = inp.value.split(/\s+/); const last = w.pop().toLowerCase(); const pool = w.length ? ((node() || {}).children || []).map((c) => c.name) : Object.keys(C); const m = pool.find((x) => x.toLowerCase().startsWith(last)); if (m) inp.value = w.concat(m).join(' '); }
        else if (e.ctrlKey && e.key.toLowerCase() === 'l') { e.preventDefault(); out.innerHTML = ''; }
      };
      root.onclick = () => { if (!getSelection().toString()) inp.focus(); };
      ps(); setTimeout(() => inp.focus(), 60);
    }
  });

  /* ================================== FOTOS ================================== */
  OS.registerApp({
    id: 'photos', title: 'Fotos', icon: 'photos', w: 900, h: 600, keywords: 'fotos imagens galeria wallpapers visualizador',
    build(win, opts) {
      const imgs = OS.vfs.resolve('Imagens/Papéis de parede').children.concat(OS.vfs.resolve('Imagens/Projetos').children);
      let i = Math.max(0, imgs.findIndex((x) => x.src === opts.src)), zoom = 1, rot = 0, slide = null;
      const root = html(`<div class="ph"><div class="ph-bar"><button class="cmd" data-a="prev">${UI.chevronLeft}</button><button class="cmd" data-a="next">${UI.chevronRight}</button><i class="cmd-sep"></i><button class="cmd" data-a="zin">${UI.zoomIn}<span>Zoom</span></button><button class="cmd" data-a="rot">${UI.restart}<span>Girar</span></button><button class="cmd" data-a="play">${UI.play}<span>Apresentação</span></button><button class="cmd" data-a="wp">${UI.image}<span>Definir como fundo</span></button><span class="ph-name" id="ph-name"></span></div><div class="ph-stage" id="ph-stage"><img id="ph-img" alt=""></div><div class="ph-strip" id="ph-strip"></div></div>`);
      win.body.appendChild(root);
      const img = $('#ph-img', root), strip = $('#ph-strip', root);
      strip.innerHTML = imgs.map((m, k) => `<button data-k="${k}"><img src="${m.thumb}" alt="" loading="lazy"></button>`).join('');
      function show() { const m = imgs[i]; img.src = m.src; img.style.transform = `rotate(${rot}deg) scale(${zoom})`; $('#ph-name', root).textContent = `${m.title || m.name}  (${i + 1}/${imgs.length})`; $$('button', strip).forEach((b, k) => b.classList.toggle('on', k === i)); win.setTitle((m.title || m.name) + ' — Fotos'); }
      const step = (d) => { i = (i + d + imgs.length) % imgs.length; zoom = 1; rot = 0; show(); };
      root.addEventListener('click', (e) => {
        const k = e.target.closest('[data-k]'); if (k) { i = +k.dataset.k; zoom = 1; rot = 0; show(); return; }
        const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a;
        if (a === 'prev') step(-1); else if (a === 'next') step(1); else if (a === 'zin') { zoom = zoom >= 2.5 ? 1 : zoom + 0.5; show(); } else if (a === 'rot') { rot += 90; show(); }
        else if (a === 'wp') { const m = imgs[i]; m.wid ? OS.wallpaper.set(m.wid) : OS.toast('Só os papéis de parede podem ser definidos como fundo.', 'photos'); }
        else if (a === 'play') { if (slide) { clearInterval(slide); slide = null; $('span', b).textContent = 'Apresentação'; } else { slide = setInterval(() => step(1), 2500); $('span', b).textContent = 'Parar'; } }
      });
      win.body.tabIndex = 0; win.body.onkeydown = (e) => { if (e.key === 'ArrowRight') step(1); if (e.key === 'ArrowLeft') step(-1); };
      win.onClose(() => clearInterval(slide)); win.onOpenAgain = (o) => { const k = imgs.findIndex((x) => x.src === o.src); if (k >= 0) { i = k; show(); } };
      show();
    }
  });

  /* ==================================== PAINT ==================================== */
  OS.registerApp({
    id: 'paint', title: 'Paint', icon: 'paint', w: 860, h: 600, keywords: 'paint desenhar pintura canvas desenho',
    build(win) {
      const colors = ['#000000', '#7f7f7f', '#880015', '#ed1c24', '#ff7f27', '#fff200', '#22b14c', '#00a2e8', '#3f48cc', '#a349a4', '#ffffff', '#c3c3c3', '#b97a57', '#ffaec9', '#ffc90e', '#efe4b0', '#b5e61d', '#99d9ea', '#7092be', '#c8bfe7'];
      const root = html(`<div class="pt"><div class="pt-bar"><div class="tools">${[['pen', 'pencil', 'Lápis'], ['brush', 'palette', 'Pincel'], ['eraser', 'eraser', 'Borracha'], ['line', 'up', 'Linha'], ['rect', 'maximize', 'Retângulo'], ['circle', 'info', 'Elipse'], ['fill', 'image', 'Balde']].map((t) => `<button class="tool" data-t="${t[0]}" title="${t[2]}">${UI[t[1]]}</button>`).join('')}</div>
        <label class="sz">Tamanho <input type="range" id="pt-size" min="1" max="40" value="4"></label><div class="pal">${colors.map((c) => `<button class="pc" data-c="${c}" style="background:${c}" aria-label="${c}"></button>`).join('')}<input type="color" id="pt-cus" value="#000000"></div>
        <div class="acts"><button class="cmd" id="pt-undo">${UI.back}<span>Desfazer</span></button><button class="cmd" id="pt-clear">${UI.trash}<span>Limpar</span></button><button class="cmd" id="pt-save">${UI.save}<span>Salvar PNG</span></button></div></div><div class="pt-wrap" id="pt-wrap"><canvas id="pt-cv"></canvas></div></div>`);
      win.body.appendChild(root);
      const cv = $('#pt-cv', root), ctx = cv.getContext('2d', { willReadFrequently: true }), wrapEl = $('#pt-wrap', root);
      let tool = 'pen', color = '#000000', size = 4, down = false, sx = 0, sy = 0, snap = null; const undo = [];
      function fit() { const old = cv.width ? ctx.getImageData(0, 0, cv.width, cv.height) : null; cv.width = Math.max(300, wrapEl.clientWidth - 2); cv.height = Math.max(200, wrapEl.clientHeight - 2); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height); if (old) ctx.putImageData(old, 0, 0); }
      const push = () => { undo.push(ctx.getImageData(0, 0, cv.width, cv.height)); if (undo.length > 25) undo.shift(); };
      const pos = (e) => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * (cv.width / r.width), (e.clientY - r.top) * (cv.height / r.height)]; };
      function flood(x, y, hex) {
        const d = ctx.getImageData(0, 0, cv.width, cv.height), a = d.data, w = cv.width, h = cv.height; x |= 0; y |= 0;
        const idx = (x0, y0) => (y0 * w + x0) * 4, t = [a[idx(x, y)], a[idx(x, y) + 1], a[idx(x, y) + 2]]; const n = parseInt(hex.slice(1), 16), c = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
        if (t[0] === c[0] && t[1] === c[1] && t[2] === c[2]) return; const st = [[x, y]];
        const same = (k) => Math.abs(a[k] - t[0]) < 8 && Math.abs(a[k + 1] - t[1]) < 8 && Math.abs(a[k + 2] - t[2]) < 8;
        while (st.length) { const [px, py] = st.pop(); if (px < 0 || py < 0 || px >= w || py >= h) continue; const k = idx(px, py); if (!same(k)) continue; a[k] = c[0]; a[k + 1] = c[1]; a[k + 2] = c[2]; a[k + 3] = 255; st.push([px + 1, py], [px - 1, py], [px, py + 1], [px, py - 1]); }
        ctx.putImageData(d, 0, 0);
      }
      cv.onpointerdown = (e) => { e.preventDefault(); cv.setPointerCapture(e.pointerId); const [x, y] = pos(e); push(); if (tool === 'fill') { flood(x, y, color); return; } down = true; sx = x; sy = y; snap = ctx.getImageData(0, 0, cv.width, cv.height); ctx.lineCap = ctx.lineJoin = 'round'; ctx.strokeStyle = tool === 'eraser' ? '#fff' : color; ctx.lineWidth = tool === 'eraser' ? size * 3 : tool === 'brush' ? size * 2 : size; if (['pen', 'brush', 'eraser'].includes(tool)) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 0.01, y); ctx.stroke(); } };
      cv.onpointermove = (e) => {
        if (!down) return; const [x, y] = pos(e);
        if (['pen', 'brush', 'eraser'].includes(tool)) { ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(x, y); ctx.stroke(); sx = x; sy = y; return; }
        ctx.putImageData(snap, 0, 0); ctx.beginPath();
        if (tool === 'line') { ctx.moveTo(sx, sy); ctx.lineTo(x, y); } else if (tool === 'rect') ctx.rect(sx, sy, x - sx, y - sy); else if (tool === 'circle') ctx.ellipse((sx + x) / 2, (sy + y) / 2, Math.abs(x - sx) / 2, Math.abs(y - sy) / 2, 0, 0, 6.3);
        ctx.stroke();
      };
      cv.onpointerup = cv.onpointercancel = () => { down = false; };
      $$('.tool', root).forEach((b) => (b.onclick = () => { tool = b.dataset.t; $$('.tool', root).forEach((x) => x.classList.toggle('on', x === b)); })); $('.tool', root).classList.add('on');
      $$('.pc', root).forEach((b) => (b.onclick = () => { color = b.dataset.c; $('#pt-cus', root).value = color; }));
      $('#pt-cus', root).oninput = (e) => (color = e.target.value); $('#pt-size', root).oninput = (e) => (size = +e.target.value);
      $('#pt-undo', root).onclick = () => { const s = undo.pop(); if (s) ctx.putImageData(s, 0, 0); };
      $('#pt-clear', root).onclick = () => { push(); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height); };
      $('#pt-save', root).onclick = () => cv.toBlob((b) => OS.download('desenho.png', b));
      win.onResize = fit; setTimeout(fit, 30); win.setTitle('Sem título — Paint');
    }
  });

  /* ================================ CAMPO MINADO ================================ */
  OS.registerApp({
    id: 'mines', title: 'Campo Minado', icon: 'mines', w: 400, h: 520, minW: 300, minH: 380, keywords: 'campo minado minesweeper jogo bombas',
    build(win) {
      const LV = { 'Iniciante': [9, 9, 10], 'Intermediário': [12, 12, 24], 'Difícil': [16, 16, 40] }; let lv = 'Iniciante', R, C, M, grid, over, started, time = 0, timer = null, flags = 0, flagMode = false;
      const root = html('<div class="ms"><div class="ms-bar"><select id="ms-lv"></select><button class="cmd" id="ms-flag" title="Modo bandeira (para toque)">🚩</button></div><div class="ms-head"><span class="lcd" id="ms-m">010</span><button class="face" id="ms-face">🙂</button><span class="lcd" id="ms-t">000</span></div><div class="ms-grid" id="ms-g"></div></div>');
      win.body.appendChild(root);
      $('#ms-lv', root).innerHTML = Object.keys(LV).map((k) => `<option>${k}</option>`).join('');
      const g = $('#ms-g', root);
      function reset() {
        [R, C, M] = LV[lv]; grid = Array.from({ length: R }, () => Array.from({ length: C }, () => ({ m: false, o: false, f: false, n: 0 }))); over = false; started = false; time = 0; flags = 0; clearInterval(timer); $('#ms-face', root).textContent = '🙂'; draw();
        g.style.gridTemplateColumns = `repeat(${C}, 1fr)`; g.style.setProperty('--cols', C);
      }
      function place(sr, sc) { let n = 0; while (n < M) { const r = Math.random() * R | 0, c = Math.random() * C | 0; if (grid[r][c].m || (Math.abs(r - sr) < 2 && Math.abs(c - sc) < 2)) continue; grid[r][c].m = true; n++; } grid.forEach((row, r) => row.forEach((cell, c) => { for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) { const x = grid[r + a] && grid[r + a][c + b]; if (x && x.m) cell.n++; } })); }
      function open(r, c) { const cell = grid[r] && grid[r][c]; if (!cell || cell.o || cell.f) return; cell.o = true; if (cell.n === 0 && !cell.m) for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) open(r + a, c + b); }
      function end(win_) { over = true; clearInterval(timer); $('#ms-face', root).textContent = win_ ? '😎' : '😵'; grid.forEach((row) => row.forEach((x) => { if (x.m) x.o = true; })); draw(); if (win_) OS.notify({ title: 'Você venceu o Campo Minado!', body: `Tempo: ${time}s — nível ${lv}.`, icon: 'mines', app: 'Campo Minado' }); }
      function click(r, c, flag) {
        if (over) return; const cell = grid[r][c];
        if (flag) { if (!cell.o) { cell.f = !cell.f; flags += cell.f ? 1 : -1; } draw(); return; }
        if (cell.f || cell.o) return;
        if (!started) { started = true; place(r, c); timer = setInterval(() => { time++; $('#ms-t', root).textContent = pad(Math.min(999, time)).padStart(3, '0'); }, 1000); }
        if (cell.m) { open(r, c); cell.boom = true; end(false); return; } open(r, c); draw();
        if (grid.every((row) => row.every((x) => x.m || x.o))) end(true);
      }
      function draw() {
        $('#ms-m', root).textContent = String(Math.max(0, M - flags)).padStart(3, '0'); $('#ms-t', root).textContent = String(Math.min(999, time)).padStart(3, '0');
        g.innerHTML = ''; const cols = ['', '#2563eb', '#16a34a', '#dc2626', '#1e3a8a', '#991b1b', '#0e7490', '#111', '#6b7280'];
        grid.forEach((row, r) => row.forEach((x, c) => {
          const b = document.createElement('button'); b.className = 'cell' + (x.o ? ' o' : '') + (x.boom ? ' boom' : '');
          if (x.o) { if (x.m) b.textContent = '💣'; else if (x.n) { b.textContent = x.n; b.style.color = cols[x.n]; } } else if (x.f) b.textContent = '🚩';
          b.onclick = () => click(r, c, flagMode); b.oncontextmenu = (e) => { e.preventDefault(); click(r, c, true); };
          let lp; b.onpointerdown = (e) => { if (e.pointerType === 'touch') lp = setTimeout(() => { lp = null; click(r, c, true); }, 450); }; b.onpointerup = b.onpointerleave = () => { if (lp) { clearTimeout(lp); lp = null; } };
          g.appendChild(b);
        }));
      }
      $('#ms-lv', root).onchange = (e) => { lv = e.target.value; reset(); }; $('#ms-face', root).onclick = reset;
      $('#ms-flag', root).onclick = (e) => { flagMode = !flagMode; e.currentTarget.classList.toggle('on', flagMode); };
      win.onClose(() => clearInterval(timer)); reset();
    }
  });

  /* ==================================== SNAKE ==================================== */
  OS.registerApp({
    id: 'snake', title: 'Snake', icon: 'snake', w: 480, h: 560, minW: 320, minH: 380, keywords: 'snake cobrinha jogo',
    build(win) {
      const root = html('<div class="sn"><div class="sn-head"><span>Pontos: <b id="sn-s">0</b></span><span>Recorde: <b id="sn-b">0</b></span><button class="btn sm" id="sn-r">Reiniciar</button></div><div class="sn-wrap" id="sn-w"><canvas id="sn-cv" width="400" height="400"></canvas><div class="sn-over" id="sn-o"><b>Snake</b><small>Setas / WASD ou deslize na tela</small><button class="btn primary" id="sn-go">Jogar</button></div></div></div>');
      win.body.appendChild(root); const cv = $('#sn-cv', root), x = cv.getContext('2d'), N = 20, S = cv.width / N;
      let snake, dir, nd, food, score, best = OS.store.get('snakebest', 0), t = null, speed;
      $('#sn-b', root).textContent = best;
      function start() { snake = [[10, 10], [9, 10], [8, 10]]; dir = nd = [1, 0]; score = 0; speed = 130; spawn(); $('#sn-o', root).hidden = true; $('#sn-s', root).textContent = 0; clearInterval(t); t = setInterval(tick, speed); win.body.focus(); }
      function spawn() { do { food = [Math.random() * N | 0, Math.random() * N | 0]; } while (snake.some((s) => s[0] === food[0] && s[1] === food[1])); }
      function tick() {
        dir = nd; const h = [snake[0][0] + dir[0], snake[0][1] + dir[1]];
        if (h[0] < 0 || h[1] < 0 || h[0] >= N || h[1] >= N || snake.some((s) => s[0] === h[0] && s[1] === h[1])) { clearInterval(t); if (score > best) { best = score; OS.store.set('snakebest', best); $('#sn-b', root).textContent = best; } const o = $('#sn-o', root); o.hidden = false; $('b', o).textContent = `Fim de jogo — ${score} pts`; $('#sn-go', root).textContent = 'Jogar de novo'; OS.sound('error'); return; }
        snake.unshift(h);
        if (h[0] === food[0] && h[1] === food[1]) { score++; $('#sn-s', root).textContent = score; spawn(); OS.sound('click'); if (score % 4 === 0 && speed > 60) { speed -= 10; clearInterval(t); t = setInterval(tick, speed); } } else snake.pop();
        draw();
      }
      function draw() {
        x.fillStyle = OS.isDark() ? '#0b1220' : '#e8f0e0'; x.fillRect(0, 0, 400, 400);
        for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) if ((i + j) % 2) { x.fillStyle = 'rgba(128,128,128,.07)'; x.fillRect(i * S, j * S, S, S); }
        x.fillStyle = '#ef4444'; x.beginPath(); x.arc(food[0] * S + S / 2, food[1] * S + S / 2, S / 2 - 3, 0, 6.3); x.fill();
        snake.forEach((s, i) => { x.fillStyle = i ? '#22c55e' : '#16a34a'; x.beginPath(); x.roundRect(s[0] * S + 1, s[1] * S + 1, S - 2, S - 2, 6); x.fill(); });
      }
      const set = (dx, dy) => { if (dx !== -dir[0] || dy !== -dir[1]) nd = [dx, dy]; };
      win.body.tabIndex = 0;
      win.body.onkeydown = (e) => { const k = e.key.toLowerCase(); const m = { arrowup: [0, -1], w: [0, -1], arrowdown: [0, 1], s: [0, 1], arrowleft: [-1, 0], a: [-1, 0], arrowright: [1, 0], d: [1, 0] }[k]; if (m) { e.preventDefault(); set(...m); } };
      let tx, ty; cv.ontouchstart = (e) => { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }; cv.ontouchend = (e) => { const dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty; Math.abs(dx) > Math.abs(dy) ? set(Math.sign(dx), 0) : set(0, Math.sign(dy)); };
      $('#sn-go', root).onclick = start; $('#sn-r', root).onclick = start; win.onClose(() => clearInterval(t));
      snake = [[10, 10]]; food = [15, 10]; draw();
    }
  });

  /* ========================== GERENCIADOR DE TAREFAS ========================== */
  OS.registerApp({
    id: 'taskmgr', title: 'Gerenciador de Tarefas', icon: 'taskmgr', w: 760, h: 520, single: true, minW: 420, minH: 320, keywords: 'gerenciador de tarefas task manager processos desempenho fps memória',
    build(win) {
      let tab = 'proc'; const fps = Array(60).fill(0); let frames = 0, last = performance.now(), raf;
      const root = html(`<div class="tm"><nav class="tm-tabs"><button data-t="proc" class="on">Processos</button><button data-t="perf">Desempenho</button></nav><div class="tm-body" id="tm-b"></div></div>`);
      win.body.appendChild(root);
      const body = $('#tm-b', root);
      function loop(now) { frames++; if (now - last >= 1000) { fps.push(Math.round(frames * 1000 / (now - last))); fps.shift(); frames = 0; last = now; if (tab === 'perf') drawPerf(); else if (tab === 'proc') drawProc(); } raf = requestAnimationFrame(loop); }
      function drawProc() {
        body.innerHTML = `<div class="tm-row head"><span>Nome</span><span>Status</span><span>Janelas</span><span></span></div>` + (OS.wins.length ? Array.from(new Set(OS.wins.map((w) => w.appId))).map((id) => { const a = OS.apps[id], ws = OS.windowsOf(id); return `<div class="tm-row" data-id="${id}"><span class="nm">${icon(a.icon)}${esc(a.title)}</span><span>${ws.every((w) => w.min) ? 'Suspenso' : 'Em execução'}</span><span>${ws.length}</span><span><button class="btn sm">Finalizar tarefa</button></span></div>`; }).join('') : '<div class="ex-empty">Nenhum aplicativo em execução.</div>');
        $$('.tm-row[data-id] button', body).forEach((b) => (b.onclick = () => OS.windowsOf(b.closest('.tm-row').dataset.id).forEach((w) => w.close())));
      }
      function drawPerf() {
        const mem = performance.memory ? (performance.memory.usedJSHeapSize / 1048576).toFixed(1) + ' MB (heap JS)' : 'indisponível neste navegador';
        const cur = fps[fps.length - 1], max = 70, pts = fps.map((v, i) => `${(i / 59) * 300},${100 - Math.min(100, v / max * 100)}`).join(' ');
        body.innerHTML = `<div class="tm-perf"><div class="card"><h4>Quadros por segundo (FPS)</h4><b class="big">${cur}</b><svg viewBox="0 0 300 100" preserveAspectRatio="none"><polyline points="${pts}"/></svg></div><div class="card"><h4>Memória</h4><b>${mem}</b></div><div class="card"><h4>Núcleos lógicos</h4><b>${navigator.hardwareConcurrency || '—'}</b></div><div class="card"><h4>Janelas abertas</h4><b>${OS.wins.length}</b></div></div>`;
      }
      $$('.tm-tabs button', root).forEach((b) => (b.onclick = () => { tab = b.dataset.t; $$('.tm-tabs button', root).forEach((x) => x.classList.toggle('on', x === b)); tab === 'proc' ? drawProc() : drawPerf(); }));
      OS.on('wm', () => win.el.isConnected && tab === 'proc' && drawProc());
      raf = requestAnimationFrame(loop); win.onClose(() => cancelAnimationFrame(raf)); drawProc();
    }
  });

  /* =============================== RÁDIO ADRIELOS =============================== */
  OS.registerApp({
    id: 'music', title: 'Rádio AdrielOS', short: 'Música', icon: 'music', w: 460, h: 540, single: true, minW: 360, minH: 440, keywords: 'música rádio som lofi player áudio',
    build(win, opts) {
      const T = [
        { n: 'Madrugada Lo-fi', bpm: 76, root: 57, ch: [[0, 4, 7, 11], [5, 9, 12, 16], [7, 11, 14, 17], [3, 7, 10, 14]], wave: 'triangle', color: '#8b5cf6' },
        { n: 'Intervalo do Jogo', bpm: 96, root: 60, ch: [[0, 4, 7], [7, 11, 14], [9, 12, 16], [5, 9, 12]], wave: 'sine', color: '#22c55e' },
        { n: 'Código à Noite', bpm: 84, root: 52, ch: [[0, 3, 7, 10], [8, 12, 15, 19], [5, 8, 12, 15], [7, 10, 14, 17]], wave: 'triangle', color: '#38bdf8' },
        { n: 'Chuva no Estádio', bpm: 68, root: 55, ch: [[0, 4, 7, 14], [2, 5, 9, 12], [4, 7, 11, 14], [0, 4, 7, 12]], wave: 'sine', color: '#f59e0b' }
      ];
      let cur = clamp(opts.track || 0, 0, 3), playing = false, step = 0, nextT = 0, timer = null, analyser = null, raf = null;
      const root = html(`<div class="mu"><div class="mu-art" id="mu-art"><canvas id="mu-cv" width="360" height="140"></canvas></div><h2 id="mu-n"></h2><small>Música gerada em tempo real pelo navegador</small><div class="mu-ctl"><button id="mu-prev" aria-label="Anterior">${UI.skipPrev}</button><button class="big" id="mu-play" aria-label="Tocar">${UI.play}</button><button id="mu-next" aria-label="Próxima">${UI.skipNext}</button></div><div class="mu-vol"><span>${UI.volume}</span><input type="range" id="mu-v" min="0" max="100"></div><div class="mu-list" id="mu-l"></div></div>`);
      win.body.appendChild(root);
      const hz = (m) => 440 * Math.pow(2, (m - 69) / 12);
      function note(c, f, t, d, type, v, dest) { const o = c.createOscillator(), g = c.createGain(), lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1400; o.type = type; o.frequency.value = f; g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + 0.04); g.gain.exponentialRampToValueAtTime(0.0001, t + d); o.connect(lp); lp.connect(g); g.connect(dest); o.start(t); o.stop(t + d + 0.05); }
      function kick(c, t, dest) { const o = c.createOscillator(), g = c.createGain(); o.frequency.setValueAtTime(130, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.14); g.gain.setValueAtTime(0.5, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.18); o.connect(g); g.connect(dest); o.start(t); o.stop(t + 0.2); }
      function hat(c, t, dest) { const b = c.createBuffer(1, 2205, c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length); const s = c.createBufferSource(), g = c.createGain(), hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 6000; s.buffer = b; g.gain.value = 0.12; s.connect(hp); hp.connect(g); g.connect(dest); s.start(t); }
      function sched() {
        const c = OS.audio.ctx(); if (!c || !playing) return; const tr = T[cur], beat = 60 / tr.bpm / 2;
        while (nextT < c.currentTime + 0.3) {
          const bar = Math.floor(step / 8) % 4, s8 = step % 8, ch = tr.ch[bar];
          if (s8 === 0) ch.forEach((n, i) => note(c, hz(tr.root + n), nextT, beat * 8.5, tr.wave, 0.07 - i * 0.008, analyser));
          if (s8 % 2 === 0) kick(c, nextT, s8 === 0 || s8 === 4 ? analyser : analyser);
          if (s8 % 2 === 1) hat(c, nextT, analyser);
          if ([0, 3, 5, 6].includes(s8)) note(c, hz(tr.root + 12 + ch[(step * 3 + s8) % ch.length] + (s8 === 6 ? 12 : 0)), nextT, beat * 1.6, 'sine', 0.06, analyser);
          nextT += beat; step++;
        }
      }
      function play() {
        const c = OS.audio.ctx(); if (!c) { OS.toast('Seu navegador não suporta áudio.', 'music'); return; }
        if (!analyser) { analyser = c.createAnalyser(); analyser.fftSize = 128; analyser.connect(OS.audio.out()); }
        playing = true; nextT = c.currentTime + 0.1; step = 0; clearInterval(timer); timer = setInterval(sched, 90); ui(); draw();
      }
      function stop() { playing = false; clearInterval(timer); ui(); }
      function ui() { $('#mu-n', root).textContent = T[cur].n; $('#mu-play', root).innerHTML = playing ? UI.pause : UI.play; $('#mu-art', root).style.setProperty('--c', T[cur].color); win.setTitle(`${T[cur].n} — Rádio AdrielOS`); $$('.mu-t', root).forEach((b, i) => b.classList.toggle('on', i === cur)); }
      function draw() {
        cancelAnimationFrame(raf); const cv = $('#mu-cv', root); if (!cv) return; const x = cv.getContext('2d'), d = new Uint8Array(analyser ? analyser.frequencyBinCount : 64);
        (function f() { if (!win.el.isConnected) return; analyser && analyser.getByteFrequencyData(d); x.clearRect(0, 0, 360, 140); x.fillStyle = T[cur].color; for (let i = 0; i < 32; i++) { const h = playing ? d[i] / 255 * 130 + 4 : 4; x.globalAlpha = 0.85; x.beginPath(); x.roundRect(i * 11.3 + 2, 140 - h, 8, h, 4); x.fill(); } raf = requestAnimationFrame(f); })();
      }
      $('#mu-l', root).innerHTML = T.map((t, i) => `<button class="mu-t" data-i="${i}"><span style="background:${t.color}">${UI.play}</span><b>${t.n}</b><small>${t.bpm} BPM</small></button>`).join('');
      $$('.mu-t', root).forEach((b) => (b.onclick = () => { cur = +b.dataset.i; play(); }));
      $('#mu-play', root).onclick = () => (playing ? stop() : play());
      $('#mu-next', root).onclick = () => { cur = (cur + 1) % 4; playing ? play() : ui(); }; $('#mu-prev', root).onclick = () => { cur = (cur + 3) % 4; playing ? play() : ui(); };
      const v = $('#mu-v', root); v.value = OS.settings.volume; v.oninput = () => { OS.set('volume', +v.value); OS.set('muted', +v.value === 0); };
      win.onClose(() => { stop(); cancelAnimationFrame(raf); });
      win.onOpenAgain = (o) => { if (o.track != null) { cur = o.track; play(); } };
      ui(); draw(); if (opts.track != null) play();
    }
  });
})();
