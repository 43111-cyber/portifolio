/* ==========================================================================
   AdrielOS — ÁREA DE TRABALHO + SESSÃO
   Ícones (seleção, arrastar, renomear, lixeira), menu de contexto,
   boot, tela de bloqueio, login, energia e tela azul (easter egg).
   ========================================================================== */
(function () {
  'use strict';
  const { $, $$, esc, html, clamp } = OS;
  const UI = window.UI, icon = window.icon, DATA = window.DATA;

  /* ----------------------------- ícones do desktop ----------------------------- */
  const holder = $('#desktop-icons');
  const SYS = () => [
    { id: 'trash', name: 'Lixeira', icon: OS.trashItems().length ? 'trashfull' : 'trash', app: 'trash', sys: true },
    { id: 'about', name: 'Sobre Adriel', icon: 'about', app: 'about', sys: true },
    { id: 'projects', name: 'Meus Projetos', icon: 'projects', app: 'explorer', arg: { path: 'Projetos' }, sys: true },
    { id: 'skills', name: 'Habilidades', icon: 'skills', app: 'skills', sys: true },
    { id: 'github', name: 'GitHub', icon: 'github', app: 'github', sys: true },
    { id: 'contact', name: 'Contato', icon: 'contact', app: 'contact', sys: true },
    { id: 'browser', name: 'Navegador', icon: 'browser', app: 'browser', sys: true },
    { id: 'terminal', name: 'Terminal', icon: 'terminal', app: 'terminal', sys: true },
    { id: 'sc-beico', name: 'Beiço Street', icon: 'soccer', url: DATA.projects[0].site, shortcut: true, sys: true },
    { id: 'sc-readme', name: 'leia-me.txt', icon: 'txt', app: 'notepad', arg: { file: 'leia-me.txt' }, sys: true }
  ];

  OS.trashItems = () => OS.store.get('trash', []);
  OS.userDesk = () => OS.store.get('deskItems', []);
  let positions = OS.store.get('deskPos', {});
  let selected = new Set();
  const CELL = { s: [78, 84], m: [92, 98], l: [112, 122] };
  const cell = () => CELL[OS.settings.iconSize] || CELL.m;
  const allItems = () => SYS().filter((i) => !OS.store.get('deskHidden', []).includes(i.id)).concat(OS.userDesk().map((u) => ({ id: u.id, name: u.name, icon: u.type === 'folder' ? 'folder' : 'txt', user: true, type: u.type })));

  OS.layoutDesktop = function () {
    const items = allItems();
    const [cw, ch] = cell();
    const rows = Math.max(1, Math.floor((window.innerHeight - OS.TB - 16) / ch));
    const occ = new Set(), placed = {};
    items.forEach((it) => { const p = positions[it.id]; if (p) { placed[it.id] = p; occ.add(p.c + ',' + p.r); } });
    let c = 0, r = 0;
    const nextFree = () => { while (occ.has(c + ',' + r)) { r++; if (r >= rows) { r = 0; c++; } } const p = { c, r }; occ.add(c + ',' + r); return p; };
    items.forEach((it) => { if (!placed[it.id]) placed[it.id] = nextFree(); });
    holder.innerHTML = '';
    items.forEach((it) => {
      const p = placed[it.id];
      const b = html(`<button class="d-icon ${selected.has(it.id) ? 'sel' : ''} ${it.shortcut ? 'shortcut' : ''}" data-id="${it.id}" style="left:${8 + p.c * cw}px;top:${8 + p.r * ch}px;width:${cw - 4}px;height:${ch - 4}px" aria-label="${esc(it.name)}">
        <span class="d-ic">${icon(it.icon)}${it.shortcut ? `<i class="d-arrow">${UI.external}</i>` : ''}</span><span class="d-label">${esc(it.name)}</span></button>`);
      b._item = it; b._pos = p;
      wireIcon(b); holder.appendChild(b);
    });
  };

  function launchItem(it) {
    if (it.user) {
      if (it.type === 'folder') OS.openApp('explorer', { path: 'Área de Trabalho/' + it.name });
      else OS.openApp('notepad', { file: it.name, desk: true });
    } else OS.launch(it);
  }

  let lastType = 'mouse';
  function wireIcon(b) {
    const it = b._item;
    b.addEventListener('dblclick', () => launchItem(it));
    b.addEventListener('click', (e) => { if (lastType === 'touch' && !drag.moved && !e.ctrlKey) launchItem(it); });
    b.addEventListener('contextmenu', (e) => {
      e.preventDefault(); e.stopPropagation();
      if (!selected.has(it.id)) { selected = new Set([it.id]); paintSel(); }
      OS.ctx(e.clientX, e.clientY, [
        { label: 'Abrir', icon: 'open', action: () => launchItem(it) },
        it.user ? { label: 'Renomear', icon: 'pencil', hint: 'F2', action: () => rename(it.id) } : null,
        { sep: true },
        { label: 'Excluir', icon: 'trash', hint: 'Del', action: () => deleteSelected() },
        { sep: true },
        { label: 'Propriedades', icon: 'info', action: () => OS.dialog({ title: 'Propriedades de ' + it.name, icon: it.icon, message: `<b>${esc(it.name)}</b><br>Tipo: ${it.user ? (it.type === 'folder' ? 'Pasta de arquivos' : 'Documento de texto') : it.shortcut ? 'Atalho da Internet' : 'Atalho de aplicativo'}<br>Local: Área de Trabalho` }) }
      ]);
    });
    b.addEventListener('pointerdown', (e) => {
      lastType = e.pointerType === 'touch' ? 'touch' : 'mouse';
      if (e.button !== 0) return;
      e.stopPropagation(); OS.closePanels();
      if (e.ctrlKey || e.shiftKey) { selected.has(it.id) ? selected.delete(it.id) : selected.add(it.id); }
      else if (!selected.has(it.id)) selected = new Set([it.id]);
      paintSel();
      drag = { sx: e.clientX, sy: e.clientY, moved: false, id: e.pointerId };
      window.addEventListener('pointermove', dragMove); window.addEventListener('pointerup', dragEnd, { once: true });
    });
  }
  let drag = { moved: false };
  function paintSel() { $$('.d-icon', holder).forEach((x) => x.classList.toggle('sel', selected.has(x.dataset.id))); }
  function dragMove(e) {
    const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
    if (!drag.moved && Math.hypot(dx, dy) < 6) return;
    drag.moved = true; document.body.classList.add('dragging');
    $$('.d-icon.sel', holder).forEach((x) => { x.classList.add('lifted'); x.style.transform = `translate(${dx}px,${dy}px)`; });
  }
  function dragEnd(e) {
    window.removeEventListener('pointermove', dragMove);
    document.body.classList.remove('dragging');
    if (drag.moved) {
      const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy, [cw, ch] = cell();
      const rows = Math.max(1, Math.floor((window.innerHeight - OS.TB - 16) / ch)), cols = Math.max(1, Math.floor(window.innerWidth / cw));
      const moving = $$('.d-icon.sel', holder), ids = new Set(moving.map((m) => m.dataset.id));
      const taken = new Set($$('.d-icon', holder).filter((x) => !ids.has(x.dataset.id)).map((x) => x._pos.c + ',' + x._pos.r));
      moving.forEach((m) => {
        let c = clamp(Math.round(m._pos.c + dx / cw), 0, cols - 1), r = clamp(Math.round(m._pos.r + dy / ch), 0, rows - 1);
        let guard = 0;
        while (taken.has(c + ',' + r) && guard++ < 400) { r++; if (r >= rows) { r = 0; c = Math.min(c + 1, cols - 1); } }
        taken.add(c + ',' + r); positions[m.dataset.id] = { c, r };
      });
      OS.store.set('deskPos', positions);
      setTimeout(() => { drag.moved = false; }, 0);
      OS.layoutDesktop();
    }
  }

  // seleção por retângulo
  const area = $('#desktop');
  let band = null;
  area.addEventListener('pointerdown', (e) => {
    if (e.target !== area && e.target !== holder && !e.target.classList.contains('wallpaper')) return;
    if (e.button !== 0) return;
    lastType = e.pointerType === 'touch' ? 'touch' : 'mouse';
    OS.closePanels();
    if (!e.ctrlKey) { selected = new Set(); paintSel(); }
    band = { x: e.clientX, y: e.clientY, el: $('#selbox') };
    const mv = (ev) => {
      if (!band) return;
      const x = Math.min(band.x, ev.clientX), y = Math.min(band.y, ev.clientY), w = Math.abs(ev.clientX - band.x), h = Math.abs(ev.clientY - band.y);
      if (w + h < 6) return;
      band.el.style.cssText = `display:block;left:${x}px;top:${y}px;width:${w}px;height:${h}px`;
      $$('.d-icon', holder).forEach((ic) => {
        const r = ic.getBoundingClientRect();
        const hit = !(r.right < x || r.left > x + w || r.bottom < y || r.top > y + h);
        if (hit) selected.add(ic.dataset.id); else if (!ev.ctrlKey) selected.delete(ic.dataset.id);
      });
      paintSel();
    };
    const up = () => { window.removeEventListener('pointermove', mv); if (band) band.el.style.display = 'none'; band = null; };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up, { once: true });
  });

  function rename(id) {
    const b = $(`.d-icon[data-id="${id}"]`, holder); if (!b) return;
    const it = b._item; if (!it.user) return;
    const lab = $('.d-label', b), old = it.name;
    const inp = html(`<input class="d-rename" value="${esc(old)}">`); lab.replaceWith(inp); inp.focus(); inp.select();
    const done = (ok) => {
      const v = inp.value.trim();
      if (ok && v && v !== old) {
        if (OS.userDesk().some((u) => u.name === v)) { OS.toast('Já existe um item com esse nome.', 'folder'); }
        else {
          const list = OS.userDesk().map((u) => (u.id === id ? Object.assign({}, u, { name: v }) : u)); OS.store.set('deskItems', list);
          if (it.type === 'txt') { const docs = OS.store.get('docs', {}); if (docs[old] != null) { docs[v] = docs[old]; delete docs[old]; OS.store.set('docs', docs); } }
        }
      }
      OS.layoutDesktop();
    };
    inp.onkeydown = (e) => { e.stopPropagation(); if (e.key === 'Enter') done(true); if (e.key === 'Escape') done(false); };
    inp.onblur = () => done(true);
    inp.onpointerdown = (e) => e.stopPropagation();
  }

  function deleteSelected() {
    const ids = Array.from(selected);
    const user = OS.userDesk(), trash = OS.trashItems();
    let moved = 0, denied = 0;
    ids.forEach((id) => {
      const u = user.find((x) => x.id === id);
      if (u) { trash.push(Object.assign({}, u, { deletedAt: Date.now() })); moved++; }
      else denied++;
    });
    if (moved) {
      OS.store.set('deskItems', user.filter((u) => !ids.includes(u.id)));
      OS.store.set('trash', trash); selected = new Set(); OS.sound('close');
      OS.emit('trash');
    }
    if (denied) OS.notify({ title: 'Esse item não pode ser excluído', body: 'Projetos e aplicativos do sistema ficam por aqui. 😄 Tente criar uma pasta nova e excluí-la.', icon: 'trash' });
    OS.layoutDesktop();
  }
  OS.on('trash', () => OS.layoutDesktop());
  OS.restoreTrash = (id) => {
    const trash = OS.trashItems(), it = trash.find((t) => t.id === id); if (!it) return;
    OS.store.set('trash', trash.filter((t) => t.id !== id));
    const user = OS.userDesk(); if (!user.some((u) => u.name === it.name)) { delete it.deletedAt; user.push(it); OS.store.set('deskItems', user); }
    OS.emit('trash');
  };
  OS.emptyTrash = () => {
    const docs = OS.store.get('docs', {});
    OS.trashItems().forEach((t) => { delete docs[t.name]; }); OS.store.set('docs', docs);
    OS.store.set('trash', []); OS.emit('trash');
  };

  function newItem(type) {
    const base = type === 'folder' ? 'Nova pasta' : 'Novo Documento de Texto';
    const names = new Set(OS.userDesk().map((u) => u.name));
    const ext = type === 'folder' ? '' : '.txt';
    let n = base + ext, i = 2; while (names.has(n)) n = `${base} (${i++})${ext}`;
    const id = 'u' + Date.now();
    OS.store.set('deskItems', OS.userDesk().concat({ id, name: n, type }));
    if (type === 'txt') { const docs = OS.store.get('docs', {}); docs[n] = ''; OS.store.set('docs', docs); }
    selected = new Set([id]); OS.layoutDesktop(); setTimeout(() => rename(id), 30);
  }

  area.addEventListener('contextmenu', (e) => {
    if (e.target.closest('.win, .d-icon, .ctx')) return;
    e.preventDefault(); OS.closePanels();
    const S = OS.settings;
    OS.ctx(e.clientX, e.clientY, [
      { label: 'Exibir', icon: 'grid', submenu: [
        { label: 'Ícones grandes', checked: S.iconSize === 'l', action: () => { OS.set('iconSize', 'l'); OS.layoutDesktop(); } },
        { label: 'Ícones médios', checked: S.iconSize === 'm', action: () => { OS.set('iconSize', 'm'); OS.layoutDesktop(); } },
        { label: 'Ícones pequenos', checked: S.iconSize === 's', action: () => { OS.set('iconSize', 's'); OS.layoutDesktop(); } },
        { sep: true }, { label: 'Mostrar ícones da área de trabalho', checked: S.showIcons, action: () => OS.set('showIcons', !S.showIcons) }] },
      { label: 'Classificar por nome', icon: 'list', action: () => { positions = {}; OS.store.set('deskPos', positions); OS.layoutDesktop(); } },
      { label: 'Atualizar', icon: 'refresh', action: () => { holder.classList.add('refresh'); OS.layoutDesktop(); setTimeout(() => holder.classList.remove('refresh'), 300); } },
      { sep: true },
      { label: 'Novo', icon: 'plus', submenu: [{ label: 'Pasta', icon: 'folder', action: () => newItem('folder') }, { label: 'Documento de Texto', icon: 'txt', action: () => newItem('txt') }] },
      { sep: true },
      { label: 'Abrir no Terminal', icon: 'terminal', action: () => OS.openApp('terminal') },
      { label: 'Personalizar', icon: 'palette', action: () => OS.openApp('settings', { page: 'background' }) },
      { label: 'Próximo papel de parede', icon: 'image', action: () => OS.wallpaper.next(1) },
      { sep: true },
      { label: 'Sobre o AdrielOS', icon: 'info', action: () => OS.openApp('winver') }
    ]);
  });
  document.addEventListener('keydown', (e) => {
    if (!document.body.classList.contains('session-on') || /INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || e.target.isContentEditable) return;
    if (OS.wm.active) return;
    if (e.key === 'F2' && selected.size === 1) rename(Array.from(selected)[0]);
    if (e.key === 'Delete' && selected.size) deleteSelected();
    if (e.key === 'Enter' && selected.size === 1) { const b = $(`.d-icon[data-id="${Array.from(selected)[0]}"]`); b && launchItem(b._item); }
    if (e.ctrlKey && e.key.toLowerCase() === 'a') { e.preventDefault(); selected = new Set(allItems().map((i) => i.id)); paintSel(); }
  });
  window.addEventListener('resize', () => OS.layoutDesktop());
  OS.on('setting', (d) => { if (d.key === 'iconSize') OS.layoutDesktop(); });

  /* ============================== SESSÃO / ENERGIA ============================== */
  const boot = $('#boot'), lock = $('#lock'), login = $('#login'), off = $('#shutdown'), bs = $('#bsod');
  boot.innerHTML = `<div class="boot-logo">${icon('start')}</div><div class="spinner" aria-label="Carregando">${'<i></i>'.repeat(5)}</div><div class="boot-name">Adriel<b>OS</b></div><button class="boot-skip" id="boot-skip">Pular <kbd>Esc</kbd></button>`;
  lock.innerHTML = `<div class="lock-clock"><div id="lock-time">--:--</div><div id="lock-date"></div></div>
    <div class="lock-msg"><b>Portfólio de Adriel Morback</b><span>Entre códigos, ideias e futebol, estou sempre criando algo novo.</span><small id="lock-hint">Clique, toque ou pressione qualquer tecla para entrar</small></div>
    <div class="lock-status">${UI.wifi}${UI.battery}</div>`;
  login.innerHTML = `<div class="login-box"><div id="login-avatar" class="login-avatar"></div><h2 id="login-name"></h2><p>Estudante de Ensino Médio Técnico</p>
    <button class="btn primary big" id="login-go">Entrar</button>
    <label class="login-auto"><input type="checkbox" id="login-auto"> Entrar automaticamente nas próximas vezes</label><div class="login-wait" id="login-wait" hidden><div class="spinner">${'<i></i>'.repeat(5)}</div><span>Bem-vindo</span></div></div>
    <div class="login-foot"><button id="login-power" title="Energia">${UI.power}</button></div>`;
  off.innerHTML = `<div class="off-msg" id="off-msg"></div><button class="off-btn" id="off-btn" hidden aria-label="Ligar">${UI.power}<span>Ligar o AdrielOS</span></button>`;

  const S = (OS.session = { state: 'boot', timer: null });
  const show = (el, on) => { el.hidden = !on; };

  S.start = function () {
    S.state = 'boot'; document.body.classList.remove('session-on');
    show(off, false); show(lock, false); show(login, false); show(bs, false); show(boot, true); boot.classList.remove('out');
    const finish = () => { clearTimeout(S.timer); window.removeEventListener('keydown', onKey); boot.classList.add('out'); setTimeout(() => show(boot, false), 450); OS.settings.autoLogin ? S.enter(true) : S.lock(true); };
    const onKey = (e) => { if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') finish(); };
    $('#boot-skip').onclick = finish; window.addEventListener('keydown', onKey);
    S.timer = setTimeout(finish, 2600);
  };

  S.lock = function (instant) {
    OS.closePanels(); OS.closeTaskView && OS.closeTaskView();
    S.state = 'lock'; document.body.classList.remove('session-on');
    show(login, false); show(lock, true); lock.classList.remove('up');
    if (instant) lock.classList.add('instant'); else lock.classList.remove('instant');
    const go = () => { if (S.state !== 'lock') return; lock.removeEventListener('pointerdown', go); window.removeEventListener('keydown', go); S.showLogin(); };
    setTimeout(() => { lock.addEventListener('pointerdown', go); window.addEventListener('keydown', go); }, 250);
    OS.emit('tick');
  };
  S.showLogin = function () {
    S.state = 'login'; lock.classList.add('up'); show(login, true); login.classList.remove('go');
    $('#login-avatar').innerHTML = OS.avatarHTML('xl'); $('#login-name').textContent = OS.profile.name;
    $('#login-auto').checked = !!OS.settings.autoLogin;
    $('#login-wait').hidden = true; $('#login-go').hidden = false; $('.login-auto', login).hidden = false;
    setTimeout(() => { show(lock, false); $('#login-go').focus(); }, 500);
  };
  $('#login-go').onclick = () => { OS.set('autoLogin', $('#login-auto').checked); $('#login-go').hidden = true; $('.login-auto', login).hidden = true; $('#login-wait').hidden = false; setTimeout(() => S.enter(), 900); };
  $('#login-power').onclick = (e) => { const r = e.currentTarget.getBoundingClientRect(); OS.ctx(r.left - 150, r.top - 4, OS.powerItems(), { fromBottom: true }); };

  let firstEnter = true;
  S.enter = function (quiet) {
    S.state = 'on'; show(lock, false); show(login, false); show(boot, false);
    document.body.classList.add('session-on');
    OS.layoutDesktop(); OS.initTaskbar && OS.initTaskbar();
    OS.sound('startup'); OS.startSlideshow();
    if (firstEnter) {
      firstEnter = false;
      setTimeout(() => {
        const touch = OS.isTouch();
        OS.notify({ title: 'Bem-vindo ao AdrielOS!', body: touch ? 'Toque nos ícones para abrir. Use a barra de baixo para o menu Iniciar.' : 'Dê dois cliques nos ícones, abra o menu Iniciar ou clique com o botão direito na área de trabalho.', icon: 'about', app: 'AdrielOS', actions: [{ label: 'Ver meus projetos', run: () => OS.openApp('explorer', { path: 'Projetos' }) }], sticky: true });
        let seen = false; try { seen = sessionStorage.getItem('adrielos.welcomed'); sessionStorage.setItem('adrielos.welcomed', '1'); } catch (e) { /* ignora */ }
        if (!seen && !quiet && !OS.isMobile()) OS.openApp('about');
      }, 700);
    }
    window.dispatchEvent(new Event('resize'));
  };

  S.closeAll = () => OS.wins.slice().forEach((w) => { w.handlers.close = []; w.close(); });
  S.signOut = () => { OS.closePanels(); S.closeAll(); setTimeout(() => { S.state = 'login'; document.body.classList.remove('session-on'); show(login, true); S.showLogin(); show(lock, false); }, 300); };

  function powerScreen(msg, then) {
    OS.closePanels(); OS.sound('shutdown'); S.closeAll();
    show(off, true); off.classList.remove('dark'); $('#off-btn').hidden = true; $('#off-msg').innerHTML = `<div class="spinner">${'<i></i>'.repeat(5)}</div><span>${msg}</span>`;
    document.body.classList.remove('session-on'); S.state = 'off';
    setTimeout(then, 1700);
  }
  S.shutdown = () => powerScreen('Desligando…', () => { off.classList.add('dark'); $('#off-msg').innerHTML = ''; $('#off-btn').hidden = false; $('#off-btn').focus(); });
  $('#off-btn').onclick = () => { show(off, false); S.start(); };
  S.restart = () => powerScreen('Reiniciando…', () => { show(off, false); firstEnter = true; try { sessionStorage.removeItem('adrielos.welcomed'); } catch (e) { /* ignora */ } S.start(); });
  S.sleep = () => {
    OS.closePanels(); show(off, true); off.classList.add('dark'); $('#off-msg').innerHTML = ''; $('#off-btn').hidden = true; S.state = 'sleep';
    const wake = () => { window.removeEventListener('keydown', wake); off.removeEventListener('pointerdown', wake); show(off, false); S.lock(); };
    setTimeout(() => { window.addEventListener('keydown', wake); off.addEventListener('pointerdown', wake); }, 600);
  };

  S.bsod = function () {
    OS.closePanels(); show(bs, true); S.state = 'bsod'; OS.sound('error');
    bs.innerHTML = `<div class="bs-inner"><div class="bs-face">:(</div><p>Seu AdrielOS encontrou um problema e precisa ser reiniciado. Estamos apenas coletando algumas informações de erro e, em seguida, reiniciaremos para você.</p><p class="bs-pct"><span id="bs-n">0</span>% concluído</p><div class="bs-info"><div class="bs-qr">${'<i></i>'.repeat(49)}</div><div><p>Para saber mais, pesquise online por este erro:</p><p><b>FUTEBOL_SEM_BOLA</b> (0x0000FUT)</p><p class="bs-small">Mentira! Está tudo bem — é só um easter egg. 😄</p></div></div></div>`;
    let n = 0; const t = setInterval(() => { n += Math.ceil(Math.random() * 9); if (n >= 100) { n = 100; clearInterval(t); setTimeout(() => { show(bs, false); S.closeAll(); firstEnter = true; S.start(); }, 700); } const el = $('#bs-n'); if (el) el.textContent = n; }, 260);
  };
})();
