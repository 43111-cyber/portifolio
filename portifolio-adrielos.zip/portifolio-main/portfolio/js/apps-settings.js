/* ==========================================================================
   AdrielOS — CONFIGURAÇÕES
   Personalização (plano de fundo, cores, barra de tarefas), sistema, contas,
   acessibilidade, atualização e informações do dispositivo.
   ========================================================================== */
(function () {
  'use strict';
  const { $, $$, esc, html } = OS;
  const UI = window.UI, icon = window.icon, DATA = window.DATA;

  const PAGES = [
    { id: 'home', title: 'Início', group: 'Sistema', i: 'monitor' },
    { id: 'display', title: 'Tela e brilho', group: 'Sistema', kw: 'brilho tela display luminosidade', i: 'sun' },
    { id: 'sound', title: 'Som', group: 'Sistema', kw: 'volume áudio efeitos sonoros mudo', i: 'volume' },
    { id: 'notifications', title: 'Notificações', group: 'Sistema', kw: 'foco não perturbe avisos', i: 'bell' },
    { id: 'battery', title: 'Bateria', group: 'Sistema', kw: 'economia de bateria energia', i: 'battery' },
    { id: 'background', title: 'Plano de fundo', group: 'Personalização', kw: 'wallpaper papel de parede imagem fundo slideshow apresentação', i: 'image' },
    { id: 'colors', title: 'Cores e tema', group: 'Personalização', kw: 'tema escuro claro modo acento cor transparência', i: 'palette' },
    { id: 'taskbar', title: 'Barra de tarefas', group: 'Personalização', kw: 'alinhamento centro esquerda botões widgets', i: 'taskview' },
    { id: 'icons', title: 'Ícones da área de trabalho', group: 'Personalização', kw: 'tamanho ícones mostrar', i: 'grid' },
    { id: 'accounts', title: 'Contas', group: 'Contas', kw: 'foto perfil avatar nome usuário login automático', i: 'user' },
    { id: 'time', title: 'Hora e idioma', group: 'Hora e idioma', kw: '24 horas relógio segundos formato', i: 'clock' },
    { id: 'accessibility', title: 'Acessibilidade', group: 'Acessibilidade', kw: 'texto grande animações reduzir', i: 'accessibility' },
    { id: 'update', title: 'AdrielOS Update', group: 'Atualização', kw: 'atualizar atualização verificar versão', i: 'refresh' },
    { id: 'about', title: 'Sobre', group: 'Sistema', kw: 'especificações dispositivo versão sobre', i: 'info' }
  ];
  OS.settingsPages = PAGES;

  const ACCENTS = ['#0078d4', '#0063b1', '#8e8cd8', '#744da9', '#c239b3', '#e3008c', '#e74856', '#ff8c00', '#f7630c', '#ffb900', '#16c60c', '#00cc6a', '#00b294', '#038387', '#6b7a8f', '#7a7574'];

  const row = (title, desc, ctrl, ic) => `<div class="s-row">${ic ? `<span class="s-ic">${UI[ic] || icon(ic)}</span>` : ''}<div class="s-t"><b>${title}</b>${desc ? `<small>${desc}</small>` : ''}</div><div class="s-c">${ctrl}</div></div>`;
  const sw = (k) => `<button class="switch" role="switch" data-toggle="${k}" aria-label="${k}"><i></i></button>`;
  const range = (k, min, max) => `<input type="range" data-range="${k}" min="${min}" max="${max}">`;
  const select = (k, opts) => `<select data-select="${k}">${opts.map((o) => `<option value="${o[0]}">${o[1]}</option>`).join('')}</select>`;

  OS.registerApp({
    id: 'settings', title: 'Configurações', icon: 'settings', w: 940, h: 640, minW: 460, minH: 320, single: true, keywords: 'configurações settings painel de controle personalizar sistema',
    build(win, opts) {
      let page = opts.page || 'home', q = '';
      const root = html(`<div class="st"><aside class="st-nav"><div class="st-user" id="st-user"></div><div class="ex-find">${UI.search}<input id="st-q" placeholder="Localizar uma configuração"></div><nav id="st-links"></nav></aside><main class="st-main"><div class="st-title"><h1 id="st-h"></h1></div><div class="st-page" id="st-page"></div></main></div>`);
      win.body.appendChild(root);
      const main = $('#st-page', root);

      function nav() {
        $('#st-user', root).innerHTML = `${OS.avatarHTML('md')}<div><b>${esc(OS.profile.name)}</b><small>Conta local</small></div>`;
        const list = PAGES.filter((p) => !q || (p.title + ' ' + (p.kw || '')).toLowerCase().includes(q));
        $('#st-links', root).innerHTML = list.map((p) => `<button class="sl ${p.id === page ? 'on' : ''}" data-p="${p.id}"><span>${UI[p.i] || icon(p.i)}</span>${p.title}</button>`).join('') || '<div class="ex-empty">Nada encontrado.</div>';
        $$('.sl', root).forEach((b) => (b.onclick = () => go(b.dataset.p)));
      }
      function go(id) {
        page = id; nav(); const meta = PAGES.find((p) => p.id === id);
        $('#st-h', root).textContent = meta.title; main.innerHTML = ''; main.scrollTop = 0;
        const el = html(`<div class="st-in">${(R[id] || R.home)()}</div>`); main.appendChild(el);
        bind(el); (W[id] || (() => { }))(el);
        win.setTitle(meta.title + ' — Configurações');
      }
      function bind(el) {
        const S = OS.settings;
        $$('[data-toggle]', el).forEach((b) => { const k = b.dataset.toggle; b.classList.toggle('on', !!S[k]); b.onclick = () => { OS.set(k, !OS.settings[k]); b.classList.toggle('on', !!OS.settings[k]); OS.sound('click'); }; });
        $$('[data-select]', el).forEach((s) => { const k = s.dataset.select; s.value = String(S[k]); s.onchange = () => { let v = s.value; if (v === 'true') v = true; else if (v === 'false') v = false; OS.set(k, v); }; });
        $$('[data-range]', el).forEach((r) => { const k = r.dataset.range; r.value = S[k]; r.oninput = () => { OS.set(k, +r.value); if (k === 'volume') OS.set('muted', +r.value === 0); }; if (k === 'volume') r.onchange = () => OS.sound('click'); });
        $$('[data-goto]', el).forEach((b) => (b.onclick = () => go(b.dataset.goto)));
      }

      const R = {
        home() {
          return `<div class="st-hero card"><div class="hero-av">${OS.avatarHTML('lg')}</div><div><h2>${esc(OS.profile.name)}</h2><p>${esc(DATA.me.role)}</p></div><div class="hero-mon" style="background-image:var(--wp-url)"></div></div>
            <div class="st-tiles">${[['background', 'Plano de fundo', 'Personalize sua área de trabalho', 'image'], ['colors', 'Cores e tema', 'Modo claro/escuro e acento', 'palette'], ['taskbar', 'Barra de tarefas', 'Alinhamento e botões', 'taskview'], ['accounts', 'Contas', 'Sua foto e nome', 'user'], ['sound', 'Som', 'Volume e efeitos', 'volume'], ['update', 'AdrielOS Update', 'Você está atualizado', 'refresh']].map((t) => `<button class="card tile" data-goto="${t[0]}"><span>${UI[t[3]] || icon(t[3])}</span><b>${t[1]}</b><small>${t[2]}</small></button>`).join('')}</div>`;
        },
        display() { return row('Brilho', 'Ajusta o brilho da tela (escurece a interface)', range('brightness', 20, 100), 'sun') + row('Tema', 'Modo claro ou escuro', select('theme', [['dark', 'Escuro'], ['light', 'Claro'], ['auto', 'Automático (sistema)']]), 'moon') + row('Resolução da janela', 'Tamanho atual da área visível do navegador', `<b>${innerWidth} × ${innerHeight}</b>`, 'monitor'); },
        sound() { return row('Volume principal', 'Controla efeitos e a Rádio AdrielOS', range('volume', 0, 100), 'volume') + row('Silenciar', '', sw('muted'), 'volumeMute') + row('Sons do sistema', 'Cliques, abrir/fechar janelas, notificações e som de inicialização', sw('sound'), 'bell') + `<div class="s-row"><div class="s-t"><b>Testar sons</b></div><div class="s-c"><button class="btn" data-snd="click">Clique</button><button class="btn" data-snd="toast">Notificação</button><button class="btn" data-snd="startup">Inicialização</button></div></div>`; },
        notifications() { return row('Não perturbe', 'Esconde os avisos na tela; eles continuam na Central de Notificações', sw('focus'), 'bellOff') + `<div class="s-row"><div class="s-t"><b>Enviar notificação de teste</b></div><div class="s-c"><button class="btn primary" id="n-test">Enviar</button></div></div>`; },
        battery() { return row('Economia de bateria', 'Reduz efeitos visuais (animações e transparência)', sw('saver'), 'battery') + row('Nível da bateria', OS.battery.real ? 'Lido do seu dispositivo' : 'Seu navegador não informa a bateria (valor simulado)', `<b>${Math.round(OS.battery.level * 100)}%${OS.battery.charging ? ' ⚡' : ''}</b>`, 'battery'); },
        background() {
          const groups = {}; OS.wallpaper.list().forEach((w) => (groups[w.group] = (groups[w.group] || []).concat(w)));
          return `<div class="wp-prev card"><div class="monitor"><div class="mon-wp" id="wp-mon"></div><div class="mon-tb"></div></div><div><b id="wp-name"></b><small>Plano de fundo atual</small></div></div>
            ${row('Slideshow', 'Troca o plano de fundo automaticamente a cada ~25 segundos', sw('slideshow'), 'image')}
            <div class="s-row"><div class="s-t"><b>Escolher sua própria imagem</b><small>A imagem fica salva apenas neste navegador</small></div><div class="s-c"><button class="btn" id="wp-up">${UI.image} Procurar fotos</button><button class="btn" id="wp-rm" hidden>Remover</button></div></div>
            ${Object.keys(groups).map((g) => `<h3 class="sec">${g}</h3><div class="wp-grid">${groups[g].map((w) => `<button class="wp-th" data-w="${w.id}" title="${esc(w.name)}"><span class="img" style="${w.thumb ? `background-image:url('${w.thumb}')` : `background:${w.css || w.solid}`}"></span><small>${esc(w.name)}</small></button>`).join('')}</div>`).join('')}`;
        },
        colors() {
          return `<div class="s-row"><div class="s-t"><b>Escolha seu modo</b><small>Controla o tema de janelas e do sistema</small></div><div class="s-c">${select('theme', [['dark', 'Escuro'], ['light', 'Claro'], ['auto', 'Automático (sistema)']])}</div></div>
            ${row('Efeitos de transparência', 'Janelas e painéis com efeito de vidro fosco', sw('transparency'), 'palette')}
            <h3 class="sec">Cor de destaque</h3><div class="card acc"><div class="swatches" id="swatches">${ACCENTS.map((c) => `<button class="sw" data-c="${c}" style="background:${c}" aria-label="${c}"></button>`).join('')}</div>
            <label class="custom-c">Cor personalizada <input type="color" id="acc-custom"></label></div>`;
        },
        taskbar() { return row('Alinhamento da barra de tarefas', '', select('align', [['center', 'Centro'], ['left', 'Esquerda']]), 'taskview') + '<h3 class="sec">Itens da barra de tarefas</h3>' + row('Pesquisar', '', sw('btnSearch'), 'search') + row('Visão de Tarefas', '', sw('btnTaskview'), 'taskview') + row('Widgets', '', sw('btnWidgets'), 'widgets'); },
        icons() { return row('Tamanho dos ícones', '', select('iconSize', [['s', 'Pequenos'], ['m', 'Médios'], ['l', 'Grandes']]), 'grid') + row('Mostrar ícones da área de trabalho', '', sw('showIcons'), 'monitor') + `<div class="s-row"><div class="s-t"><b>Reorganizar ícones</b><small>Volta os ícones para a posição padrão</small></div><div class="s-c"><button class="btn" id="ic-reset">Reorganizar</button></div></div>`; },
        accounts() { return `<div class="card acct"><div class="acct-av" id="acct-av"></div><div class="acct-f"><label>Nome de exibição<input id="acct-name" value="${esc(OS.profile.name)}"></label><div class="acct-b"><button class="btn primary" id="acct-photo">${UI.image} Escolher foto</button><button class="btn" id="acct-rm">Remover foto</button></div></div></div>` + row('Entrar automaticamente', 'Pula as telas de bloqueio e login nas próximas visitas', sw('autoLogin'), 'user'); },
        time() { return row('Formato de 24 horas', 'Desligue para ver AM/PM', sw('clock24'), 'clock') + row('Mostrar segundos no relógio', 'Na barra de tarefas', sw('showSeconds'), 'clock') + row('Idioma', '', '<b>Português (Brasil)</b>', 'cloud') + row('Fuso horário', '', `<b>${Intl.DateTimeFormat().resolvedOptions().timeZone}</b>`, 'clock'); },
        accessibility() { return row('Texto maior', 'Aumenta o tamanho do texto na interface', sw('bigText'), 'accessibility') + row('Efeitos de animação', 'Desligue para reduzir movimento', sw('animations'), 'accessibility') + row('Efeitos de transparência', '', sw('transparency'), 'palette'); },
        update() { return `<div class="card upd"><div class="upd-ic">${UI.check}</div><div><h2 id="upd-t">Você está atualizado</h2><small id="upd-s">Última verificação: hoje, ${OS.fmtTime(new Date())}</small></div><button class="btn primary" id="upd-btn">Verificar se há atualizações</button></div><div class="upd-bar" id="upd-bar" hidden><i></i></div>${row('Versão', '', '<b>AdrielOS 11 Edição Portfólio — 26H2</b>', 'info')}`; },
        about() {
          const spec = [['Nome do dispositivo', 'ADRIEL-PC'], ['Processador', 'Cérebro de dev em evolução @ 100% de curiosidade'], ['RAM instalada', '16 GB de ideias (e café)'], ['Tipo de sistema', 'Sistema operacional web de 64 bits'], ['Edição', 'AdrielOS 11 Edição Portfólio'], ['Versão', '26H2'], ['Tecnologias', 'HTML5 · CSS3 · JavaScript (puro)'], ['Navegador', esc((navigator.userAgent.match(/(Firefox|Edg|Chrome|Safari)\/[\d.]+/) || ['desconhecido'])[0])], ['Tela', `${innerWidth} × ${innerHeight} @${window.devicePixelRatio}x`], ['Idioma', navigator.language]];
          return `<div class="card specs"><dl>${spec.map((s) => `<dt>${s[0]}</dt><dd>${s[1]}</dd>`).join('')}</dl></div><div class="s-row"><div class="s-t"><b>Reiniciar o AdrielOS</b><small>Volta à tela de inicialização</small></div><div class="s-c"><button class="btn" id="ab-restart">Reiniciar</button></div></div>`;
        }
      };
      const W = {
        sound(el) { $$('[data-snd]', el).forEach((b) => (b.onclick = () => OS.sound(b.dataset.snd))); },
        notifications(el) { $('#n-test', el).onclick = () => OS.notify({ title: 'Notificação de teste', body: 'Tudo funcionando por aqui! ✨', icon: 'settings', app: 'Configurações', force: true }); },
        background(el) {
          const mark = () => { const w = OS.wallpaper.current(); $$('.wp-th', el).forEach((b) => b.classList.toggle('on', b.dataset.w === w.id)); $('#wp-name', el).textContent = w.name; const m = $('#wp-mon', el); m.style.backgroundImage = w.src && !w.live && !w.solid ? `url("${w.src}")` : 'none'; m.style.background = w.live ? w.css : w.solid || ''; if (w.src && !w.live && !w.solid) m.style.backgroundImage = `url("${w.src}")`; };
          $$('.wp-th', el).forEach((b) => (b.onclick = () => { OS.wallpaper.set(b.dataset.w); mark(); }));
          $('#wp-up', el).onclick = () => { const inp = html('<input type="file" accept="image/*" hidden>'); document.body.appendChild(inp); inp.onchange = () => { if (inp.files[0]) OS.wallpaper.setCustom(inp.files[0], (ok) => ok && go('background')); inp.remove(); }; inp.click(); };
          const rm = $('#wp-rm', el); if (OS.store.get('customWallpaper', null)) { rm.hidden = false; rm.onclick = () => { OS.store.del('customWallpaper'); if (OS.settings.wallpaper === 'custom') OS.wallpaper.set('flor_azul_escuro'); go('background'); }; }
          mark();
        },
        colors(el) {
          const mark = () => { $$('.sw', el).forEach((b) => b.classList.toggle('on', b.dataset.c.toLowerCase() === OS.settings.accent.toLowerCase())); $('#acc-custom', el).value = OS.settings.accent; };
          $$('.sw', el).forEach((b) => (b.onclick = () => { OS.set('accent', b.dataset.c); mark(); }));
          $('#acc-custom', el).oninput = (e) => { OS.set('accent', e.target.value); mark(); }; mark();
        },
        icons(el) { $('#ic-reset', el).onclick = () => { OS.store.del('deskPos'); OS.toast('Ícones reorganizados.', 'settings'); location.reload; OS.layoutDesktop(); }; },
        accounts(el) {
          const av = () => { $('#acct-av', el).innerHTML = OS.avatarHTML('xl'); };
          av();
          $('#acct-name', el).onchange = (e) => { const v = e.target.value.trim(); if (v) { OS.profile.name = v; OS.saveProfile(); } };
          $('#acct-photo', el).onclick = () => { const inp = html('<input type="file" accept="image/*" hidden>'); document.body.appendChild(inp); inp.onchange = () => { if (inp.files[0]) OS.readImageFile(inp.files[0], 320, (d) => { if (d) { OS.profile.avatar = d; OS.saveProfile(); av(); nav(); } }); inp.remove(); }; inp.click(); };
          $('#acct-rm', el).onclick = () => { OS.profile.avatar = null; OS.saveProfile(); av(); nav(); };
        },
        update(el) {
          $('#upd-btn', el).onclick = () => {
            const bar = $('#upd-bar', el), i = $('i', bar), b = $('#upd-btn', el); bar.hidden = false; b.disabled = true; $('#upd-t', el).textContent = 'Verificando atualizações…'; let p = 0;
            const t = setInterval(() => { p += 7 + Math.random() * 12; i.style.width = Math.min(100, p) + '%'; if (p >= 100) { clearInterval(t); bar.hidden = true; i.style.width = '0'; b.disabled = false; $('#upd-t', el).textContent = 'Você está atualizado'; $('#upd-s', el).textContent = 'Última verificação: agora mesmo'; OS.notify({ title: 'Tudo em dia!', body: 'Nenhuma atualização disponível. O AdrielOS 11 já é a versão mais recente.', icon: 'settings', app: 'AdrielOS Update' }); } }, 220);
          };
        },
        about(el) { $('#ab-restart', el).onclick = () => OS.session.restart(); }
      };
      $('#st-q', root).oninput = (e) => { q = e.target.value.trim().toLowerCase(); nav(); };
      OS.on('profile', () => win.el.isConnected && nav());
      OS.on('wallpaper', () => { if (win.el.isConnected && page === 'background') { const m = $('#wp-mon', root); if (m) go('background'); } });
      win.onOpenAgain = (o) => { if (o.page) go(o.page); };
      go(PAGES.some((p) => p.id === page) ? page : 'home');
    }
  });
})();
