/* ==========================================================================
   AdrielOS — APLICATIVOS PRINCIPAIS
   Sistema de arquivos virtual, Explorador, Navegador, Sobre, Habilidades,
   GitHub, Contato, Lixeira, Leitor de PDF, Executar e Sobre o AdrielOS.
   ========================================================================== */
(function () {
  'use strict';
  const { $, $$, esc, html } = OS;
  const UI = window.UI, icon = window.icon, DATA = window.DATA;
  window.APP_ICONS.explorer = window.APP_ICONS.projects;

  /* ============================ SISTEMA DE ARQUIVOS ============================ */
  const README = `Bem-vindo ao AdrielOS!
======================

Este site é o portfólio interativo de Adriel Morback, feito como um
sistema operacional que roda no navegador (HTML, CSS e JavaScript puros).

Dicas:
 - Dê dois cliques nos ícones (ou um toque no celular) para abrir.
 - Clique no botão Iniciar e explore todos os aplicativos.
 - Botão direito na área de trabalho: novo, exibir, personalizar...
 - Arraste uma janela para a borda da tela para encaixar (snap).
 - Passe o mouse no botão maximizar para ver os layouts de encaixe.
 - Abra o Terminal e digite "help".
 - Ctrl+Alt+R abre o "Executar".

Projetos: abra a pasta "Projetos" no Explorador de Arquivos.
`;
  const ABOUT_TXT = `${DATA.me.name}\n${DATA.me.role}\n\n"${DATA.me.tagline}"\n\n${DATA.me.bio}\n`;
  const CONTACT_TXT = `Contato — ${DATA.me.name}\n\nE-mail:   ${DATA.me.email}\nWhatsApp: ${DATA.me.whatsappLabel}  (https://wa.me/${DATA.me.whatsapp})\nGitHub:   ${DATA.me.github}\n`;
  const IDEAS_TXT = `Próximos projetos (em construção)\n\n- Novos jogos 2D com Canvas\n- Sites e sistemas web completos\n- Protótipos de aplicativos\n- Ferramentas úteis para estudantes\n\nTem uma sugestão? Fale comigo pelo app Contato!\n`;
  const TRACKS = ['Madrugada Lo-fi', 'Intervalo do Jogo', 'Código à Noite', 'Chuva no Estádio'];

  const folder = (name, children, extra) => Object.assign({ type: 'folder', name, children }, extra || {});
  const file = (name, kind, extra) => Object.assign({ type: 'file', name, kind }, extra || {});

  function buildTree() {
    const docs = OS.store.get('docs', {});
    const deskNames = new Set(OS.userDesk().map((u) => u.name));
    const savedDocs = Object.keys(docs).filter((n) => !deskNames.has(n) && !['leia-me.txt'].includes(n)).map((n) => file(n, 'txt', { user: true, icon: 'txt' }));
    const wallpapers = OS.wallpaper.list().filter((w) => w.src && !w.live && !w.solid).map((w) => file(w.id + (w.src.endsWith('.svg') ? '.svg' : '.jpg'), 'image', { src: w.src, thumb: w.thumb || w.src, title: w.name, wid: w.id }));
    const projImgs = DATA.projects.map((p) => file(p.image.split('/').pop(), 'image', { src: p.image, thumb: p.image, title: p.short })).concat([file('beico_street.jpg', 'image', { src: 'assets/projects/beico_street.jpg', thumb: 'assets/projects/beico_street.jpg', title: 'Beiço Street — arte' })]);
    const desk = OS.userDesk().map((u) => (u.type === 'folder' ? folder(u.name, [], { icon: 'folder', user: true }) : file(u.name, 'txt', { user: true, desk: true, icon: 'txt' })));
    const shortcuts = [
      file('Sobre Adriel', 'app', { app: 'about', icon: 'about' }), file('Meus Projetos', 'app', { app: 'explorer', arg: { path: 'Projetos' }, icon: 'projects' }),
      file('Habilidades', 'app', { app: 'skills', icon: 'skills' }), file('GitHub', 'app', { app: 'github', icon: 'github' }), file('Contato', 'app', { app: 'contact', icon: 'contact' }),
      file('Beiço Street', 'link', { url: DATA.projects[0].site, icon: 'soccer' })
    ];
    return folder('Este Computador', [
      folder('Área de Trabalho', shortcuts.concat(desk), { icon: 'monitor' }),
      folder('Projetos', DATA.projects.map((p) => (p.future
        ? folder(p.short, [file('ideias.txt', 'txt', { content: IDEAS_TXT, icon: 'txt' })], { project: p, thumb: p.image })
        : file(p.short, 'project', { project: p, thumb: p.image }))), { icon: 'projects' }),
      folder('Documentos', [
        file('MorfaIAs-proposta.pdf', 'pdf', { src: DATA.projects[3].pdf, icon: 'pdf' }),
        file('leia-me.txt', 'txt', { content: README, icon: 'txt' }), file('sobre-mim.txt', 'txt', { content: ABOUT_TXT, icon: 'txt' }), file('contato.txt', 'txt', { content: CONTACT_TXT, icon: 'txt' })
      ].concat(savedDocs), { icon: 'folder' }),
      folder('Imagens', [folder('Papéis de parede', wallpapers, { icon: 'folder' }), folder('Projetos', projImgs, { icon: 'folder' })], { icon: 'image' }),
      folder('Música', TRACKS.map((t, i) => file(t + '.mp3', 'music', { track: i, icon: 'music' })), { icon: 'music' }),
      folder('Downloads', [], { icon: 'folder' })
    ], { icon: 'monitor' });
  }

  const vfs = (OS.vfs = {
    tree: buildTree,
    resolve(path) {
      let n = buildTree(); if (!path) return n;
      for (const seg of path.split('/')) { n = n.children && n.children.find((c) => c.name === seg); if (!n) return null; }
      return n;
    },
    walk() {
      const out = [];
      (function rec(n, p) { (n.children || []).forEach((c) => { const cp = p ? p + '/' + c.name : c.name; if (c.type === 'folder') rec(c, cp); else out.push(Object.assign({}, c, { path: p })); }); })(buildTree(), '');
      return out;
    },
    open(node, ctx) {
      switch (node.kind) {
        case 'project': { const p = node.project; if (p.site) OS.openUrl(p.site, p.short); else if (p.pdf) OS.openApp('pdf', { src: p.pdf, title: p.short }); break; }
        case 'pdf': OS.openApp('pdf', { src: node.src, title: node.name }); break;
        case 'txt': OS.openApp('notepad', { file: node.name, content: node.content, desk: node.desk, forceNew: true }); break;
        case 'image': OS.openApp('photos', { src: node.src }); break;
        case 'app': OS.openApp(node.app, node.arg || {}); break;
        case 'link': OS.openUrl(node.url); break;
        case 'music': OS.openApp('music', { track: node.track }); break;
        default: ctx && ctx.navigate && ctx.navigate(node);
      }
    }
  });
  vfs.TRACKS = TRACKS;

  /* ================================ EXPLORADOR ================================ */
  OS.registerApp({
    id: 'explorer', title: 'Explorador de Arquivos', short: 'Explorador', icon: 'projects', w: 960, h: 600, minW: 420, minH: 300,
    keywords: 'arquivos pastas projetos documentos imagens explorer',
    build(win, opts) {
      let path = opts.path || 'Projetos', hist = [path], hi = 0, view = OS.store.get('exView', 'grid'), query = '', sel = null, preview = true;
      const root = html(`<div class="ex">
        <div class="ex-cmd">
          <button class="cmd" data-c="open">${UI.open}<span>Abrir</span></button>
          <button class="cmd" data-c="ext">${UI.external}<span>Abrir site</span></button>
          <button class="cmd" data-c="gh">${icon('github')}<span>GitHub</span></button>
          <i class="cmd-sep"></i>
          <button class="cmd" data-c="view">${UI.list}<span>Exibir</span></button>
          <button class="cmd" data-c="prev">${UI.snap}<span>Painel</span></button>
        </div>
        <div class="ex-nav">
          <button class="nb" data-n="back" aria-label="Voltar">${UI.back}</button><button class="nb" data-n="fwd" aria-label="Avançar">${UI.forward}</button><button class="nb" data-n="up" aria-label="Acima">${UI.up}</button><button class="nb" data-n="ref" aria-label="Atualizar">${UI.refresh}</button>
          <div class="ex-addr" id="ex-addr"></div><div class="ex-find">${UI.search}<input placeholder="Pesquisar" id="ex-q"></div>
        </div>
        <div class="ex-main"><aside class="ex-side" id="ex-side"></aside><div class="ex-content" id="ex-content" tabindex="0"></div><aside class="ex-prev" id="ex-prev"></aside></div>
        <div class="ex-status" id="ex-status"></div></div>`);
      win.body.appendChild(root);
      const $r = (s) => $(s, root);

      function nodeIcon(n, big) {
        if (n.thumb && (n.kind === 'project' || n.kind === 'image' || n.project)) return `<img class="th" src="${n.thumb}" alt="" loading="lazy">`;
        if (n.type === 'folder') return icon(n.icon || 'folder');
        return icon(n.kind === 'pdf' ? 'pdf' : n.kind === 'music' ? 'music' : n.kind === 'link' ? 'link' : n.icon || (n.kind === 'txt' ? 'txt' : 'folder'));
      }
      const kindLabel = (n) => ({ project: 'Projeto', pdf: 'Documento PDF', txt: 'Documento de texto', image: 'Imagem', app: 'Atalho', link: 'Atalho da Internet', music: 'Faixa de áudio' }[n.kind] || (n.type === 'folder' ? 'Pasta de arquivos' : 'Arquivo'));

      function go(p, push) {
        if (!vfs.resolve(p) && p !== '') { OS.toast('Caminho não encontrado.', 'folder'); return; }
        if (push !== false) { hist = hist.slice(0, hi + 1); hist.push(p); hi = hist.length - 1; }
        path = p; sel = null; query = ''; $r('#ex-q').value = ''; draw();
      }
      function draw() {
        const node = vfs.resolve(path) || vfs.resolve(''); const segs = path ? path.split('/') : [];
        win.setTitle(segs.length ? segs[segs.length - 1] : 'Este Computador'); win.setIcon(node.icon || 'projects');
        // endereço
        const addr = $r('#ex-addr'); addr.innerHTML = `<button data-p="">${icon('monitor')}</button>`;
        segs.forEach((s, i) => { addr.innerHTML += `<i>${UI.chevronRight}</i><button data-p="${esc(segs.slice(0, i + 1).join('/'))}">${esc(s)}</button>`; });
        $$('button', addr).forEach((b) => (b.onclick = () => go(b.dataset.p)));
        // sidebar
        const side = $r('#ex-side');
        const sideItems = [['Área de Trabalho', 'monitor'], ['Projetos', 'projects'], ['Documentos', 'folder'], ['Imagens', 'image'], ['Música', 'music'], ['Downloads', 'folder']];
        side.innerHTML = `<div class="sd-h">Acesso rápido</div>` + sideItems.map(([n, ic]) => `<button class="sd ${path === n || path.startsWith(n + '/') ? 'on' : ''}" data-p="${n}"><span>${icon(ic)}</span>${n}</button>`).join('') +
          `<div class="sd-h">Este Computador</div><button class="sd ${path === '' ? 'on' : ''}" data-p=""><span>${icon('monitor')}</span>Este Computador</button><button class="sd" data-t="1"><span>${icon('trash')}</span>Lixeira</button>`;
        $$('.sd', side).forEach((b) => (b.onclick = () => (b.dataset.t ? OS.openApp('trash') : go(b.dataset.p))));
        // conteúdo
        let items = node.children || [];
        if (query) { const q = query.toLowerCase(); items = vfs.walk().filter((f) => f.name.toLowerCase().includes(q)).concat(items.filter((c) => c.type === 'folder' && c.name.toLowerCase().includes(q))); }
        const c = $r('#ex-content'); c.className = 'ex-content ' + view; c.innerHTML = '';
        if (view === 'list') c.innerHTML = '<div class="ex-row head"><span>Nome</span><span>Tipo</span><span>Descrição</span></div>';
        if (!items.length) c.innerHTML += `<div class="ex-empty">${query ? 'Nenhum item corresponde à sua pesquisa.' : 'Esta pasta está vazia.'}</div>`;
        items.forEach((n) => {
          const desc = n.project ? n.project.badge.replace(/^\S+\s/, '') : '';
          const el = html(view === 'list'
            ? `<div class="ex-row it" tabindex="0"><span class="nm">${nodeIcon(n)}${esc(n.name)}</span><span>${kindLabel(n)}</span><span>${esc(desc)}</span></div>`
            : `<div class="ex-item it" tabindex="0" title="${esc(n.name)}"><span class="ico ${n.thumb ? 'has-th' : ''}">${nodeIcon(n)}</span><span class="nm">${esc(n.name)}</span></div>`);
          el.onclick = () => { sel = n; $$('.it', c).forEach((x) => x.classList.toggle('sel', x === el)); drawPrev(); status(); };
          el.ondblclick = () => (n.type === 'folder' ? go(path ? path + '/' + n.name : n.name) : vfs.open(n, { navigate: () => { } }));
          el.onkeydown = (e) => { if (e.key === 'Enter') el.ondblclick(); };
          el.oncontextmenu = (e) => {
            e.preventDefault(); e.stopPropagation(); el.click();
            const p = n.project;
            OS.ctx(e.clientX, e.clientY, [
              { label: 'Abrir', icon: 'open', action: () => el.ondblclick() },
              p && p.site ? { label: 'Abrir no navegador do sistema', icon: 'external', action: () => window.open(p.site, '_blank', 'noopener') } : null,
              p && p.repo ? { label: 'Ver no GitHub', icon: 'external', action: () => window.open(p.repo, '_blank', 'noopener') } : null,
              n.kind === 'image' && n.wid ? { label: 'Definir como plano de fundo', icon: 'image', action: () => OS.wallpaper.set(n.wid) } : null
            ]);
          };
          c.appendChild(el);
        });
        drawPrev(); status();
        $r('[data-n=back]').disabled = hi <= 0; $r('[data-n=fwd]').disabled = hi >= hist.length - 1; $r('[data-n=up]').disabled = path === '';
      }
      function status() { $r('#ex-status').textContent = `${(vfs.resolve(path) || { children: [] }).children.length} itens${sel ? '   |   1 item selecionado' : ''}`; }
      function drawPrev() {
        const p = $r('#ex-prev'); root.classList.toggle('no-prev', !preview); const n = sel;
        const cm = (k, show, label) => { const b = $r(`[data-c=${k}]`); b.hidden = !show; if (label) $('span', b).textContent = label; };
        cm('ext', !!(n && n.project && n.project.site)); cm('gh', !!(n && n.project && n.project.repo));
        if (!n) { p.innerHTML = `<div class="pv-empty">${icon('folder')}<span>Selecione um arquivo para visualizar.</span></div>`; return; }
        const pr = n.project;
        if (pr) {
          p.innerHTML = `<img class="pv-img" src="${pr.image}" alt=""><h3>${esc(pr.name)}</h3><div class="pv-meta"><span class="badge">${esc(pr.badge)}</span><span class="stat">${esc(pr.status)}</span></div><p>${esc(pr.desc)}</p><div class="tags">${pr.tags.map((t) => `<span class="tag">${esc(t)}</span>`).join('')}</div>
            <div class="pv-act">${pr.site ? '<button class="btn primary" data-a="site">Abrir site</button>' : ''}${pr.pdf ? '<button class="btn primary" data-a="pdf">Ver proposta (PDF)</button>' : ''}${pr.repo ? '<button class="btn" data-a="repo">GitHub</button>' : ''}${pr.future ? '<button class="btn primary" data-a="ctt">Sugerir um projeto</button>' : ''}</div>`;
          const act = { site: () => OS.openUrl(pr.site, pr.short), pdf: () => OS.openApp('pdf', { src: pr.pdf, title: pr.short }), repo: () => window.open(pr.repo, '_blank', 'noopener'), ctt: () => OS.openApp('contact') };
          $$('[data-a]', p).forEach((b) => (b.onclick = act[b.dataset.a]));
        } else if (n.kind === 'image') p.innerHTML = `<img class="pv-img big" src="${n.src}" alt=""><h3>${esc(n.title || n.name)}</h3><p>${kindLabel(n)}</p>${n.wid ? '<div class="pv-act"><button class="btn primary" data-a="wp">Definir como plano de fundo</button></div>' : ''}`;
        else if (n.kind === 'txt') p.innerHTML = `<div class="pv-ic">${icon('txt')}</div><h3>${esc(n.name)}</h3><pre class="pv-txt">${esc((n.content != null ? n.content : OS.store.get('docs', {})[n.name] || '').slice(0, 600))}</pre>`;
        else p.innerHTML = `<div class="pv-ic">${nodeIcon(n)}</div><h3>${esc(n.name)}</h3><p>${kindLabel(n)}</p>`;
        const wp = $('[data-a=wp]', p); if (wp) wp.onclick = () => OS.wallpaper.set(n.wid);
      }
      $$('.nb', root).forEach((b) => (b.onclick = () => {
        const a = b.dataset.n;
        if (a === 'back' && hi > 0) { hi--; go(hist[hi], false); } else if (a === 'fwd' && hi < hist.length - 1) { hi++; go(hist[hi], false); }
        else if (a === 'up') go(path.split('/').slice(0, -1).join('/')); else if (a === 'ref') draw();
      }));
      $$('.cmd', root).forEach((b) => (b.onclick = () => {
        const c = b.dataset.c, pr = sel && sel.project;
        if (c === 'open' && sel) $r('.it.sel') ? $r('.it.sel').ondblclick() : 0;
        else if (c === 'ext' && pr) OS.openUrl(pr.site, pr.short); else if (c === 'gh' && pr) window.open(pr.repo, '_blank', 'noopener');
        else if (c === 'view') { view = view === 'grid' ? 'list' : 'grid'; OS.store.set('exView', view); draw(); }
        else if (c === 'prev') { preview = !preview; drawPrev(); }
      }));
      $r('#ex-q').oninput = (e) => { query = e.target.value.trim(); draw(); };
      $r('#ex-content').addEventListener('pointerdown', (e) => { if (e.target.id === 'ex-content') { sel = null; $$('.it', root).forEach((x) => x.classList.remove('sel')); drawPrev(); status(); } });
      const off = () => { if (!win.el.isConnected) return; draw(); };
      OS.on('trash', off); OS.on('docs', off);
      win.onOpenAgain = (o) => { if (o.path) go(o.path); };
      go(path, false);
    }
  });

  /* ================================= NAVEGADOR ================================ */
  const BLOCKED = ['github.com', 'google.com', 'youtube.com', 'wa.me', 'whatsapp.com', 'instagram.com', 'facebook.com', 'twitter.com', 'x.com', 'linkedin.com', 'duckduckgo.com', 'bing.com', 'vercel.com'];
  OS.registerApp({
    id: 'browser', title: 'Navegador', icon: 'browser', w: 1020, h: 640, single: true, minW: 400, minH: 300, keywords: 'internet web site navegador browser edge chrome',
    build(win, opts) {
      let tabs = [], active = null, seq = 0;
      const root = html(`<div class="br">
        <div class="br-tabs" id="br-tabs"></div>
        <div class="br-bar"><button class="nb" data-n="back" aria-label="Voltar">${UI.back}</button><button class="nb" data-n="fwd" aria-label="Avançar">${UI.forward}</button><button class="nb" data-n="ref" aria-label="Recarregar">${UI.refresh}</button><button class="nb" data-n="home" aria-label="Início">${UI.home}</button>
          <form class="br-addr" id="br-form"><span class="lockic">${UI.lock}</span><input id="br-url" spellcheck="false" autocomplete="off" aria-label="Endereço"></form>
          <button class="nb" data-n="ext" title="Abrir em uma nova aba do navegador real" aria-label="Abrir externamente">${UI.external}</button></div>
        <div class="br-fav" id="br-fav"></div>
        <div class="br-view" id="br-view"></div></div>`);
      win.body.appendChild(root);
      const view = $('#br-view', root), bar = $('#br-tabs', root);
      const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return ''; } };
      const norm = (v) => {
        v = v.trim(); if (!v) return 'adriel://inicio';
        if (/^adriel:\/\//.test(v)) return v;
        if (/^https?:\/\//i.test(v)) return v;
        if (/^[\w-]+(\.[\w-]+)+(\/.*)?$/.test(v) && !/\s/.test(v)) return 'https://' + v;
        return 'search:' + v;
      };
      function newTab(url) {
        const t = { id: ++seq, url: '', title: 'Nova guia', hist: [], i: -1, pane: html('<div class="br-pane"></div>') };
        view.appendChild(t.pane); tabs.push(t); activate(t); nav(t, url || 'adriel://inicio'); return t;
      }
      function activate(t) { active = t; tabs.forEach((x) => (x.pane.hidden = x !== t)); drawTabs(); syncBar(); }
      function drawTabs() {
        bar.innerHTML = '';
        tabs.forEach((t) => {
          const b = html(`<div class="br-tab ${t === active ? 'on' : ''}" role="tab"><span class="tt">${t.favicon ? `<img src="${t.favicon}" alt="">` : icon('browser')}<em>${esc(t.title)}</em></span><button aria-label="Fechar guia">${UI.close}</button></div>`);
          b.onclick = (e) => { if (e.target.closest('button')) { closeTab(t); } else activate(t); };
          bar.appendChild(b);
        });
        const plus = html(`<button class="br-plus" aria-label="Nova guia">${UI.plus}</button>`); plus.onclick = () => newTab(); bar.appendChild(plus);
        win.setTitle((active ? active.title : 'Navegador') + ' — Navegador');
      }
      function closeTab(t) {
        const i = tabs.indexOf(t); t.pane.remove(); tabs.splice(i, 1);
        if (!tabs.length) { win.close(); return; }
        activate(active === t ? tabs[Math.max(0, i - 1)] : active);
      }
      function syncBar() {
        if (!active) return; const u = active.url;
        $('#br-url', root).value = u === 'adriel://inicio' ? '' : u; $('#br-url', root).placeholder = 'Pesquise ou digite um endereço';
        $('[data-n=back]', root).disabled = active.i <= 0; $('[data-n=fwd]', root).disabled = active.i >= active.hist.length - 1;
        $('.lockic', root).style.visibility = /^https:/.test(u) ? 'visible' : 'hidden';
        $('[data-n=ext]', root).disabled = !/^https?:/.test(u);
      }
      function nav(t, raw, push) {
        let url = norm(raw);
        if (url.startsWith('search:')) { const q = url.slice(7); window.open('https://duckduckgo.com/?q=' + encodeURIComponent(q), '_blank', 'noopener'); OS.toast('Pesquisa aberta em uma nova aba do navegador.', 'browser'); return; }
        if (push !== false) { t.hist = t.hist.slice(0, t.i + 1); t.hist.push(url); t.i = t.hist.length - 1; }
        t.url = url; t.favicon = null; render(t); drawTabs(); syncBar();
      }
      function render(t) {
        const url = t.url, p = t.pane; p.innerHTML = '';
        if (url === 'adriel://inicio') { t.title = 'Nova guia'; p.appendChild(startPage(t)); return; }
        const host = hostOf(url);
        if (BLOCKED.some((b) => host === b || host.endsWith('.' + b))) {
          t.title = host; p.appendChild(html(`<div class="br-block"><div class="bb-ic">${UI.lock}</div><h2>Este site não pode ser exibido aqui</h2><p><b>${esc(host)}</b> não permite ser incorporado dentro de outra página (isso é uma proteção do próprio site). Abra-o em uma nova aba do seu navegador.</p><button class="btn primary" id="bb-open">Abrir em nova aba ${UI.external}</button></div>`));
          $('#bb-open', p).onclick = () => window.open(url, '_blank', 'noopener'); return;
        }
        t.title = host || url;
        const wrap = html(`<div class="br-frame"><div class="br-load"><div class="spinner small">${'<i></i>'.repeat(5)}</div><span>Carregando ${esc(host)}…</span></div><iframe title="${esc(host)}" referrerpolicy="no-referrer" allow="fullscreen; gamepad; autoplay; clipboard-write" sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-pointer-lock allow-downloads"></iframe>
          <div class="br-slow" hidden>Demorando? Alguns sites bloqueiam a exibição aqui. <button class="link" id="bs-open">Abrir em nova aba ${UI.external}</button></div></div>`);
        const fr = $('iframe', wrap);
        fr.onload = () => { $('.br-load', wrap).hidden = true; $('.br-slow', wrap).hidden = false; };
        $('#bs-open', wrap).onclick = () => window.open(url, '_blank', 'noopener');
        p.appendChild(wrap); fr.src = url;
        const pj = DATA.projects.find((x) => x.site && x.site.replace(/\/$/, '') === url.replace(/\/$/, '')); if (pj) { t.title = pj.short; t.favicon = pj.image; }
        drawTabs();
      }
      function startPage(t) {
        const h = new Date().getHours();
        const el = html(`<div class="br-start"><div class="bs-hero"><h1>${h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'}</h1><p>Navegue pelos meus projetos ou pesquise na web.</p>
          <form class="bs-search" id="bs-form">${UI.search}<input placeholder="Pesquise na web (abre em nova aba) ou digite um endereço" aria-label="Pesquisar"></form></div>
          <h3 class="bs-h">Meus projetos</h3><div class="bs-tiles" id="bs-tiles"></div>
          <h3 class="bs-h">Atalhos</h3><div class="bs-tiles small" id="bs-sc"></div></div>`);
        const tiles = $('#bs-tiles', el);
        DATA.projects.filter((p) => !p.future).forEach((p) => {
          const b = html(`<button class="bs-tile"><span class="th"><img src="${p.image}" alt=""></span><b>${esc(p.short)}</b><small>${esc(p.kind)}</small></button>`);
          b.onclick = () => (p.site ? nav(t, p.site) : OS.openApp('pdf', { src: p.pdf, title: p.short }));
          tiles.appendChild(b);
        });
        [['GitHub', 'github', DATA.me.github], ['Contato', 'contact', null, 'contact'], ['Habilidades', 'skills', null, 'skills'], ['Sobre mim', 'about', null, 'about']].forEach(([n, ic, url, app]) => {
          const b = html(`<button class="bs-tile sm"><span class="th">${icon(ic)}</span><b>${n}</b></button>`);
          b.onclick = () => (url ? window.open(url, '_blank', 'noopener') : OS.openApp(app)); $('#bs-sc', el).appendChild(b);
        });
        $('#bs-form', el).onsubmit = (e) => { e.preventDefault(); nav(t, $('input', e.target).value); };
        return el;
      }
      $('#br-form', root).onsubmit = (e) => { e.preventDefault(); nav(active, $('#br-url', root).value); $('#br-url', root).blur(); };
      $('#br-url', root).onfocus = (e) => e.target.select();
      $$('.nb', root).forEach((b) => (b.onclick = () => {
        const a = b.dataset.n;
        if (a === 'back' && active.i > 0) { active.i--; nav(active, active.hist[active.i], false); } else if (a === 'fwd' && active.i < active.hist.length - 1) { active.i++; nav(active, active.hist[active.i], false); }
        else if (a === 'ref') render(active); else if (a === 'home') nav(active, 'adriel://inicio'); else if (a === 'ext') window.open(active.url, '_blank', 'noopener');
      }));
      const fav = $('#br-fav', root);
      DATA.projects.filter((p) => p.site).forEach((p) => { const b = html(`<button><img src="${p.image}" alt="">${esc(p.short)}</button>`); b.onclick = () => nav(active, p.site); fav.appendChild(b); });
      newTab(opts.url);
      win.onOpenAgain = (o) => { if (o.url) { const t = tabs.find((x) => x.url === o.url); t ? activate(t) : newTab(o.url); } };
      win.onClose(() => { tabs.forEach((t) => { const f = $('iframe', t.pane); if (f) f.src = 'about:blank'; }); });
    }
  });

  /* ================================ SOBRE ADRIEL ================================ */
  OS.registerApp({
    id: 'about', title: 'Sobre Adriel', icon: 'about', w: 780, h: 600, keywords: 'sobre adriel morback perfil biografia estudante futebol quem sou',
    build(win) {
      const root = html(`<div class="about">
        <div class="ab-banner"><div class="ab-bg"></div></div>
        <div class="ab-head"><div class="ab-av" id="ab-av"></div>
          <div class="ab-id"><span class="chip">${esc(DATA.me.role)}</span><h1>${esc(DATA.me.name)}</h1><p class="ab-quote">“${esc(DATA.me.tagline)}”</p>
            <div class="ab-pills"><span>${UI.cloud} Campinas / SP</span><span class="live">● Disponível para aprender</span></div></div></div>
        <div class="ab-body">
          <div class="card ab-bio"><p>${esc(DATA.me.bio)}</p></div>
          <h3 class="sec">Áreas de foco & interesses</h3>
          <div class="ab-grid" id="ab-grid"></div>
          <h3 class="sec">Informações do dispositivo</h3>
          <div class="card specs"><dl>
            <dt>Nome do dispositivo</dt><dd>ADRIEL-PC</dd><dt>Processador</dt><dd>Cérebro de dev em evolução @ 100% de curiosidade</dd>
            <dt>Memória (RAM)</dt><dd>16 GB de ideias (e café)</dd><dt>Sistema</dt><dd>AdrielOS 11 — Edição Portfólio (HTML + CSS + JS puros)</dd>
            <dt>Tela</dt><dd>${innerWidth} × ${innerHeight}</dd></dl></div>
          <div class="ab-actions"><button class="btn primary" data-go="projects">Explorar meus projetos</button><button class="btn" data-go="skills">Ver habilidades</button><button class="btn" data-go="contact">Entrar em contato</button></div>
        </div></div>`);
      win.body.appendChild(root);
      const av = () => { $('#ab-av', root).innerHTML = OS.avatarHTML('xl') + `<button class="av-edit" title="Trocar foto" aria-label="Trocar foto">${UI.pencil}</button>`; $('.av-edit', root).onclick = () => pickAvatar(); };
      function pickAvatar() {
        const inp = html('<input type="file" accept="image/*" hidden>'); document.body.appendChild(inp);
        inp.onchange = () => { if (inp.files[0]) OS.readImageFile(inp.files[0], 320, (d) => { if (d) { OS.profile.avatar = d; OS.saveProfile(); } }); inp.remove(); };
        inp.click();
      }
      OS.on('profile', () => win.el.isConnected && av()); av();
      $('.ab-bg', root).style.backgroundImage = 'var(--wp-url)';
      $('#ab-grid', root).innerHTML = DATA.interests.map((i) => `<div class="card int"><span class="int-ic" style="--c:${i.c}">${i.i === 'soccer' ? icon('soccer') : UI[i.i] || icon(i.i)}</span><div><b>${esc(i.t)}</b><p>${esc(i.d)}</p></div></div>`).join('');
      $$('[data-go]', root).forEach((b) => (b.onclick = () => ({ projects: () => OS.openApp('explorer', { path: 'Projetos' }), skills: () => OS.openApp('skills'), contact: () => OS.openApp('contact') })[b.dataset.go]()));
    }
  });

  /* ================================= HABILIDADES ================================ */
  OS.registerApp({
    id: 'skills', title: 'Habilidades', icon: 'skills', w: 860, h: 600, keywords: 'habilidades skills programação html css javascript canvas git curso técnico',
    build(win) {
      let cat = 'all', q = '';
      const root = html(`<div class="sk"><aside class="sk-nav" id="sk-nav"></aside><main class="sk-main"><div class="sk-top"><h2 id="sk-title">Todas as habilidades</h2><div class="ex-find">${UI.search}<input id="sk-q" placeholder="Buscar habilidade"></div></div><p class="note">${UI.info} Habilidades fundamentadas no aprendizado contínuo no Ensino Médio Técnico e aplicadas na prática nos projetos reais — sem certificações ou porcentagens inventadas.</p><div id="sk-list"></div></main></div>`);
      win.body.appendChild(root);
      function draw() {
        const nav = $('#sk-nav', root);
        nav.innerHTML = `<button class="sn ${cat === 'all' ? 'on' : ''}" data-c="all"><span class="dot" style="--c:var(--accent)"></span>Todas</button>` + DATA.skills.map((g) => `<button class="sn ${cat === g.id ? 'on' : ''}" data-c="${g.id}"><span class="dot" style="--c:${g.color}"></span>${esc(g.title)}</button>`).join('');
        $$('.sn', nav).forEach((b) => (b.onclick = () => { cat = b.dataset.c; draw(); }));
        $('#sk-title', root).textContent = cat === 'all' ? 'Todas as habilidades' : DATA.skills.find((g) => g.id === cat).title;
        const list = $('#sk-list', root); list.innerHTML = ''; let n = 0;
        DATA.skills.filter((g) => cat === 'all' || g.id === cat).forEach((g) => {
          const items = g.items.filter((it) => !q || (it[0] + it[2] + it[1]).toLowerCase().includes(q)); if (!items.length) return;
          const sec = html(`<section class="sk-group"><h3><span class="dot" style="--c:${g.color}"></span>${esc(g.title)}</h3><div class="sk-grid"></div></section>`);
          items.forEach((it) => { n++; sec.lastElementChild.appendChild(html(`<div class="card sk-card" style="--c:${g.color}"><div class="sk-h"><b>${esc(it[0])}</b><span class="verified">${UI.check} ${esc(it[1])}</span></div><p>${esc(it[2])}</p></div>`)); });
          list.appendChild(sec);
        });
        if (!n) list.innerHTML = '<div class="ex-empty">Nenhuma habilidade encontrada.</div>';
      }
      $('#sk-q', root).oninput = (e) => { q = e.target.value.trim().toLowerCase(); draw(); };
      draw();
    }
  });

  /* ================================== GITHUB ================================== */
  OS.registerApp({
    id: 'github', title: 'GitHub', icon: 'github', w: 760, h: 600, keywords: 'github git repositório código 43111-cyber jogo-ste fonte',
    build(win) {
      const root = html(`<div class="gh">
        <div class="gh-top"><div class="gh-av">${icon('github')}</div><div class="gh-who"><h2>${DATA.me.githubUser}</h2><p>Repositórios públicos e projetos de código de ${esc(DATA.me.name)}</p></div><a class="btn" target="_blank" rel="noopener noreferrer" href="${DATA.me.github}">Visitar perfil ${UI.external}</a></div>
        <h3 class="sec">Repositório em destaque</h3>
        <div class="card gh-repo">
          <div class="repo-t"><svg viewBox="0 0 16 16" width="18" height="18" fill="currentColor"><path d="M2 2.5A2.5 2.5 0 014.5 0h8.75a.75.75 0 01.75.75v12.5a.75.75 0 01-.75.75h-2.5a.75.75 0 110-1.5h1.75v-2h-8a1 1 0 00-.714 1.7.75.75 0 01-1.072 1.05A2.495 2.495 0 012 11.5v-9zm10.5-1V9h-8c-.356 0-.694.074-1 .208V2.5a1 1 0 011-1h8zM5 12.25v3.25a.75.75 0 001.5 0v-3.25a.75.75 0 00-1.5 0z"/></svg><a href="${DATA.projects[0].repo}" target="_blank" rel="noopener noreferrer">${DATA.me.githubUser} / <b>jogo-ste</b></a><span class="chip">Public</span></div>
          <p>BEIÇO STREET — Taça das Favelas Campinas. Jogo arcade de futebol de rua 1v1 construído para navegador com HTML5 Canvas e JavaScript puro.</p>
          <div class="lang-bar" title="JavaScript 72.4%, CSS 19.4%, HTML 8.2%"><i style="width:72.4%;background:#f1e05a"></i><i style="width:19.4%;background:#a77bff"></i><i style="width:8.2%;background:#e34c26"></i></div>
          <div class="lang-leg"><span><i style="background:#f1e05a"></i>JavaScript 72.4%</span><span><i style="background:#a77bff"></i>CSS 19.4%</span><span><i style="background:#e34c26"></i>HTML 8.2%</span></div>
          <div class="clone"><label>Clonar via HTTPS</label><div class="clone-row"><input readonly id="gh-clone" value="${DATA.projects[0].repo}.git"><button class="btn" id="gh-copy">${UI.copy} Copiar</button></div>
            <div class="clone-row"><input readonly value="git clone ${DATA.projects[0].repo}.git"><button class="btn" id="gh-copy2">${UI.copy} Copiar</button></div></div>
          <div class="gh-act"><a class="btn primary" href="${DATA.projects[0].repo}" target="_blank" rel="noopener noreferrer">Acessar repositório ${UI.external}</a><button class="btn" id="gh-play">Jogar no navegador</button></div>
        </div></div>`);
      win.body.appendChild(root);
      const copy = (v) => { (navigator.clipboard ? navigator.clipboard.writeText(v) : Promise.reject()).then(() => OS.toast('Copiado para a área de transferência!', 'github')).catch(() => OS.toast('Selecione e copie manualmente.', 'github')); };
      $('#gh-copy', root).onclick = () => copy($('#gh-clone', root).value);
      $('#gh-copy2', root).onclick = () => copy($('#gh-copy2', root).previousElementSibling.value);
      $('#gh-play', root).onclick = () => OS.openUrl(DATA.projects[0].site, 'Beiço Street');
    }
  });

  /* ================================== CONTATO ================================= */
  OS.registerApp({
    id: 'contact', title: 'Contato', icon: 'contact', w: 820, h: 620, keywords: 'contato email e-mail whatsapp mensagem falar adriel.morback@gmail.com redes',
    build(win) {
      const draft = OS.store.get('draft', { name: '', email: '', subject: '', msg: '' });
      const root = html(`<div class="ct">
        <aside class="ct-side"><h3>Canais diretos</h3>
          <a class="ch" href="mailto:${DATA.me.email}"><span style="--c:#0ea5e9">${icon('contact')}</span><div><b>E-mail</b><small>${DATA.me.email}</small></div></a>
          <a class="ch" href="https://wa.me/${DATA.me.whatsapp}" target="_blank" rel="noopener noreferrer"><span style="--c:#25d366">${UI.send}</span><div><b>WhatsApp</b><small>${DATA.me.whatsappLabel}</small></div></a>
          <a class="ch" href="${DATA.me.github}" target="_blank" rel="noopener noreferrer"><span style="--c:#6e7681">${icon('github')}</span><div><b>GitHub</b><small>github.com/${DATA.me.githubUser}</small></div></a>
          <div class="ct-note">${UI.info}<span>Este é um site estático: o formulário monta a mensagem e abre o seu app de e-mail ou o WhatsApp para você enviar.</span></div></aside>
        <form class="ct-form" id="ct-form" novalidate><h2>Nova mensagem</h2>
          <div class="to"><span>Para:</span><b>${DATA.me.email}</b></div>
          <div class="frow"><label>Seu nome *<input name="name" placeholder="Ex.: Lucas Silva" value="${esc(draft.name)}"></label><label>Seu e-mail *<input name="email" type="email" placeholder="voce@exemplo.com" value="${esc(draft.email)}"></label></div>
          <label>Assunto<input name="subject" placeholder="Proposta de projeto, bate-papo…" value="${esc(draft.subject)}"></label>
          <label>Mensagem *<textarea name="msg" rows="7" placeholder="Escreva aqui sua mensagem…">${esc(draft.msg)}</textarea></label>
          <div class="fb" id="ct-fb" role="alert" hidden></div>
          <div class="ct-act"><button class="btn primary" data-s="mail">${UI.mail} Enviar por e-mail</button><button class="btn" data-s="wa">${UI.send} Enviar pelo WhatsApp</button><button class="btn ghost" type="button" id="ct-clear">Limpar</button></div></form></div>`);
      win.body.appendChild(root);
      const form = $('#ct-form', root), fb = $('#ct-fb', root);
      const val = () => Object.fromEntries(new FormData(form).entries());
      form.oninput = () => OS.store.set('draft', val());
      $('#ct-clear', root).onclick = () => { form.reset(); OS.store.del('draft'); fb.hidden = true; };
      form.onsubmit = (e) => {
        e.preventDefault(); const which = (e.submitter && e.submitter.dataset.s) || 'mail', v = val();
        const errs = []; if (!v.name.trim()) errs.push('informe seu nome'); if (!/^\S+@\S+\.\S+$/.test(v.email.trim())) errs.push('informe um e-mail válido'); if (v.msg.trim().length < 5) errs.push('escreva sua mensagem');
        fb.hidden = false;
        if (errs.length) { fb.className = 'fb err'; fb.textContent = 'Por favor, ' + errs.join(', ') + '.'; return; }
        const body = `${v.msg.trim()}\n\n— ${v.name.trim()} (${v.email.trim()})`;
        if (which === 'wa') window.open(`https://wa.me/${DATA.me.whatsapp}?text=${encodeURIComponent((v.subject ? v.subject.trim() + '\n\n' : '') + body)}`, '_blank', 'noopener');
        else window.location.href = `mailto:${DATA.me.email}?subject=${encodeURIComponent(v.subject.trim() || 'Contato pelo portfólio AdrielOS')}&body=${encodeURIComponent(body)}`;
        fb.className = 'fb ok'; fb.textContent = 'Mensagem validada! Se o seu app de e-mail/WhatsApp não abriu, use os canais diretos ao lado.';
        OS.notify({ title: 'Mensagem pronta para enviar', body: 'Abrimos o seu aplicativo para concluir o envio.', icon: 'contact', app: 'Contato' });
      };
    }
  });

  /* ================================== LIXEIRA ================================= */
  OS.registerApp({
    id: 'trash', title: 'Lixeira', icon: 'trash', w: 620, h: 440, single: true, keywords: 'lixeira excluídos deletados restaurar',
    build(win) {
      const root = html(`<div class="tr"><div class="ex-cmd"><button class="cmd" id="tr-empty">${UI.trash}<span>Esvaziar Lixeira</span></button><button class="cmd" id="tr-all">${UI.restart}<span>Restaurar todos os itens</span></button></div><div class="tr-body" id="tr-body"></div></div>`);
      win.body.appendChild(root);
      function draw() {
        const items = OS.trashItems(), b = $('#tr-body', root);
        win.setIcon(items.length ? 'trashfull' : 'trash');
        $('#tr-empty', root).disabled = $('#tr-all', root).disabled = !items.length;
        if (!items.length) { b.innerHTML = `<div class="tr-empty">${icon('trash')}<h3>Nenhum arquivo descartado.</h3><p>“Todos os projetos continuam em construção!”</p><small>Crie uma pasta ou documento na área de trabalho (botão direito → Novo) e exclua para ver a Lixeira funcionando.</small></div>`; return; }
        b.innerHTML = items.map((t) => `<div class="tr-row" data-id="${t.id}"><span>${icon(t.type === 'folder' ? 'folder' : 'txt')}</span><b>${esc(t.name)}</b><small>Excluído ${new Date(t.deletedAt).toLocaleString('pt-BR')}</small><button class="btn sm">Restaurar</button></div>`).join('');
        $$('.tr-row', b).forEach((r) => ($('button', r).onclick = () => OS.restoreTrash(r.dataset.id)));
      }
      $('#tr-empty', root).onclick = async () => { if (await OS.confirm('Esvaziar Lixeira', 'Deseja excluir permanentemente todos os itens da Lixeira?', 'Sim', 'Não')) { OS.emptyTrash(); OS.toast('Lixeira esvaziada.', 'trash'); } };
      $('#tr-all', root).onclick = () => OS.trashItems().slice().forEach((t) => OS.restoreTrash(t.id));
      OS.on('trash', () => win.el.isConnected && draw()); draw();
    }
  });

  /* ================================= LEITOR PDF ================================ */
  OS.registerApp({
    id: 'pdf', title: 'Leitor de PDF', icon: 'pdf', w: 900, h: 640, keywords: 'pdf proposta morfaias documento leitor',
    build(win, opts) {
      const src = opts.src || DATA.projects[3].pdf;
      win.setTitle((opts.title || 'Proposta') + ' — Leitor de PDF');
      win.body.innerHTML = `<div class="pdf"><div class="ex-cmd"><a class="cmd" href="${src}" target="_blank" rel="noopener noreferrer">${UI.external}<span>Abrir em nova aba</span></a><a class="cmd" href="${src}" download>${UI.save}<span>Baixar</span></a></div><iframe src="${src}#view=FitH" title="PDF"></iframe><div class="pdf-fb">Seu navegador não conseguiu exibir o PDF aqui. <a href="${src}" target="_blank" rel="noopener noreferrer">Abrir em nova aba</a>.</div></div>`;
    }
  });

  /* ================================== EXECUTAR ================================= */
  const ALIAS = { calc: 'calc', calculadora: 'calc', notepad: 'notepad', bloco: 'notepad', cmd: 'terminal', terminal: 'terminal', powershell: 'terminal', explorer: 'explorer', explorador: 'explorer', paint: 'paint', mspaint: 'paint', taskmgr: 'taskmgr', control: 'settings', settings: 'settings', configuracoes: 'settings', winver: 'winver', about: 'about', sobre: 'about', projetos: 'explorer', github: 'github', contato: 'contact', contact: 'contact', skills: 'skills', habilidades: 'skills', browser: 'browser', navegador: 'browser', edge: 'browser', chrome: 'browser', fotos: 'photos', photos: 'photos', musica: 'music', music: 'music', mines: 'mines', winmine: 'mines', campominado: 'mines', snake: 'snake', cobrinha: 'snake', lixeira: 'trash', trash: 'trash', pdf: 'pdf', run: 'run', executar: 'run' };
  OS.resolveApp = (n) => ALIAS[String(n).toLowerCase().replace(/\.exe$/, '').replace(/\s+/g, '')] || (OS.apps[n] ? n : null);
  OS.registerApp({
    id: 'run', title: 'Executar', icon: 'run', w: 460, h: 230, noMax: true, noMin: true, noResize: true, single: true, keywords: 'executar run comando abrir',
    build(win) {
      const hist = OS.store.get('runhist', []);
      win.body.innerHTML = `<form class="run"><div class="run-top">${icon('run')}<p>Digite o nome de um programa, pasta, documento ou site, e o AdrielOS o abrirá para você.</p></div>
        <label>Abrir: <input id="run-in" list="run-list" autocomplete="off" spellcheck="false"><datalist id="run-list">${hist.map((h) => `<option value="${esc(h)}">`).join('')}</datalist></label>
        <div class="run-act"><button class="btn primary">OK</button><button class="btn" type="button" id="run-cancel">Cancelar</button></div></form>`;
      const inp = $('#run-in', win.body); setTimeout(() => inp.focus(), 50);
      $('#run-cancel', win.body).onclick = () => win.close();
      $('.run', win.body).onsubmit = async (e) => {
        e.preventDefault(); const v = inp.value.trim(); if (!v) return;
        const h = [v].concat(hist.filter((x) => x !== v)).slice(0, 8); OS.store.set('runhist', h);
        const low = v.toLowerCase();
        if (/^(https?:\/\/|www\.)/i.test(v)) { win.close(); OS.openUrl(/^www\./i.test(v) ? 'https://' + v : v); return; }
        if (low === 'bsod') { win.close(); OS.session.bsod(); return; }
        if (low === 'shutdown') { win.close(); OS.session.shutdown(); return; }
        if (low === 'restart') { win.close(); OS.session.restart(); return; }
        if (low === 'lock') { win.close(); OS.session.lock(); return; }
        const app = OS.resolveApp(v);
        if (app) { win.close(); OS.openApp(app); return; }
        await OS.dialog({ title: v, icon: 'run', message: `O AdrielOS não pode encontrar '${esc(v)}'. Verifique se o nome foi digitado corretamente e tente novamente.` });
        inp.focus();
      };
    }
  });

  /* ============================== SOBRE O ADRIELOS ============================= */
  OS.registerApp({
    id: 'winver', title: 'Sobre o AdrielOS', icon: 'start', w: 480, h: 420, noMax: true, noMin: true, noResize: true, single: true, hidden: false, keywords: 'versão sobre sistema winver',
    build(win) {
      win.body.innerHTML = `<div class="winver"><div class="wv-logo">${icon('start')}</div><h2>Adriel<b>OS</b> 11</h2><hr><p><b>Edição Portfólio — Versão 26H2</b><br>Compilação ${new Date().getFullYear()}.${OS.pad(new Date().getMonth() + 1)}.${OS.pad(new Date().getDate())}</p><p>Feito por <b>${esc(DATA.me.name)}</b> com HTML, CSS e JavaScript puros — sem frameworks. Inspirado na experiência dos sistemas operacionais modernos.</p><p class="wv-small">Esta cópia do AdrielOS é licenciada para: <b>Você, visitante</b> 🎉</p><button class="btn primary" id="wv-ok">OK</button></div>`;
      $('#wv-ok', win.body).onclick = () => win.close();
    }
  });
})();
