/* ==========================================================================
   AdrielOS — Biblioteca de ícones (SVG inline, sem dependências)
   APP_ICONS: ícones coloridos de aplicativos (viewBox 48x48, cores chapadas)
   UI: ícones de interface em traço (viewBox 24x24, currentColor)
   ========================================================================== */
(function () {
  'use strict';

  const s = (inner) => `<svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">${inner}</svg>`;

  const APP_ICONS = {
    start: s(`<rect x="5" y="5" width="18" height="18" rx="3.5" fill="currentColor"/><rect x="25" y="5" width="18" height="18" rx="3.5" fill="currentColor" opacity=".85"/><rect x="5" y="25" width="18" height="18" rx="3.5" fill="currentColor" opacity=".85"/><rect x="25" y="25" width="18" height="18" rx="3.5" fill="currentColor" opacity=".7"/>`),

    about: s(`<rect x="4" y="4" width="40" height="40" rx="12" fill="#2563eb"/><circle cx="24" cy="18" r="7.5" fill="#fff"/><path d="M9.5 39c1.2-8 7-12 14.5-12s13.300 4 14.500 12z" fill="#fff"/><circle cx="24" cy="18" r="7.500" fill="none"/>`),

    projects: s(`<path d="M4 12a4 4 0 0 1 4-4h10l4 4h18a4 4 0 0 1 4 4v3H4z" fill="#f4b73e"/><path d="M4 17h40v19a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4z" fill="#fbd169"/><path d="M4 17h40v3H4z" fill="#fff" opacity=".35"/>`),

    folder: s(`<path d="M4 12a4 4 0 0 1 4-4h10l4 4h18a4 4 0 0 1 4 4v3H4z" fill="#e7a921"/><path d="M4 17h40v19a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4z" fill="#ffd45f"/>`),

    skills: s(`<rect x="4" y="4" width="40" height="40" rx="11" fill="#7c3aed"/><rect x="15" y="15" width="18" height="18" rx="3" fill="#fff"/><rect x="19" y="19" width="10" height="10" rx="1.500" fill="#7c3aed"/><g stroke="#fff" stroke-width="2.600" stroke-linecap="round"><path d="M19 9v4M24 9v4M29 9v4M19 35v4M24 35v4M29 35v4M9 19h4M9 24h4M9 29h4M35 19h4M35 24h4M35 29h4"/></g>`),

    github: s(`<rect x="4" y="4" width="40" height="40" rx="12" fill="#161b22"/><path fill="#fff" d="M24 9.500c-8.100 0-14.500 6.500-14.500 14.600 0 6.400 4.100 11.900 9.900 13.800.7.100 1-.3 1-.7v-2.500c-4 .9-4.900-1.900-4.900-1.900-.7-1.700-1.600-2.100-1.600-2.100-1.300-.9.100-.9.100-.9 1.500.1 2.200 1.500 2.200 1.500 1.300 2.200 3.400 1.600 4.200 1.200.1-.9.500-1.600.9-1.900-3.200-.4-6.600-1.600-6.600-7.200 0-1.600.6-2.900 1.500-3.900-.1-.4-.7-1.900.1-3.900 0 0 1.200-.4 3.900 1.500a13.400 13.400 0 0 1 7.100 0c2.700-1.900 3.900-1.500 3.900-1.500.8 2 .3 3.500.1 3.900.9 1 1.500 2.300 1.500 3.900 0 5.600-3.400 6.800-6.700 7.100.5.500 1 1.400 1 2.700v4c0 .4.300.8 1 .7 5.800-1.900 9.900-7.400 9.900-13.800C38.500 16 32.100 9.500 24 9.500z"/>`),

    contact: s(`<rect x="4" y="9" width="40" height="30" rx="6" fill="#0ea5e9"/><path d="M6 13l18 14 18-14" fill="none" stroke="#fff" stroke-width="3.200" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 15a6 6 0 0 1 6-6h28a6 6 0 0 1 6 6" fill="#fff" opacity=".18"/>`),

    trash: s(`<path d="M13 15h22l-2 25a3 3 0 0 1-3 2.700H18a3 3 0 0 1-3-2.700z" fill="#cbd5e1"/><path d="M13 15h22l-.5 6h-21z" fill="#fff" opacity=".35"/><rect x="9" y="10" width="30" height="4.500" rx="2" fill="#94a3b8"/><rect x="19" y="6" width="10" height="5" rx="2" fill="#94a3b8"/><path d="M20 22v14M24 22v14M28 22v14" stroke="#64748b" stroke-width="2.200" stroke-linecap="round"/>`),

    trashfull: s(`<path d="M13 17h22l-2 23a3 3 0 0 1-3 2.700H18a3 3 0 0 1-3-2.700z" fill="#cbd5e1"/><rect x="9" y="12" width="30" height="4.500" rx="2" fill="#94a3b8"/><path d="M16 12l3-6 5 5 4-7 5 8" fill="#f8fafc" stroke="#94a3b8" stroke-width="1.500" stroke-linejoin="round"/><path d="M20 24v12M24 24v12M28 24v12" stroke="#64748b" stroke-width="2.200" stroke-linecap="round"/>`),

    settings: s(`<circle cx="24" cy="24" r="20" fill="#64748b"/><path fill="#fff" d="M24 14.500a9.500 9.500 0 1 0 0 19 9.500 9.500 0 0 0 0-19zm0 5.500a4 4 0 1 1 0 8 4 4 0 0 1 0-8z"/><g fill="#fff"><rect x="21.500" y="5.500" width="5" height="7" rx="1.500"/><rect x="21.500" y="35.500" width="5" height="7" rx="1.500"/><rect x="5.500" y="21.500" width="7" height="5" rx="1.500"/><rect x="35.500" y="21.500" width="7" height="5" rx="1.500"/><rect x="21.500" y="5.500" width="5" height="7" rx="1.500" transform="rotate(45 24 24)"/><rect x="21.500" y="35.500" width="5" height="7" rx="1.500" transform="rotate(45 24 24)"/><rect x="5.500" y="21.500" width="7" height="5" rx="1.500" transform="rotate(45 24 24)"/><rect x="35.500" y="21.500" width="7" height="5" rx="1.500" transform="rotate(45 24 24)"/></g><circle cx="24" cy="24" r="4" fill="#64748b"/>`),

    browser: s(`<circle cx="24" cy="24" r="20" fill="#0ea5e9"/><path d="M24 4c-6 5-9 12-9 20s3 15 9 20M24 4c6 5 9 12 9 20s-3 15-9 20M4 24h40M7 14h34M7 34h34" fill="none" stroke="#fff" stroke-width="2" opacity=".9"/><path d="M12 30c4-8 12-14 24-14-3 8-10 14-20 16z" fill="#22c55e" opacity=".85"/>`),

    notepad: s(`<rect x="9" y="5" width="30" height="38" rx="4" fill="#38bdf8"/><rect x="12" y="11" width="24" height="29" rx="2" fill="#fff"/><path d="M16 18h16M16 23h16M16 28h16M16 33h10" stroke="#94a3b8" stroke-width="2.200" stroke-linecap="round"/><rect x="13" y="3" width="3.500" height="8" rx="1.700" fill="#0369a1"/><rect x="22" y="3" width="3.500" height="8" rx="1.700" fill="#0369a1"/><rect x="31" y="3" width="3.500" height="8" rx="1.700" fill="#0369a1"/>`),

    calc: s(`<rect x="8" y="4" width="32" height="40" rx="6" fill="#334155"/><rect x="12" y="8" width="24" height="9" rx="2.500" fill="#a7f3d0"/><g fill="#e2e8f0"><circle cx="16.500" cy="25" r="2.600"/><circle cx="24" cy="25" r="2.600"/><circle cx="31.500" cy="25" r="2.600"/><circle cx="16.500" cy="32" r="2.600"/><circle cx="24" cy="32" r="2.600"/><circle cx="16.500" cy="39" r="2.600"/><circle cx="24" cy="39" r="2.600"/></g><circle cx="31.500" cy="32" r="2.600" fill="#fb923c"/><rect x="28.900" y="36.400" width="5.200" height="5.200" rx="2.600" fill="#fb923c"/>`),

    terminal: s(`<rect x="3" y="7" width="42" height="34" rx="6" fill="#0f172a"/><rect x="3" y="7" width="42" height="8" rx="6" fill="#334155"/><circle cx="9" cy="11" r="1.600" fill="#f87171"/><circle cx="14" cy="11" r="1.600" fill="#fbbf24"/><circle cx="19" cy="11" r="1.600" fill="#4ade80"/><path d="M11 22l7 5-7 5" fill="none" stroke="#4ade80" stroke-width="3.200" stroke-linecap="round" stroke-linejoin="round"/><path d="M22 34h12" stroke="#e2e8f0" stroke-width="3.200" stroke-linecap="round"/>`),

    photos: s(`<rect x="4" y="8" width="40" height="32" rx="6" fill="#e0f2fe"/><circle cx="33" cy="18" r="4.500" fill="#fbbf24"/><path d="M4 34l12-13 9 9 6-6 13 12v2a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4z" fill="#22c55e"/><path d="M4 36l11-8 8 7 6-4 15 8" fill="#15803d" opacity=".55"/>`),

    paint: s(`<path d="M24 5C12 5 4 13.500 4 23.500 4 33 11 40 19 40c3.500 0 4-2.500 3-4.500-1-2.200.2-4.500 3-4.500h6c6 0 13-3 13-9C44 14 36 5 24 5z" fill="#f1f5f9"/><circle cx="14" cy="21" r="3.500" fill="#ef4444"/><circle cx="22" cy="13.500" r="3.500" fill="#f59e0b"/><circle cx="33" cy="14.500" r="3.500" fill="#22c55e"/><circle cx="38" cy="23.500" r="3.200" fill="#3b82f6"/><path d="M30 36l10-10 3 3-10 10z" fill="#a855f7"/>`),

    mines: s(`<rect x="4" y="4" width="40" height="40" rx="8" fill="#94a3b8"/><rect x="7" y="7" width="34" height="34" rx="5" fill="#cbd5e1"/><circle cx="24" cy="25" r="9" fill="#111827"/><g stroke="#111827" stroke-width="3" stroke-linecap="round"><path d="M24 12v6M24 32v6M11 25h6M31 25h6M15 16l4 4M29 30l4 4M33 16l-4 4M19 30l-4 4"/></g><circle cx="21" cy="22" r="2.400" fill="#fff"/>`),

    snake: s(`<rect x="4" y="4" width="40" height="40" rx="10" fill="#14532d"/><path d="M12 36V24a6 6 0 0 1 6-6h12a4 4 0 0 0 0-8" fill="none" stroke="#4ade80" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/><circle cx="35" cy="12" r="2.400" fill="#111827"/><circle cx="37" cy="31" r="3.600" fill="#ef4444"/>`),

    taskmgr: s(`<rect x="4" y="6" width="40" height="36" rx="6" fill="#0f766e"/><path d="M8 33l8-9 6 5 8-13 10 9" fill="none" stroke="#99f6e4" stroke-width="3.200" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 38h32" stroke="#5eead4" stroke-width="2" opacity=".6"/>`),

    music: s(`<rect x="4" y="4" width="40" height="40" rx="12" fill="#e11d48"/><path d="M19 32V14l15-3v18" fill="none" stroke="#fff" stroke-width="3.200" stroke-linejoin="round" stroke-linecap="round"/><circle cx="15.500" cy="32.500" r="4.200" fill="#fff"/><circle cx="30.500" cy="29.500" r="4.200" fill="#fff"/>`),

    pdf: s(`<path d="M11 4h18l10 10v26a4 4 0 0 1-4 4H11a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4z" fill="#ef4444"/><path d="M29 4l10 10H33a4 4 0 0 1-4-4z" fill="#fca5a5"/><text x="23" y="35" font-family="Segoe UI,Arial,sans-serif" font-size="11" font-weight="700" fill="#fff" text-anchor="middle">PDF</text>`),

    txt: s(`<path d="M11 4h18l10 10v26a4 4 0 0 1-4 4H11a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4z" fill="#f8fafc" stroke="#94a3b8" stroke-width="2"/><path d="M29 4l10 10H33a4 4 0 0 1-4-4z" fill="#cbd5e1"/><path d="M14 22h20M14 28h20M14 34h12" stroke="#64748b" stroke-width="2.400" stroke-linecap="round"/>`),

    image: s(`<path d="M11 4h18l10 10v26a4 4 0 0 1-4 4H11a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4z" fill="#e0f2fe" stroke="#38bdf8" stroke-width="2"/><circle cx="29" cy="24" r="3" fill="#f59e0b"/><path d="M8 40l9-10 6 6 5-4 11 8z" fill="#22c55e"/>`),

    link: s(`<rect x="4" y="4" width="40" height="40" rx="10" fill="#0ea5e9"/><path d="M20 28l8-8M22 16l3-3a6 6 0 0 1 9 9l-3 3M26 32l-3 3a6 6 0 0 1-9-9l3-3" fill="none" stroke="#fff" stroke-width="3.400" stroke-linecap="round"/>`),

    soccer: s(`<circle cx="24" cy="24" r="20" fill="#f8fafc" stroke="#0f172a" stroke-width="2.400"/><path d="M24 15l8 6-3 9H19l-3-9z" fill="#0f172a"/><path d="M24 15V6M32 21l9-3M29 30l5 8M19 30l-5 8M16 21l-9-3" stroke="#0f172a" stroke-width="2.200" stroke-linecap="round"/>`),

    run: s(`<rect x="4" y="8" width="40" height="32" rx="6" fill="#475569"/><rect x="4" y="8" width="40" height="8" rx="6" fill="#64748b"/><path d="M12 28h16" stroke="#e2e8f0" stroke-width="3.400" stroke-linecap="round"/><path d="M30 22l7 6-7 6" fill="none" stroke="#4ade80" stroke-width="3.200" stroke-linecap="round" stroke-linejoin="round"/>`),

    widgets: s(`<rect x="4" y="4" width="18" height="18" rx="5" fill="#38bdf8"/><rect x="26" y="4" width="18" height="18" rx="5" fill="#a78bfa"/><rect x="4" y="26" width="18" height="18" rx="5" fill="#34d399"/><rect x="26" y="26" width="18" height="18" rx="5" fill="#fbbf24"/>`),

    bsod: s(`<rect x="3" y="7" width="42" height="34" rx="5" fill="#0078d4"/><text x="9" y="30" font-family="Segoe UI,Arial,sans-serif" font-size="22" fill="#fff">:(</text>`),

    game: s(`<rect x="4" y="12" width="40" height="26" rx="13" fill="#6366f1"/><path d="M14 20v10M9 25h10" stroke="#fff" stroke-width="3" stroke-linecap="round"/><circle cx="32" cy="22" r="2.600" fill="#fbbf24"/><circle cx="37" cy="27" r="2.600" fill="#34d399"/>`)
  };

  const p = (inner, extra) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" ${extra || ''} aria-hidden="true" focusable="false">${inner}</svg>`;

  const UI = {
    search: p('<circle cx="11" cy="11" r="6.500"/><path d="M20 20l-4.200-4.200"/>'),
    taskview: p('<rect x="3" y="5" width="18" height="14" rx="2.500"/><path d="M3 9h18"/>'),
    widgets: p('<rect x="3.500" y="3.500" width="7" height="7" rx="1.800"/><rect x="13.500" y="3.500" width="7" height="7" rx="1.800"/><rect x="3.500" y="13.500" width="7" height="7" rx="1.800"/><rect x="13.500" y="13.500" width="7" height="7" rx="1.800"/>'),
    chevronUp: p('<path d="M6 15l6-6 6 6"/>'),
    chevronRight: p('<path d="M9 6l6 6-6 6"/>'),
    chevronLeft: p('<path d="M15 6l-6 6 6 6"/>'),
    chevronDown: p('<path d="M6 9l6 6 6-6"/>'),
    wifi: p('<path d="M2.500 9.500a14 14 0 0 1 19 0M5.500 13a9.500 9.500 0 0 1 13 0M8.700 16.300a5 5 0 0 1 6.600 0"/><circle cx="12" cy="19.500" r=".8" fill="currentColor"/>'),
    wifiOff: p('<path d="M2.500 9.500a14 14 0 0 1 5-3M21.500 9.500a14 14 0 0 0-8-3.400M5.500 13a9.500 9.500 0 0 1 3.500-2M18.500 13a9.500 9.500 0 0 0-3-2M8.700 16.300a5 5 0 0 1 6.600 0M3 3l18 18"/>'),
    volume: p('<path d="M4 9.500h3.500L12 5.500v13l-4.500-4H4z"/><path d="M15.500 9a4 4 0 0 1 0 6M18 6.500a8 8 0 0 1 0 11"/>'),
    volumeMute: p('<path d="M4 9.500h3.500L12 5.500v13l-4.500-4H4z"/><path d="M16 9.500l5 5M21 9.500l-5 5"/>'),
    battery: p('<rect x="2.500" y="8" width="16" height="8.500" rx="2"/><path d="M21 11v3"/><rect x="4.500" y="10" width="10" height="4.500" rx="1" fill="currentColor" stroke="none"/>'),
    bluetooth: p('<path d="M7 7.500l10 9-5 4.500v-18l5 4.500-10 9"/>'),
    plane: p('<path d="M21 15.500l-8-4.500V5.500a1.500 1.500 0 0 0-3 0V11l-8 4.500V18l8-2.300V20l-2 1.500V23l3.500-1 3.500 1v-1.500L13 20v-4.300l8 2.300z" transform="scale(.88) translate(1.500 -1)"/>'),
    moon: p('<path d="M20 14.500A8.500 8.500 0 1 1 9.500 4 7 7 0 0 0 20 14.500z"/>'),
    sun: p('<circle cx="12" cy="12" r="4"/><path d="M12 2.500v2M12 19.500v2M2.500 12h2M19.500 12h2M5.300 5.300l1.400 1.400M17.300 17.300l1.400 1.400M5.300 18.700l1.400-1.400M17.300 6.700l1.400-1.400"/>'),
    bell: p('<path d="M6 16.500V11a6 6 0 0 1 12 0v5.500l1.500 2h-15z"/><path d="M10 21a2.200 2.200 0 0 0 4 0"/>'),
    bellOff: p('<path d="M6 16.500V11a6 6 0 0 1 9-5.200M18 11v5.500l1.500 2h-15M10 21a2.200 2.200 0 0 0 4 0M3 3l18 18"/>'),
    power: p('<path d="M12 3v8.500"/><path d="M17.500 6.500a8 8 0 1 1-11 0"/>'),
    lock: p('<rect x="5" y="10.500" width="14" height="10" rx="2.500"/><path d="M8 10.500V8a4 4 0 0 1 8 0v2.500"/>'),
    sleep: p('<path d="M20 14.500A8.500 8.500 0 1 1 9.500 4 7 7 0 0 0 20 14.500z"/>'),
    restart: p('<path d="M20 11a8 8 0 1 0-2.300 6"/><path d="M20.500 4v6.500H14"/>'),
    user: p('<circle cx="12" cy="8" r="4"/><path d="M4 20.500c1-4 4-6 8-6s7 2 8 6"/>'),
    close: p('<path d="M5 5l14 14M19 5L5 19"/>'),
    minimize: p('<path d="M5 12h14"/>'),
    maximize: p('<rect x="5" y="5" width="14" height="14" rx="1.800"/>'),
    restore: p('<rect x="4.500" y="8.500" width="11" height="11" rx="1.800"/><path d="M8.500 8.500V6.500a1.800 1.800 0 0 1 1.800-1.800h7.400a1.800 1.800 0 0 1 1.800 1.800v7.400a1.800 1.800 0 0 1-1.800 1.800h-2.200"/>'),
    back: p('<path d="M19 12H5M11 6l-6 6 6 6"/>'),
    forward: p('<path d="M5 12h14M13 6l6 6-6 6"/>'),
    up: p('<path d="M12 19V5M6 11l6-6 6 6"/>'),
    refresh: p('<path d="M20 11a8 8 0 1 0-2.300 6"/><path d="M20.500 4v6.500H14"/>'),
    home: p('<path d="M4 11l8-7 8 7v9h-5v-6h-6v6H4z"/>'),
    plus: p('<path d="M12 5v14M5 12h14"/>'),
    trash: p('<path d="M5 7h14M10 7V4.500h4V7M7 7l1 13h8l1-13M10 11v6M14 11v6"/>'),
    copy: p('<rect x="8.500" y="8.500" width="11" height="11" rx="2"/><path d="M15.500 8.500V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v7.500a2 2 0 0 0 2 2h2.500"/>'),
    save: p('<path d="M5 4h11l3 3v13H5z"/><path d="M8 4v5h7V4M8 20v-6h8v6"/>'),
    open: p('<path d="M3.500 7a2 2 0 0 1 2-2H10l2 2.500h6.500a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>'),
    grid: p('<rect x="4" y="4" width="6.500" height="6.500" rx="1.200"/><rect x="13.500" y="4" width="6.500" height="6.500" rx="1.200"/><rect x="4" y="13.500" width="6.500" height="6.500" rx="1.200"/><rect x="13.500" y="13.500" width="6.500" height="6.500" rx="1.200"/>'),
    list: p('<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>'),
    external: p('<path d="M14 4h6v6M20 4l-9 9M18 14v4.500a1.500 1.500 0 0 1-1.500 1.500h-10A1.500 1.500 0 0 1 5 18.500v-10A1.500 1.500 0 0 1 6.500 7H11"/>'),
    star: p('<path d="M12 3.500l2.600 5.400 5.900.8-4.300 4.100 1 5.800L12 16.800 6.800 19.600l1-5.800L3.500 9.700l5.900-.8z"/>'),
    palette: p('<path d="M12 3.500C7 3.500 3.500 7 3.500 11.500c0 4 3 7 6.500 7 1.500 0 1.800-1 1.300-2-.5-1 .1-2 1.300-2H14c3.300 0 6.500-1.500 6.500-4.500C20.500 6.500 17 3.500 12 3.500z"/><circle cx="8" cy="11" r=".9" fill="currentColor"/><circle cx="11.500" cy="7.500" r=".9" fill="currentColor"/><circle cx="16" cy="8.500" r=".9" fill="currentColor"/>'),
    image: p('<rect x="3.500" y="4.500" width="17" height="15" rx="2.500"/><circle cx="9" cy="10" r="1.700"/><path d="M4 17l5-4.500 4 3.500 3-2.500 4.500 4"/>'),
    monitor: p('<rect x="3" y="4" width="18" height="12.500" rx="2"/><path d="M8.500 20.500h7M12 16.500v4"/>'),
    info: p('<circle cx="12" cy="12" r="9"/><path d="M12 11v5.500M12 7.800v.1"/>'),
    play: p('<path d="M7 4.500v15l12-7.500z" fill="currentColor"/>'),
    pause: p('<rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor"/><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor"/>'),
    skipNext: p('<path d="M6 5v14l10-7z" fill="currentColor"/><path d="M18 5v14"/>'),
    skipPrev: p('<path d="M18 5v14L8 12z" fill="currentColor"/><path d="M6 5v14"/>'),
    mail: p('<rect x="3" y="5.500" width="18" height="13" rx="2.500"/><path d="M3.500 7.500L12 13.500l8.500-6"/>'),
    send: p('<path d="M21 3L10 14M21 3l-7 18-4-7-7-4z"/>'),
    eraser: p('<path d="M8 20l-4-4 10.500-10.500a2 2 0 0 1 2.800 0l3.200 3.200a2 2 0 0 1 0 2.800L11.500 20H20"/>'),
    pencil: p('<path d="M4 20l1-4L16.500 4.500a2 2 0 0 1 2.800 0l.2.200a2 2 0 0 1 0 2.800L8 19z"/>'),
    snap: p('<rect x="3.500" y="4.500" width="17" height="15" rx="2.500"/><path d="M12 4.500v15"/>'),
    zoomIn: p('<circle cx="11" cy="11" r="6.500"/><path d="M20 20l-4.200-4.200M11 8v6M8 11h6"/>'),
    cloud: p('<path d="M7 18.500a4.500 4.500 0 0 1-.5-9 6 6 0 0 1 11.500 1.500 3.800 3.800 0 0 1-.5 7.500z"/>'),
    check: p('<path d="M5 12.500l4.500 4.500L19 7.500"/>'),
    flag: p('<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>'),
    windows: p('<rect x="4" y="4" width="7.200" height="7.200" rx="1.200"/><rect x="12.800" y="4" width="7.200" height="7.200" rx="1.200"/><rect x="4" y="12.800" width="7.200" height="7.200" rx="1.200"/><rect x="12.800" y="12.800" width="7.200" height="7.200" rx="1.200"/>'),
    accessibility: p('<circle cx="12" cy="5" r="1.800"/><path d="M5 8.500l7 1.500 7-1.500M12 10v4.500M12 14.500l-3 6M12 14.500l3 6"/>'),
    clock: p('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.500 2"/>'),
    gamepad: p('<rect x="2.500" y="7" width="19" height="10.500" rx="5"/><path d="M8 10v4.500M5.800 12.300h4.500M15.500 11.500h.01M18 13.500h.01"/>')
  };

  window.APP_ICONS = APP_ICONS;
  window.UI = UI;
  window.icon = (name) => APP_ICONS[name] || APP_ICONS.folder;
})();
