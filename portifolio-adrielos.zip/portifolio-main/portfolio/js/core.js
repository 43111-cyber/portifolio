/* ==========================================================================
   AdrielOS — NÚCLEO
   Utilitários, configurações, som, papéis de parede, notificações,
   menu de contexto, painéis, diálogos e gerenciador de janelas.
   ========================================================================== */
(function () {
  'use strict';

  const OS = (window.OS = { apps: {}, wins: [], panels: {}, TB: 48, bootedAt: Date.now(), opened: 0 });

  /* ------------------------------ utilitários ------------------------------ */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const html = (str) => { const t = document.createElement('template'); t.innerHTML = str.trim(); return t.content.firstElementChild; };
  const clamp = (v, a, b) => Math.min(Math.max(v, a), b);
  const pad = (n) => String(n).padStart(2, '0');
  OS.$ = $; OS.$$ = $$; OS.esc = esc; OS.html = html; OS.clamp = clamp; OS.pad = pad;

  const bus = new EventTarget();
  OS.on = (ev, fn) => bus.addEventListener(ev, (e) => fn(e.detail));
  OS.emit = (ev, d) => bus.dispatchEvent(new CustomEvent(ev, { detail: d }));

  OS.isMobile = () => window.innerWidth <= 720;
  OS.isTouch = () => window.matchMedia('(pointer: coarse)').matches;

  const store = {
    get(k, def) { try { const v = localStorage.getItem('adrielos.' + k); return v == null ? def : JSON.parse(v); } catch (e) { return def; } },
    set(k, v) { try { localStorage.setItem('adrielos.' + k, JSON.stringify(v)); return true; } catch (e) { return false; } },
    del(k) { try { localStorage.removeItem('adrielos.' + k); } catch (e) { /* ignora */ } }
  };
  OS.store = store;

  OS.download = (name, blobOrText, type) => {
    const blob = blobOrText instanceof Blob ? blobOrText : new Blob([blobOrText], { type: type || 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  };

  OS.readImageFile = (file, maxW, cb) => {
    const r = new FileReader();
    r.onload = () => {
      const img = new Image();
      img.onload = () => {
        const k = Math.min(1, maxW / img.width);
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        cb(c.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => cb(null);
      img.src = r.result;
    };
    r.onerror = () => cb(null);
    r.readAsDataURL(file);
  };

  /* ------------------------------- perfil -------------------------------- */
  OS.profile = Object.assign({ name: 'Adriel Morback', avatar: null }, store.get('profile', {}));
  OS.saveProfile = () => { store.set('profile', OS.profile); OS.emit('profile'); };
  OS.avatarHTML = (cls) => OS.profile.avatar
    ? `<span class="avatar ${cls || ''}"><img src="${OS.profile.avatar}" alt=""></span>`
    : `<span class="avatar ${cls || ''}"><b>AM</b></span>`;

  /* ----------------------------- configurações ---------------------------- */
  const DEFAULTS = {
    theme: 'dark', accent: '#0078d4', transparency: true, align: 'center', wallpaper: 'flor_azul_escuro',
    slideshow: false, brightness: 100, volume: 70, muted: false, iconSize: 'm', showIcons: true, sound: true,
    wifi: true, bluetooth: true, airplane: false, saver: false, focus: false, btnSearch: true, btnTaskview: true,
    btnWidgets: true, animations: true, bigText: false, clock24: true, showSeconds: false, autoLogin: false,
    pinned: ['explorer', 'browser', 'about', 'contact', 'terminal', 'settings']
  };
  OS.settings = Object.assign({}, DEFAULTS, store.get('settings', {}));
  if (!Array.isArray(OS.settings.pinned)) OS.settings.pinned = DEFAULTS.pinned.slice();

  function hexToRgb(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
    if (!m) return [0, 120, 212];
    const n = parseInt(m[1], 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  OS.isDark = () => {
    const t = OS.settings.theme;
    return t === 'auto' ? window.matchMedia('(prefers-color-scheme: dark)').matches : t !== 'light';
  };

  function applySetting(k) {
    const S = OS.settings, root = document.documentElement;
    switch (k) {
      case 'theme': root.dataset.theme = OS.isDark() ? 'dark' : 'light'; break;
      case 'accent': {
        const [r, g, b] = hexToRgb(S.accent);
        root.style.setProperty('--accent', S.accent);
        root.style.setProperty('--accent-rgb', `${r},${g},${b}`);
        const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        root.style.setProperty('--on-accent', lum > 0.62 ? '#000' : '#fff');
        break;
      }
      case 'transparency': root.dataset.transparency = S.transparency ? 'on' : 'off'; break;
      case 'align': root.dataset.align = S.align; break;
      case 'iconSize': root.dataset.icons = S.iconSize; break;
      case 'showIcons': root.dataset.showicons = S.showIcons ? 'on' : 'off'; break;
      case 'animations': root.dataset.anim = S.animations ? 'on' : 'off'; break;
      case 'bigText': root.dataset.bigtext = S.bigText ? 'on' : 'off'; break;
      case 'saver': root.dataset.saver = S.saver ? 'on' : 'off'; break;
      case 'brightness': {
        const dim = $('#dim');
        if (dim) dim.style.opacity = String(clamp((100 - S.brightness) / 100 * 0.85, 0, 0.85));
        break;
      }
      case 'volume': case 'muted': OS.audioUpdate && OS.audioUpdate(); break;
      case 'wallpaper': OS.wallpaper && OS.wallpaper.apply(); break;
      case 'btnSearch': root.dataset.btnsearch = S.btnSearch ? 'on' : 'off'; break;
      case 'btnTaskview': root.dataset.btntaskview = S.btnTaskview ? 'on' : 'off'; break;
      case 'btnWidgets': root.dataset.btnwidgets = S.btnWidgets ? 'on' : 'off'; break;
      default: break;
    }
  }
  OS.set = (k, v) => { OS.settings[k] = v; store.set('settings', OS.settings); applySetting(k); OS.emit('setting', { key: k, value: v }); };
  OS.applyAllSettings = () => Object.keys(OS.settings).forEach(applySetting);
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (OS.settings.theme === 'auto') applySetting('theme'); });

  /* --------------------------------- som ---------------------------------- */
  let ac = null, master = null;
  function audioCtx() {
    if (!ac) {
      const C = window.AudioContext || window.webkitAudioContext;
      if (!C) return null;
      ac = new C(); master = ac.createGain(); master.connect(ac.destination);
    }
    if (ac.state === 'suspended') ac.resume();
    OS.audioUpdate();
    return ac;
  }
  OS.audioUpdate = () => { if (master) master.gain.value = OS.settings.muted ? 0 : Math.pow(OS.settings.volume / 100, 1.6); };
  OS.audio = { ctx: audioCtx, out: () => { audioCtx(); return master; } };

  function tone(freq, t0, dur, type, vol, glideTo) {
    const c = audioCtx(); if (!c) return;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(freq, c.currentTime + t0);
    if (glideTo) o.frequency.exponentialRampToValueAtTime(glideTo, c.currentTime + t0 + dur);
    g.gain.setValueAtTime(0.0001, c.currentTime + t0);
    g.gain.exponentialRampToValueAtTime(vol, c.currentTime + t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + t0 + dur);
    o.connect(g); g.connect(master); o.start(c.currentTime + t0); o.stop(c.currentTime + t0 + dur + 0.05);
  }
  OS.sound = (type) => {
    if (!OS.settings.sound) return;
    try {
      switch (type) {
        case 'click': tone(900, 0, 0.04, 'sine', 0.08, 450); break;
        case 'open': tone(330, 0, 0.1, 'sine', 0.1, 660); break;
        case 'close': tone(540, 0, 0.09, 'sine', 0.09, 270); break;
        case 'toast': tone(659, 0, 0.12, 'sine', 0.1); tone(880, 0.09, 0.18, 'sine', 0.09); break;
        case 'error': tone(220, 0, 0.18, 'square', 0.05); tone(165, 0.16, 0.22, 'square', 0.05); break;
        case 'startup': [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.12, 0.7, 'sine', 0.1)); break;
        case 'shutdown': [784, 659, 523, 392].forEach((f, i) => tone(f, i * 0.14, 0.6, 'sine', 0.09)); break;
        default: break;
      }
    } catch (e) { /* ignora */ }
  };
  document.addEventListener('pointerdown', () => { if (!ac) { try { audioCtx(); } catch (e) { /* ignora */ } } }, { once: true });

  /* ---------------------------- papéis de parede -------------------------- */
  const W = 'assets/wallpapers/';
  const jpg = (id, name, group, theme) => ({ id, name, group, theme, src: `${W}${id}.jpg`, thumb: `${W}thumbs/${id}.jpg` });
  const WALLPAPERS = [
    jpg('flor_azul_escuro', 'Flor Azul — Escuro', 'Destaques', 'dark'),
    jpg('flor_azul_claro', 'Flor Azul — Claro', 'Destaques', 'light'),
    jpg('brilho', 'Brilho', 'Destaques', 'dark'),
    jpg('ondas_abstratas', 'Ondas Abstratas', 'Destaques', 'dark'),
    jpg('violeta', 'Violeta Mesh', 'Destaques', 'dark'),
    jpg('nascer_do_sol', 'Nascer do Sol', 'Paisagens', 'dark'),
    jpg('montanhas', 'Montanhas ao Entardecer', 'Paisagens', 'dark'),
    jpg('oceano', 'Oceano Profundo', 'Paisagens', 'dark'),
    jpg('floresta', 'Floresta na Neblina', 'Paisagens', 'dark'),
    jpg('colinas', 'Colinas Verdes', 'Paisagens', 'light'),
    jpg('dunas', 'Dunas ao Meio-dia', 'Paisagens', 'light'),
    jpg('aurora_boreal', 'Aurora Boreal', 'Noite & Espaço', 'dark'),
    jpg('espaco', 'Espaço Profundo', 'Noite & Espaço', 'dark'),
    jpg('cidade_neon', 'Cidade Neon', 'Noite & Espaço', 'dark'),
    jpg('estadio_noite', 'Estádio à Noite', 'Futebol & Código', 'dark'),
    jpg('adriel_tactical_pitch', 'Cyber Tático de Futebol', 'Futebol & Código', 'dark'),
    { id: 'cyber_matrix_pitch', name: 'Matriz Vetorial de Futebol', group: 'Futebol & Código', theme: 'dark', src: W + 'cyber_matrix_pitch.svg', thumb: W + 'cyber_matrix_pitch.svg' },
    { id: 'deep_space_aurora', name: 'Aurora Cósmica Esmeralda', group: 'Noite & Espaço', theme: 'dark', src: W + 'deep_space_aurora.svg', thumb: W + 'deep_space_aurora.svg' },
    { id: 'minimal_slate_field', name: 'Ardósia Minimalista', group: 'Minimalistas', theme: 'dark', src: W + 'minimal_slate_field.svg', thumb: W + 'minimal_slate_field.svg' },
    jpg('grafite', 'Grafite', 'Minimalistas', 'dark'),
    { id: 'live_matrix', name: 'Chuva de Código (animado)', group: 'Animados', theme: 'dark', live: 'matrix', thumb: '', css: 'linear-gradient(160deg,#001a0d,#003d1f)' },
    { id: 'live_stars', name: 'Viagem Estelar (animado)', group: 'Animados', theme: 'dark', live: 'stars', thumb: '', css: 'radial-gradient(circle at 50% 50%,#1b2a6b,#02030a 70%)' },
    { id: 'live_pitch', name: 'Bola Quicando (animado)', group: 'Animados', theme: 'dark', live: 'pitch', thumb: '', css: 'linear-gradient(180deg,#052e1a,#0f7a3f)' }
  ];
  const solids = ['#0f172a', '#1e293b', '#0b3d2e', '#3b0764', '#7f1d1d', '#0c4a6e', '#78350f', '#111111'];
  solids.forEach((c, i) => WALLPAPERS.push({ id: 'solid_' + i, name: 'Cor sólida ' + (i + 1), group: 'Cores sólidas', theme: 'dark', solid: c, thumb: '', css: c }));

  const WP = (OS.wallpaper = {
    list: () => {
      const l = WALLPAPERS.slice();
      const custom = store.get('customWallpaper', null);
      if (custom) l.push({ id: 'custom', name: 'Minha imagem', group: 'Personalizado', theme: 'dark', src: custom, thumb: custom });
      return l;
    },
    get: (id) => WP.list().find((w) => w.id === id) || WALLPAPERS[0],
    current: () => WP.get(OS.settings.wallpaper),
    _layer: 0, _live: null,
    apply() {
      const w = WP.current();
      const a = $('#wp-a'), b = $('#wp-b'); if (!a || !b) return;
      const next = WP._layer ? a : b, prev = WP._layer ? b : a;
      if (w.live) { next.style.backgroundImage = 'none'; next.style.background = w.css; }
      else if (w.solid) { next.style.backgroundImage = 'none'; next.style.background = w.solid; }
      else { next.style.background = ''; next.style.backgroundImage = `url("${w.src}")`; }
      next.classList.add('on'); prev.classList.remove('on'); WP._layer = WP._layer ? 0 : 1;
      WP.live(w.live || null);
      document.documentElement.style.setProperty('--wp-url', w.src && !w.live ? `url("${w.src}")` : 'none');
      OS.emit('wallpaper', w);
    },
    set(id, silent) {
      OS.set('wallpaper', id);
      if (!silent) OS.sound('click');
    },
    next(dir) {
      const l = WP.list().filter((w) => !w.solid);
      const i = Math.max(0, l.findIndex((w) => w.id === OS.settings.wallpaper));
      WP.set(l[(i + (dir || 1) + l.length) % l.length].id);
    },
    setCustom(file, cb) {
      OS.readImageFile(file, 1920, (data) => {
        if (!data) { cb && cb(false); return; }
        const ok = store.set('customWallpaper', data);
        if (!ok) { OS.notify({ title: 'Imagem grande demais', body: 'O navegador não conseguiu guardar essa imagem. Tente uma menor.', icon: 'photos' }); cb && cb(false); return; }
        WP.set('custom'); cb && cb(true);
      });
    },
    live(kind) {
      const cv = $('#live-wall'); if (!cv) return;
      if (WP._live) { WP._live.stop(); WP._live = null; }
      cv.style.display = kind ? 'block' : 'none';
      if (kind && OS.liveWallpapers && OS.liveWallpapers[kind]) WP._live = OS.liveWallpapers[kind](cv);
    }
  });

  OS.liveWallpapers = {
    matrix(cv) {
      const x = cv.getContext('2d'); let run = true, cols, drops, fs = 16;
      const chars = 'アイウエオカキクケコサシスセソ0123456789{}[]<>/=+*#ABCDEF';
      function size() { cv.width = innerWidth; cv.height = innerHeight; cols = Math.ceil(cv.width / fs); drops = Array.from({ length: cols }, () => Math.random() * -50); }
      size(); window.addEventListener('resize', size);
      (function loop() {
        if (!run) return;
        x.fillStyle = 'rgba(0,12,6,.12)'; x.fillRect(0, 0, cv.width, cv.height);
        x.font = fs + 'px "Cascadia Mono", Consolas, monospace';
        for (let i = 0; i < cols; i++) {
          x.fillStyle = Math.random() > 0.96 ? '#e8fff0' : '#22d36b';
          x.fillText(chars[(Math.random() * chars.length) | 0], i * fs, drops[i] * fs);
          if (drops[i] * fs > cv.height && Math.random() > 0.975) drops[i] = 0;
          drops[i] += 0.55;
        }
        requestAnimationFrame(loop);
      })();
      return { stop() { run = false; window.removeEventListener('resize', size); } };
    },
    stars(cv) {
      const x = cv.getContext('2d'); let run = true, stars = [];
      function size() { cv.width = innerWidth; cv.height = innerHeight; stars = Array.from({ length: 380 }, () => ({ x: Math.random() * 2 - 1, y: Math.random() * 2 - 1, z: Math.random() })); }
      size(); window.addEventListener('resize', size);
      (function loop() {
        if (!run) return;
        x.fillStyle = '#02030a'; x.fillRect(0, 0, cv.width, cv.height);
        const cx = cv.width / 2, cy = cv.height / 2;
        for (const s of stars) {
          s.z -= 0.004; if (s.z <= 0.01) { s.x = Math.random() * 2 - 1; s.y = Math.random() * 2 - 1; s.z = 1; }
          const px = cx + (s.x / s.z) * cx * 0.5, py = cy + (s.y / s.z) * cy * 0.5, r = (1 - s.z) * 2.2;
          x.fillStyle = `rgba(190,210,255,${1 - s.z})`; x.beginPath(); x.arc(px, py, r, 0, 6.3); x.fill();
        }
        requestAnimationFrame(loop);
      })();
      return { stop() { run = false; window.removeEventListener('resize', size); } };
    },
    pitch(cv) {
      const x = cv.getContext('2d'); let run = true, t = 0;
      const ball = { x: 300, y: 200, vx: 4, vy: 2.5 };
      function size() { cv.width = innerWidth; cv.height = innerHeight; }
      size(); window.addEventListener('resize', size);
      (function loop() {
        if (!run) return;
        const w = cv.width, h = cv.height; t++;
        x.fillStyle = '#0b6b34'; x.fillRect(0, 0, w, h);
        for (let i = 0; i < 12; i++) { x.fillStyle = i % 2 ? 'rgba(255,255,255,.03)' : 'rgba(0,0,0,.05)'; x.fillRect(i * w / 12, 0, w / 12, h); }
        x.strokeStyle = 'rgba(255,255,255,.55)'; x.lineWidth = 3;
        const m = 60; x.strokeRect(m, m, w - 2 * m, h - 2 * m);
        x.beginPath(); x.moveTo(w / 2, m); x.lineTo(w / 2, h - m); x.stroke();
        x.beginPath(); x.arc(w / 2, h / 2, Math.min(h, w) * 0.13, 0, 6.3); x.stroke();
        const bw = (h - 2 * m) * 0.5, bh = (w - 2 * m) * 0.14;
        x.strokeRect(m, h / 2 - bw / 2, bh, bw); x.strokeRect(w - m - bh, h / 2 - bw / 2, bh, bw);
        ball.x += ball.vx; ball.y += ball.vy;
        if (ball.x < m + 12 || ball.x > w - m - 12) ball.vx *= -1;
        if (ball.y < m + 12 || ball.y > h - m - 12) ball.vy *= -1;
        x.save(); x.translate(ball.x, ball.y); x.rotate(t * 0.05);
        x.fillStyle = '#fff'; x.beginPath(); x.arc(0, 0, 14, 0, 6.3); x.fill();
        x.fillStyle = '#111'; x.beginPath(); for (let i = 0; i < 5; i++) { const a = i * 1.2566; x.lineTo(Math.cos(a) * 7, Math.sin(a) * 7); } x.fill();
        x.restore();
        requestAnimationFrame(loop);
      })();
      return { stop() { run = false; window.removeEventListener('resize', size); } };
    }
  };

  let slideTimer = null;
  OS.on('setting', (d) => {
    if (d.key !== 'slideshow') return;
    clearInterval(slideTimer);
    if (d.value) slideTimer = setInterval(() => { if (OS.settings.slideshow) WP.next(1); }, 25000);
  });
  OS.startSlideshow = () => { if (OS.settings.slideshow) { clearInterval(slideTimer); slideTimer = setInterval(() => WP.next(1), 25000); } };

  /* ----------------------------- notificações ----------------------------- */
  OS.notifications = [];
  OS.notify = (n) => {
    const item = Object.assign({ id: Date.now() + Math.random(), time: new Date(), app: 'AdrielOS', icon: 'about', title: '', body: '' }, n);
    OS.notifications.unshift(item);
    if (OS.notifications.length > 40) OS.notifications.pop();
    OS.emit('notifications');
    if (OS.settings.focus && !n.force) return item;
    const box = $('#toasts'); if (!box) return item;
    OS.sound('toast');
    const t = html(`<div class="toast" role="status">
      <div class="toast-head"><span class="toast-app">${icon(item.icon)}<span>${esc(item.app)}</span></span><button class="toast-x" aria-label="Fechar">${UI.close}</button></div>
      <div class="toast-title">${esc(item.title)}</div>${item.body ? `<div class="toast-body">${esc(item.body)}</div>` : ''}
      ${item.actions ? `<div class="toast-actions">${item.actions.map((a, i) => `<button data-i="${i}">${esc(a.label)}</button>`).join('')}</div>` : ''}
    </div>`);
    while (box.children.length >= 3) box.firstChild.remove();
    box.appendChild(t);
    const kill = () => { t.classList.add('out'); setTimeout(() => t.remove(), 260); };
    $('.toast-x', t).onclick = kill;
    if (item.actions) $$('.toast-actions button', t).forEach((b) => (b.onclick = () => { item.actions[b.dataset.i].run(); kill(); }));
    setTimeout(kill, n.sticky ? 12000 : 6000);
    return item;
  };
  OS.toast = (msg, ic) => OS.notify({ title: msg, icon: ic || 'about' });

  /* ------------------------------ diálogos -------------------------------- */
  OS.dialog = ({ title, message, icon: ic, buttons, input, defaultValue }) => new Promise((resolve) => {
    const layer = html(`<div class="modal-layer"><div class="modal" role="alertdialog" aria-modal="true">
      <div class="modal-bar">${ic ? icon(ic) : ''}<span>${esc(title || 'AdrielOS')}</span></div>
      <div class="modal-body"><p>${message || ''}</p>${input ? `<input class="modal-input" type="text" value="${esc(defaultValue || '')}">` : ''}</div>
      <div class="modal-foot"></div></div></div>`);
    const foot = $('.modal-foot', layer);
    const done = (v) => { layer.remove(); resolve(v); };
    (buttons || [{ label: 'OK', value: true, primary: true }]).forEach((b) => {
      const btn = html(`<button class="btn ${b.primary ? 'primary' : ''}">${esc(b.label)}</button>`);
      btn.onclick = () => done(input && b.primary ? $('.modal-input', layer).value : b.value);
      foot.appendChild(btn);
    });
    layer.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') done(input ? null : false);
      if (e.key === 'Enter') { const p = $('.btn.primary', layer); if (p) p.click(); }
    });
    document.body.appendChild(layer);
    OS.sound('error');
    const f = $('.modal-input', layer) || $('.btn.primary', layer) || $('.btn', layer); f && f.focus();
    if (input && f) f.select();
  });
  OS.confirm = (title, message, ok, cancel) => OS.dialog({ title, message, icon: 'about', buttons: [{ label: ok || 'Sim', value: true, primary: true }, { label: cancel || 'Não', value: false }] });
  OS.prompt = (title, message, def) => OS.dialog({ title, message, input: true, defaultValue: def, buttons: [{ label: 'OK', value: true, primary: true }, { label: 'Cancelar', value: null }] });

  /* --------------------------- menu de contexto --------------------------- */
  let ctxEl = null;
  OS.closeCtx = () => { if (ctxEl) { ctxEl.remove(); ctxEl = null; } };
  function buildMenu(items) {
    const m = html('<div class="ctx" role="menu"></div>');
    items.forEach((it) => {
      if (!it) return;
      if (it.sep) { m.appendChild(html('<div class="ctx-sep"></div>')); return; }
      const row = html(`<button class="ctx-item" role="menuitem" ${it.disabled ? 'disabled' : ''}>
        <span class="ctx-ic">${it.checked ? UI.check : (it.icon ? (UI[it.icon] || icon(it.icon)) : '')}</span>
        <span class="ctx-label">${esc(it.label)}</span>${it.hint ? `<span class="ctx-hint">${esc(it.hint)}</span>` : ''}
        ${it.submenu ? `<span class="ctx-arrow">${UI.chevronRight}</span>` : ''}</button>`);
      if (it.submenu) {
        let sub = null;
        const open = () => {
          if (sub) return;
          sub = buildMenu(it.submenu); sub.classList.add('ctx-sub'); row.appendChild(sub);
          const r = row.getBoundingClientRect(), sw = 230;
          sub.style.left = (r.right + sw > innerWidth ? -sw + 6 : r.width - 6) + 'px'; sub.style.top = '-5px';
        };
        row.addEventListener('mouseenter', open);
        row.addEventListener('click', (e) => { e.stopPropagation(); open(); });
        row.addEventListener('mouseleave', (e) => { if (sub && !row.contains(e.relatedTarget)) { sub.remove(); sub = null; } });
      } else if (!it.disabled) {
        row.addEventListener('click', () => { OS.closeCtx(); OS.sound('click'); it.action && it.action(); });
      }
      m.appendChild(row);
    });
    return m;
  }
  OS.ctx = (x, y, items, opts) => {
    OS.closeCtx();
    const m = buildMenu(items); if (opts && opts.up) m.classList.add('up');
    document.body.appendChild(m); ctxEl = m;
    const r = m.getBoundingClientRect();
    let px = x, py = y;
    if (opts && opts.fromBottom) py = y - r.height;
    if (px + r.width > innerWidth - 4) px = Math.max(4, innerWidth - r.width - 4);
    if (py + r.height > innerHeight - OS.TB - 2 && !(opts && opts.fromBottom)) py = Math.max(4, y - r.height);
    m.style.left = px + 'px'; m.style.top = Math.max(4, py) + 'px';
    return m;
  };
  document.addEventListener('pointerdown', (e) => { if (ctxEl && !e.target.closest('.ctx')) OS.closeCtx(); }, true);
  window.addEventListener('blur', () => OS.closeCtx());

  /* -------------------------------- painéis ------------------------------- */
  OS.registerPanel = (name, el, hooks) => { OS.panels[name] = Object.assign({ el, open: false }, hooks || {}); el.hidden = true; el.classList.add('panel'); };
  OS.panelOpen = (name) => !!(OS.panels[name] && OS.panels[name].open);
  OS.closePanels = (except) => Object.keys(OS.panels).forEach((n) => { if (n !== except) OS.closePanel(n); });
  OS.openPanel = (name, arg) => {
    const p = OS.panels[name]; if (!p) return;
    OS.closePanels(name); OS.closeCtx();
    if (p.open) { p.onOpen && p.onOpen(arg); return; }
    p.open = true; p.el.hidden = false;
    requestAnimationFrame(() => requestAnimationFrame(() => p.el.classList.add('open')));
    p.onOpen && p.onOpen(arg);
    OS.emit('panel', name);
  };
  OS.closePanel = (name) => {
    const p = OS.panels[name]; if (!p || !p.open) return;
    p.open = false; p.el.classList.remove('open');
    setTimeout(() => { if (!p.open) p.el.hidden = true; }, OS.settings.animations ? 200 : 0);
    p.onClose && p.onClose();
    OS.emit('panel', name);
  };
  OS.togglePanel = (name, arg) => (OS.panelOpen(name) ? OS.closePanel(name) : OS.openPanel(name, arg));
  document.addEventListener('pointerdown', (e) => {
    if (e.target.closest('.panel, [data-toggles-panel], .ctx, .modal-layer')) return;
    OS.closePanels();
  }, true);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { OS.closePanels(); OS.closeCtx(); if (OS.closeTaskView) OS.closeTaskView(); }
  });

  /* ------------------------------ aplicativos ----------------------------- */
  OS.registerApp = (def) => { OS.apps[def.id] = Object.assign({ w: 720, h: 520, minW: 340, minH: 220, category: 'Aplicativos', keywords: '' }, def); };
  const icon = (name) => (window.icon ? window.icon(name) : '');
  OS.icon = icon;
  const UI = window.UI;

  OS.recent = store.get('recent', []);
  OS.addRecent = (r) => {
    OS.recent = OS.recent.filter((x) => !(x.app === r.app && (x.arg || '') === (r.arg || '')));
    OS.recent.unshift(Object.assign({ t: Date.now() }, r));
    OS.recent = OS.recent.slice(0, 12); store.set('recent', OS.recent);
  };

  /* ======================== GERENCIADOR DE JANELAS ======================== */
  const WM = (OS.wm = { z: 100, seq: 0, active: null });
  const layerEl = () => $('#windows');
  const area = () => ({ w: window.innerWidth, h: window.innerHeight - OS.TB });

  const SNAP_LAYOUTS = [
    { name: 'Duas colunas', zones: [[0, 0, 0.5, 1], [0.5, 0, 0.5, 1]] },
    { name: '2/3 e 1/3', zones: [[0, 0, 0.66, 1], [0.66, 0, 0.34, 1]] },
    { name: '1/3 e 2/3', zones: [[0, 0, 0.34, 1], [0.34, 0, 0.66, 1]] },
    { name: 'Três colunas', zones: [[0, 0, 0.333, 1], [0.333, 0, 0.334, 1], [0.667, 0, 0.333, 1]] },
    { name: 'Principal + 2', zones: [[0, 0, 0.5, 1], [0.5, 0, 0.5, 0.5], [0.5, 0.5, 0.5, 0.5]] },
    { name: 'Quatro cantos', zones: [[0, 0, 0.5, 0.5], [0.5, 0, 0.5, 0.5], [0, 0.5, 0.5, 0.5], [0.5, 0.5, 0.5, 0.5]] }
  ];

  OS.openApp = (id, opts) => WM.open(id, opts);
  OS.windowsOf = (appId) => OS.wins.filter((w) => w.appId === appId);

  WM.open = function (appId, opts) {
    opts = opts || {};
    const app = OS.apps[appId];
    if (!app) { OS.toast('Aplicativo não encontrado: ' + appId, 'about'); return null; }
    OS.closePanels(); OS.closeCtx();
    if (OS.closeTaskView) OS.closeTaskView();

    if (app.single) {
      const ex = OS.windowsOf(appId)[0];
      if (ex) {
        ex.restore(); ex.focus();
        if (ex.onOpenAgain) ex.onOpenAgain(opts);
        return ex;
      }
    }

    const a = area();
    const mobile = OS.isMobile();
    const w = Math.min(opts.w || app.w, a.w - 16), h = Math.min(opts.h || app.h, a.h - 16);
    const n = OS.wins.length % 8;
    const x = Math.max(8, Math.round((a.w - w) / 2) + (n - 3) * 26 + (opts.dx || 0));
    const y = Math.max(8, Math.round((a.h - h) / 2) + (n - 3) * 22 - 6 + (opts.dy || 0));

    const el = html(`<section class="win" role="dialog" aria-label="${esc(app.title)}">
      <i class="rz rz-n"></i><i class="rz rz-s"></i><i class="rz rz-e"></i><i class="rz rz-w"></i><i class="rz rz-ne"></i><i class="rz rz-nw"></i><i class="rz rz-se"></i><i class="rz rz-sw"></i>
      <header class="win-bar">
        <span class="win-icon">${icon(app.icon)}</span><span class="win-title"></span>
        <div class="win-actions">
          ${app.noMin ? '' : `<button class="wb wb-min" aria-label="Minimizar" title="Minimizar">${UI.minimize}</button>`}
          ${app.noMax ? '' : `<button class="wb wb-max" aria-label="Maximizar" title="Maximizar">${UI.maximize}</button>`}
          <button class="wb wb-close" aria-label="Fechar" title="Fechar">${UI.close}</button>
        </div>
      </header><div class="win-body"></div></section>`);

    const win = {
      id: appId + '#' + ++WM.seq, appId, app, el, body: $('.win-body', el), bar: $('.win-bar', el),
      min: false, max: false, snap: null, rect: { x, y, w, h }, restoreRect: null, handlers: { close: [] },
      title: opts.title || app.title,
      setTitle(t) { win.title = t; $('.win-title', el).textContent = t; el.setAttribute('aria-label', t); OS.emit('wm'); },
      setIcon(name) { $('.win-icon', el).innerHTML = icon(name); win.iconName = name; OS.emit('wm'); },
      onClose(fn) { win.handlers.close.push(fn); },
      focus() { WM.focus(win); },
      applyRect() {
        const r = win.rect;
        el.style.left = r.x + 'px'; el.style.top = r.y + 'px'; el.style.width = r.w + 'px'; el.style.height = r.h + 'px';
      },
      toggleMax() { win.max ? win.restore() : win.maximize(); },
      maximize() {
        if (app.noMax || win.max) return;
        if (!win.snap) win.restoreRect = Object.assign({}, win.rect);
        win.snap = null; win.max = true; el.classList.add('max'); el.classList.remove('snapped');
        const a2 = area(); win.rect = { x: 0, y: 0, w: a2.w, h: a2.h }; win.applyRect();
        $('.wb-max', el) && ($('.wb-max', el).innerHTML = UI.restore);
        OS.emit('wm');
      },
      restore() {
        if (win.min) { WM.unminimize(win); return; }
        if (win.max || win.snap) {
          const r = win.restoreRect || { x, y, w, h };
          win.max = false; win.snap = null; el.classList.remove('max', 'snapped');
          win.rect = Object.assign({}, r); win.applyRect();
          $('.wb-max', el) && ($('.wb-max', el).innerHTML = UI.maximize);
          OS.emit('wm');
        }
      },
      snapTo(fr) {
        if (app.noMax || OS.isMobile()) return;
        if (!win.max && !win.snap) win.restoreRect = Object.assign({}, win.rect);
        win.max = false; win.snap = fr; el.classList.remove('max'); el.classList.add('snapped');
        win.layoutSnap(); $('.wb-max', el) && ($('.wb-max', el).innerHTML = UI.restore); OS.emit('wm');
      },
      layoutSnap() {
        if (!win.snap) return; const a2 = area(), f = win.snap, g = 0;
        win.rect = { x: Math.round(f[0] * a2.w) + g, y: Math.round(f[1] * a2.h) + g, w: Math.round(f[2] * a2.w) - g * 2, h: Math.round(f[3] * a2.h) - g * 2 };
        win.applyRect();
      },
      minimize() { WM.minimize(win); },
      close() { WM.close(win); }
    };

    $('.win-title', el).textContent = win.title;
    win.applyRect();
    if (mobile && !app.noMax) { win.restoreRect = { x, y, w, h }; win.max = true; el.classList.add('max'); const a2 = area(); win.rect = { x: 0, y: 0, w: a2.w, h: a2.h }; win.applyRect(); $('.wb-max', el) && ($('.wb-max', el).innerHTML = UI.restore); }
    layerEl().appendChild(el);
    OS.wins.push(win);
    OS.opened++;
    wireWindow(win);
    try { const ret = app.build(win, opts); if (ret && typeof ret === 'object') Object.assign(win, ret); } catch (err) { console.error('Erro ao abrir', appId, err); win.body.innerHTML = `<div class="pad">Erro ao abrir o aplicativo: ${esc(err.message)}</div>`; }
    if (opts.maximize && !mobile) win.maximize();
    WM.focus(win);
    OS.sound('open');
    OS.emit('wm', { opened: win });
    return win;
  };

  WM.focus = function (win) {
    if (!win || !OS.wins.includes(win)) return;
    if (win.min) WM.unminimize(win, true);
    WM.z++; win.el.style.zIndex = WM.z; WM.active = win;
    OS.wins.forEach((w) => w.el.classList.toggle('active', w === win));
    // mantém ordem de empilhamento para o Task View
    OS.wins.splice(OS.wins.indexOf(win), 1); OS.wins.push(win);
    win.onFocus && win.onFocus();
    OS.emit('wm');
  };

  function taskbarRectFor(win) {
    const b = $(`.tb-app[data-app="${win.appId}"]`) || $('.tb-start');
    return b ? b.getBoundingClientRect() : { left: innerWidth / 2, top: innerHeight - 24, width: 40, height: 40 };
  }

  WM.minimize = function (win) {
    if (win.min) return;
    win.min = true; win.el.classList.remove('active');
    const r = win.el.getBoundingClientRect(), t = taskbarRectFor(win);
    const dx = t.left + t.width / 2 - (r.left + r.width / 2), dy = t.top + t.height / 2 - (r.top + r.height / 2);
    const finish = () => { if (win.min) win.el.classList.add('min'); };
    if (OS.settings.animations && win.el.animate) {
      const an = win.el.animate([{ transform: 'none', opacity: 1 }, { transform: `translate(${dx}px,${dy}px) scale(.25)`, opacity: 0 }], { duration: 220, easing: 'cubic-bezier(.4,0,.8,.4)' });
      an.onfinish = finish;
    } else finish();
    if (WM.active === win) {
      WM.active = null;
      const next = OS.wins.slice().reverse().find((w) => !w.min);
      if (next) WM.focus(next);
    }
    OS.emit('wm');
  };
  WM.unminimize = function (win, noFocus) {
    if (!win.min) return;
    win.min = false; win.el.classList.remove('min');
    const r = win.el.getBoundingClientRect(), t = taskbarRectFor(win);
    const dx = t.left + t.width / 2 - (r.left + r.width / 2), dy = t.top + t.height / 2 - (r.top + r.height / 2);
    if (OS.settings.animations && win.el.animate) win.el.animate([{ transform: `translate(${dx}px,${dy}px) scale(.25)`, opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 240, easing: 'cubic-bezier(.2,.8,.2,1)' });
    if (!noFocus) WM.focus(win); else OS.emit('wm');
  };

  WM.close = function (win) {
    if (win._closing) return;
    for (const fn of win.handlers.close) { try { if (fn() === false) return; } catch (e) { console.error(e); } }
    win._closing = true;
    OS.sound('close');
    const done = () => {
      win.el.remove();
      OS.wins.splice(OS.wins.indexOf(win), 1);
      if (WM.active === win) {
        WM.active = null;
        const next = OS.wins.slice().reverse().find((w) => !w.min);
        if (next) WM.focus(next);
      }
      OS.emit('wm', { closed: win });
    };
    if (OS.settings.animations && win.el.animate) {
      win.el.style.pointerEvents = 'none';
      win.el.animate([{ transform: 'scale(1)', opacity: 1 }, { transform: 'scale(.94)', opacity: 0 }], { duration: 140, easing: 'ease-in' }).onfinish = done;
    } else done();
  };

  WM.minimizeAll = function () { OS.wins.slice().forEach((w) => w.minimize()); };
  WM.showDesktop = function () {
    const anyVisible = OS.wins.some((w) => !w.min);
    if (anyVisible) { WM._hidden = OS.wins.filter((w) => !w.min); WM.minimizeAll(); }
    else if (WM._hidden) { WM._hidden.forEach((w) => OS.wins.includes(w) && WM.unminimize(w, true)); const last = WM._hidden[WM._hidden.length - 1]; last && WM.focus(last); WM._hidden = null; }
  };
  OS.showDesktop = WM.showDesktop;

  /* ----------- interação: arrastar, redimensionar, snap, botões ---------- */
  function wireWindow(win) {
    const { el, bar } = win;
    el.addEventListener('pointerdown', () => { if (WM.active !== win) WM.focus(win); }, true);
    $('.wb-min', el) && ($('.wb-min', el).onclick = () => win.minimize());
    $('.wb-max', el) && ($('.wb-max', el).onclick = () => win.toggleMax());
    $('.wb-close', el).onclick = () => win.close();
    bar.addEventListener('dblclick', (e) => { if (!e.target.closest('.win-actions') && !win.app.noMax) win.toggleMax(); });
    bar.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      OS.ctx(e.clientX, e.clientY, [
        { label: 'Restaurar', icon: 'restore', disabled: !(win.max || win.snap), action: () => win.restore() },
        { label: 'Minimizar', icon: 'minimize', action: () => win.minimize() },
        { label: 'Maximizar', icon: 'maximize', disabled: win.max || win.app.noMax, action: () => win.maximize() },
        { sep: true }, { label: 'Fechar', icon: 'close', hint: 'Alt+F4', action: () => win.close() }
      ]);
    });

    // ---- arrastar ----
    let drag = null;
    const preview = () => $('#snap-preview');
    function zoneAt(px, py) {
      const a = area(), m = 10, c = 70;
      if (px <= m && py <= c) return [0, 0, 0.5, 0.5];
      if (px >= a.w - m && py <= c) return [0.5, 0, 0.5, 0.5];
      if (px <= m && py >= a.h - c) return [0, 0.5, 0.5, 0.5];
      if (px >= a.w - m && py >= a.h - c) return [0.5, 0.5, 0.5, 0.5];
      if (py <= 4) return [0, 0, 1, 1];
      if (px <= m) return [0, 0, 0.5, 1];
      if (px >= a.w - m) return [0.5, 0, 0.5, 1];
      return null;
    }
    bar.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || e.target.closest('.win-actions') || OS.isMobile()) return;
      drag = { sx: e.clientX, sy: e.clientY, ox: win.rect.x, oy: win.rect.y, moved: false, zone: null, id: e.pointerId };
      bar.setPointerCapture(e.pointerId);
    });
    bar.addEventListener('pointermove', (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
      if (!drag.moved) {
        if (Math.abs(dx) + Math.abs(dy) < 4) return;
        drag.moved = true; document.body.classList.add('dragging'); el.classList.add('moving');
        if (win.max || win.snap) {
          const wasMax = win.max, cur = win.rect, back = win.restoreRect || { w: win.app.w, h: win.app.h };
          const ratio = clamp((e.clientX - cur.x) / cur.w, 0.1, 0.9);
          win.max = false; win.snap = null; el.classList.remove('max', 'snapped');
          const nw = Math.min(back.w, area().w - 20), nh = Math.min(back.h, area().h - 20);
          win.rect = { x: Math.round(e.clientX - nw * ratio), y: 0, w: nw, h: nh }; win.applyRect();
          $('.wb-max', el) && ($('.wb-max', el).innerHTML = UI.maximize);
          drag.ox = win.rect.x; drag.oy = win.rect.y; drag.sx = e.clientX; drag.sy = e.clientY; void wasMax;
          return;
        }
      }
      const a = area();
      win.rect.x = clamp(drag.ox + (e.clientX - drag.sx), 80 - win.rect.w, a.w - 80);
      win.rect.y = clamp(drag.oy + (e.clientY - drag.sy), 0, a.h - 36);
      win.applyRect();
      const z = win.app.noMax ? null : zoneAt(e.clientX, e.clientY);
      drag.zone = z;
      const p = preview();
      if (z) { p.style.cssText = `display:block;left:${z[0] * a.w + 6}px;top:${z[1] * a.h + 6}px;width:${z[2] * a.w - 12}px;height:${z[3] * a.h - 12}px`; p.classList.add('on'); }
      else { p.classList.remove('on'); p.style.display = 'none'; }
    });
    const endDrag = (e) => {
      if (!drag || (e && e.pointerId !== drag.id)) return;
      const z = drag.zone, moved = drag.moved; drag = null;
      document.body.classList.remove('dragging'); el.classList.remove('moving');
      const p = preview(); p.classList.remove('on'); p.style.display = 'none';
      if (moved && z) {
        if (z[2] === 1 && z[3] === 1) { win.restoreRect = Object.assign({}, win.rect); win.maximize(); }
        else win.snapTo(z);
      }
    };
    bar.addEventListener('pointerup', endDrag);
    bar.addEventListener('pointercancel', endDrag);

    // ---- redimensionar ----
    $$('.rz', el).forEach((h) => {
      h.addEventListener('pointerdown', (e) => {
        if (e.button !== 0 || win.max || OS.isMobile() || win.app.noResize) return;
        e.preventDefault(); e.stopPropagation();
        const dir = h.className.replace('rz rz-', '').trim();
        const s = { x: e.clientX, y: e.clientY, r: Object.assign({}, win.rect) };
        const minW = win.app.minW, minH = win.app.minH, a = area();
        h.setPointerCapture(e.pointerId); document.body.classList.add('dragging');
        if (win.snap) { win.restoreRect = win.restoreRect || Object.assign({}, win.rect); win.snap = null; el.classList.remove('snapped'); $('.wb-max', el) && ($('.wb-max', el).innerHTML = UI.maximize); }
        const mv = (ev) => {
          const dx = ev.clientX - s.x, dy = ev.clientY - s.y; let { x, y, w, h: hh } = s.r;
          if (dir.includes('e')) w = Math.max(minW, s.r.w + dx);
          if (dir.includes('s')) hh = Math.max(minH, s.r.h + dy);
          if (dir.includes('w')) { w = Math.max(minW, s.r.w - dx); x = s.r.x + (s.r.w - w); }
          if (dir.includes('n')) { hh = Math.max(minH, s.r.h - dy); y = s.r.y + (s.r.h - hh); }
          y = Math.max(0, y); hh = Math.min(hh, a.h - y + 40);
          win.rect = { x, y, w, h: hh }; win.applyRect(); win.onResize && win.onResize();
        };
        const up = () => { h.removeEventListener('pointermove', mv); h.removeEventListener('pointerup', up); document.body.classList.remove('dragging'); };
        h.addEventListener('pointermove', mv); h.addEventListener('pointerup', up);
      });
    });

    // ---- Snap Layouts ao passar sobre o botão maximizar ----
    const maxBtn = $('.wb-max', el);
    if (maxBtn && !win.app.noMax) {
      let timer = null, pop = null;
      const hide = () => { clearTimeout(timer); if (pop) { pop.remove(); pop = null; } };
      maxBtn.addEventListener('mouseenter', () => {
        if (OS.isTouch() || OS.isMobile()) return;
        timer = setTimeout(() => {
          pop = html('<div class="snap-pop"></div>');
          SNAP_LAYOUTS.forEach((L) => {
            const lay = html(`<div class="snap-lay" title="${L.name}"></div>`);
            L.zones.forEach((z) => {
              const b = html('<button class="snap-zone"></button>');
              b.style.cssText = `left:${z[0] * 100}%;top:${z[1] * 100}%;width:${z[2] * 100}%;height:${z[3] * 100}%`;
              b.onclick = (ev) => { ev.stopPropagation(); hide(); win.snapTo(z); WM.suggestSnap(win, z, L); };
              lay.appendChild(b);
            });
            pop.appendChild(lay);
          });
          const r = maxBtn.getBoundingClientRect();
          pop.style.left = clamp(r.left + r.width / 2 - 100, 8, innerWidth - 216) + 'px'; pop.style.top = (r.bottom + 4) + 'px';
          document.body.appendChild(pop);
          pop.addEventListener('mouseleave', hide);
          pop.addEventListener('mouseenter', () => clearTimeout(timer));
        }, 450);
      });
      maxBtn.addEventListener('mouseleave', (e) => { clearTimeout(timer); setTimeout(() => { if (pop && !pop.matches(':hover') && !maxBtn.matches(':hover')) hide(); }, 120); void e; });
      maxBtn.addEventListener('click', hide);
    }
  }

  // Após encaixar uma janela, ajuda a preencher as demais zonas do layout com outras janelas abertas
  WM.suggestSnap = function (win, zone, layout) {
    const others = OS.wins.filter((w) => w !== win && !w.min && !w.app.noMax);
    const free = layout.zones.filter((z) => z !== zone);
    free.forEach((z, i) => { if (others[i]) others[i].snapTo(z); });
  };

  window.addEventListener('resize', () => {
    const a = area();
    OS.wins.forEach((w) => {
      if (w.max) { w.rect = { x: 0, y: 0, w: a.w, h: a.h }; w.applyRect(); }
      else if (w.snap) w.layoutSnap();
      else {
        w.rect.w = Math.min(w.rect.w, a.w); w.rect.h = Math.min(w.rect.h, a.h);
        w.rect.x = clamp(w.rect.x, 0, Math.max(0, a.w - w.rect.w)); w.rect.y = clamp(w.rect.y, 0, Math.max(0, a.h - w.rect.h));
        w.applyRect();
      }
      if (OS.isMobile() && !w.max && !w.app.noMax) w.maximize();
      w.onResize && w.onResize();
    });
  });

  // ------------------------------ atalhos globais -------------------------
  document.addEventListener('keydown', (e) => {
    if (!document.body.classList.contains('session-on')) return;
    const typing = /INPUT|TEXTAREA|SELECT/.test((e.target.tagName || '')) || e.target.isContentEditable;
    if (e.key === 'F4' && e.altKey) { e.preventDefault(); WM.active && WM.active.close(); }
    if (e.ctrlKey && e.key === 'Escape') { e.preventDefault(); OS.togglePanel('start'); }
    if (e.ctrlKey && e.shiftKey && e.key === 'Escape') { e.preventDefault(); OS.openApp('taskmgr'); }
    if (e.altKey && e.key.toLowerCase() === 't' && e.ctrlKey) { e.preventDefault(); OS.openApp('terminal'); }
    if (e.ctrlKey && e.altKey && e.key.toLowerCase() === 'r') { e.preventDefault(); OS.openApp('run'); }
    if (e.altKey && e.key === 'Tab') { e.preventDefault(); OS.cycleWindows && OS.cycleWindows(e.shiftKey ? -1 : 1); }
    if (!typing && e.key === 'Meta') OS._metaDown = true; else if (e.key !== 'Meta') OS._metaDown = false;
  });
  document.addEventListener('keyup', (e) => { if (e.key === 'Meta' && OS._metaDown && document.body.classList.contains('session-on')) { OS.togglePanel('start'); } OS._metaDown = false; });

  OS.cycleWindows = (dir) => {
    const vis = OS.wins.filter((w) => true);
    if (vis.length < 2) return;
    const i = vis.indexOf(WM.active);
    const target = dir > 0 ? vis[(i <= 0 ? vis.length : i) - 1] : vis[0];
    if (target) { target.min && WM.unminimize(target, true); WM.focus(target); }
  };
})();
